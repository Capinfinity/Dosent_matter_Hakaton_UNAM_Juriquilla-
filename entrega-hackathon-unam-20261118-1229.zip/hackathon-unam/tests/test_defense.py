import pytest
from fastapi.testclient import TestClient

from backend.data_loader import get_store
from backend.engines.defense import recommend_defense
from backend.main import app
from backend.schemas import RecommendRequest


@pytest.fixture(scope="module")
def store():
    return get_store()


def correr(store, **kw):
    base = dict(mode="defense", down=3, yards_to_go=8, yardline_100=50, score_diff=0, quarter=2, clock_seconds=500)
    return recommend_defense(RecommendRequest(**{**base, **kw}), store)


def test_ofrece_solo_coberturas_man_o_zone_ordenadas(store):
    r = correr(store)
    claves = {o.key for o in r.options}
    assert {"Cover-1", "Cover-2", "Cover-3", "Quarters"} <= claves
    assert not claves & {"Prevent", "Red Zone", "Goal Line", "Bracket"}
    scores = [o.score for o in r.options]
    assert scores == sorted(scores, reverse=True)
    assert r.best == r.options[0].key
    assert all(o.score_metric == "EPA" for o in r.options)


@pytest.mark.parametrize("formacion", ["SHOTGUN", "EMPTY", "SINGLEBACK"])
def test_formaciones_comunes(store, formacion):
    r = correr(store, formation=formacion)
    assert r.options
    assert all(0 <= (o.success_rate or 0) <= 1 for o in r.options)


def test_la_formacion_cambia_la_recomendacion_o_los_valores(store):
    sin = {o.key: o.score for o in correr(store).options}
    con = {o.key: o.score for o in correr(store, formation="EMPTY").options}
    assert sin != con


def test_muestra_escasa_baja_la_confianza_y_avisa(store):
    r = correr(store, formation="SINGLEBACK", personnel="1 RB, 1 TE, 3 WR")
    assert any(o.confidence == "baja" for o in r.options)
    assert any("Muestra pequeña" in w or "muestra suficiente" in w for w in r.warnings)


def test_el_marcador_se_interpreta_desde_la_defensa(store):
    r = correr(store, score_diff=10)
    assert r.context["score_diff_ofensiva"] == -10


def test_recomienda_caja_cuando_hay_muestra(store):
    r = correr(store)
    assert 5 <= r.context["mejor_caja"] <= 8


def test_api_modo_defensivo():
    with TestClient(app) as c:
        r = c.post("/api/recommend", json={
            "mode": "defense", "down": 2, "yards_to_go": 6, "yardline_100": 35, "score_diff": -7,
            "quarter": 4, "clock_seconds": 200, "formation": "SHOTGUN", "personnel": "1 RB, 1 TE, 3 WR",
        })
    assert r.status_code == 200
    d = r.json()
    assert d["mode"] == "defense" and len(d["options"]) >= 5
