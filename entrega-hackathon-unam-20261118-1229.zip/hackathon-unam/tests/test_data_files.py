from pathlib import Path

import pandas as pd
import pytest

DATA = Path(__file__).resolve().parent.parent / "data"

COLUMNAS_PBP = {
    "season", "old_game_id", "play_id", "down", "ydstogo", "yardline_100",
    "game_seconds_remaining", "score_differential", "play_type", "epa", "wpa", "success",
    "fourth_down_converted", "field_goal_result", "kick_distance", "pass_length",
}
COLUMNAS_BDB = {"gameId", "playId", "pff_passCoverage", "defendersInBox", "offenseFormation", "personnelO"}


@pytest.fixture(scope="module")
def pbp():
    return pd.read_csv(DATA / "nflverse_pbp_filtered.csv", low_memory=False)


@pytest.fixture(scope="module")
def bdb():
    return pd.read_csv(DATA / "plays.csv", low_memory=False)


def test_pbp_tiene_columnas_esperadas(pbp):
    assert COLUMNAS_PBP <= set(pbp.columns)


def test_pbp_cubre_2018_a_2023(pbp):
    assert set(pbp["season"].unique()) == set(range(2018, 2024))


def test_pbp_tiene_cuarto_down_y_tipos(pbp):
    assert (pbp["down"] == 4).sum() > 10000
    assert set(pbp["play_type"].unique()) == {"pass", "run", "punt", "field_goal"}


def test_bdb_tiene_columnas_esperadas(bdb):
    assert COLUMNAS_BDB <= set(bdb.columns)


def test_union_bdb_nflverse_2021(pbp, bdb):
    llaves = pbp[pbp["season"] == 2021][["old_game_id", "play_id"]].rename(
        columns={"old_game_id": "gameId", "play_id": "playId"}
    )
    unidas = bdb.merge(llaves, on=["gameId", "playId"], how="inner")
    assert len(unidas) / len(bdb) > 0.9
