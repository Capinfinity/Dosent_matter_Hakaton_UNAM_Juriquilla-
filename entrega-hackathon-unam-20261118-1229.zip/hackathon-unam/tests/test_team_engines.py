"""Los equipos elegidos deben modificar las recomendaciones de forma acotada y explicable."""
import pytest

from backend.data_loader import get_store
from backend.engines.defense import recommend_defense
from backend.engines.fourth_down import AJUSTE_MAX_CONVERSION, recommend_fourth_down
from backend.engines.offense import recommend_offense
from backend.schemas import RecommendRequest
from backend.teams import TEAM_CODES


@pytest.fixture(scope="module")
def store():
    return get_store()


def peticion(modo, **kw):
    base = dict(mode=modo, down=3, yards_to_go=6, yardline_100=45, score_diff=0, quarter=2, clock_seconds=500)
    if modo == "fourth_down":
        base.update(down=4, yards_to_go=2, yardline_100=40)
    return RecommendRequest(**{**base, **kw})


def por_clave(r):
    return {o.key: o for o in r.options}


# ---------------- ofensiva
def test_ofensiva_sin_equipos_no_cambia(store):
    r = recommend_offense(peticion("offense"), store)
    assert all(o.detail["ajuste_equipo"] == 0.0 for o in r.options)


def test_ofensiva_con_equipos_aplica_ajuste_y_lo_explica(store):
    base = por_clave(recommend_offense(peticion("offense"), store))
    r = recommend_offense(peticion("offense", team="KC", opponent="BUF"), store)
    con = por_clave(r)
    esperado = store.teams.off_delta["KC"]["run"] + store.teams.def_delta["BUF"]["run"]
    assert con["run"].detail["ajuste_equipo"] == pytest.approx(esperado)
    # la carrera solo cambia por el equipo (no depende de coberturas)
    assert con["run"].score == pytest.approx(base["run"].score + esperado)
    assert any("Ajuste por equipo" in n for n in r.notes)


def test_ofensiva_usa_la_mezcla_de_coberturas_del_rival(store):
    r = recommend_offense(peticion("offense", opponent="KC"), store)
    assert any("mezcla habitual de coberturas de KC" in n for n in r.notes)
    # si se indica la cobertura, manda la indicada
    r2 = recommend_offense(peticion("offense", opponent="KC", rival_coverage="Cover-3"), store)
    assert not any("mezcla habitual" in n for n in r2.notes)


def test_ofensiva_rivales_distintos_dan_resultados_distintos(store):
    a = {o.key: o.score for o in recommend_offense(peticion("offense", team="BAL", opponent="BUF"), store).options}
    b = {o.key: o.score for o in recommend_offense(peticion("offense", team="BAL", opponent="DET"), store).options}
    assert a != b


# ---------------- defensiva
def test_defensiva_con_equipo_rival_mezcla_formaciones(store):
    r = recommend_defense(peticion("defense", opponent="LA"), store)
    assert any("se promedian las formaciones de LA" in n for n in r.notes)
    assert r.options and r.best == r.options[0].key


def test_defensiva_formacion_indicada_manda_sobre_el_rival(store):
    r = recommend_defense(peticion("defense", opponent="LA", formation="SHOTGUN"), store)
    assert not any("se promedian las formaciones" in n for n in r.notes)


def test_defensiva_ajuste_de_tu_equipo(store):
    sin = por_clave(recommend_defense(peticion("defense"), store))
    con = por_clave(recommend_defense(peticion("defense", team="BUF"), store))
    for cob, o in con.items():
        assert o.score == pytest.approx(sin[cob].score + o.detail["ajuste_equipo"])
    assert any(o.detail["ajuste_equipo"] != 0 for o in con.values())


# ---------------- 4º down
def test_cuarto_down_ajuste_acotado(store):
    for team in TEAM_CODES:
        r = recommend_fourth_down(peticion("fourth_down", team=team, opponent="KC" if team != "KC" else "BUF"), store)
        go = por_clave(r)["go"]
        assert abs(go.detail["ajuste_equipo"]) <= AJUSTE_MAX_CONVERSION + 1e-9


def test_cuarto_down_buen_equipo_convierte_mas_que_uno_flojo(store):
    ts = store.teams
    mejor = max(TEAM_CODES, key=lambda t: ts.conv_off[t])
    peor = min(TEAM_CODES, key=lambda t: ts.conv_off[t])
    rival = next(t for t in TEAM_CODES if t not in (mejor, peor))
    a = por_clave(recommend_fourth_down(peticion("fourth_down", team=mejor, opponent=rival), store))["go"]
    b = por_clave(recommend_fourth_down(peticion("fourth_down", team=peor, opponent=rival), store))["go"]
    assert a.success_rate > b.success_rate


def test_cuarto_down_sin_equipos_no_cambia(store):
    go = por_clave(recommend_fourth_down(peticion("fourth_down"), store))["go"]
    assert go.detail["ajuste_equipo"] == 0.0


# ---------------- todas las combinaciones funcionan
@pytest.mark.parametrize("modo", ["offense", "defense", "fourth_down"])
def test_todos_los_equipos_funcionan_en_todos_los_modos(store, modo):
    from backend.engines import recommend
    for i, team in enumerate(TEAM_CODES):
        rival = TEAM_CODES[(i + 7) % len(TEAM_CODES)]
        r = recommend(peticion(modo, team=team, opponent=rival), store)
        assert r.options and r.best == r.options[0].key
