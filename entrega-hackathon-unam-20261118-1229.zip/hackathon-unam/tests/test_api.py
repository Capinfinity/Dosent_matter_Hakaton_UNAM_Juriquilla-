import pytest
from fastapi.testclient import TestClient

from backend.main import app

BASE = {
    "mode": "fourth_down", "down": 4, "yards_to_go": 2, "yardline_100": 40,
    "score_diff": -3, "quarter": 4, "clock_seconds": 300,
}


@pytest.fixture(scope="module")
def client():
    with TestClient(app) as c:
        yield c


def test_health(client):
    r = client.get("/health")
    assert r.status_code == 200
    assert r.json() == {"status": "ok"}


def test_meta(client):
    d = client.get("/api/meta").json()
    assert "Cover-3" in d["coverages"]
    assert "SHOTGUN" in d["formations"]
    assert set(d["modes"]) == {"offense", "defense", "fourth_down"}
    assert d["data"]["nflverse_plays"] > 100000
    assert d["data"]["bdb_plays"] > 8000


@pytest.mark.parametrize("mode", ["offense", "defense", "fourth_down"])
def test_recommend_esquema(client, mode):
    r = client.post("/api/recommend", json={**BASE, "mode": mode})
    assert r.status_code == 200
    d = r.json()
    assert d["mode"] == mode
    assert d["options"]
    assert d["best"] == d["options"][0]["key"]
    for o in d["options"]:
        assert {"key", "label", "score", "score_metric", "n_samples", "confidence"} <= set(o)
        assert o["confidence"] in {"alta", "media", "baja"}


def test_recommend_acepta_opcionales(client):
    body = {**BASE, "mode": "offense", "rival_coverage": "Cover-3", "formation": "SHOTGUN",
            "defenders_in_box": 6, "timeouts": 2}
    assert client.post("/api/recommend", json=body).status_code == 200


@pytest.mark.parametrize("cambio", [
    {"down": 0}, {"down": 5}, {"yards_to_go": 0}, {"yardline_100": 100}, {"quarter": 6},
    {"clock_seconds": 901}, {"mode": "otra"}, {"defenders_in_box": 20}, {"timeouts": 4},
    {"yards_to_go": 50, "yardline_100": 40},
    {"quarter": 5, "clock_seconds": 700},
])
def test_recommend_rechaza_entradas_invalidas(client, cambio):
    assert client.post("/api/recommend", json={**BASE, **cambio}).status_code == 422


def test_recommend_falta_campo(client):
    body = {k: v for k, v in BASE.items() if k != "down"}
    assert client.post("/api/recommend", json=body).status_code == 422


def test_segundos_de_juego():
    from backend.schemas import RecommendRequest
    r = RecommendRequest(**{**BASE, "quarter": 2, "clock_seconds": 120})
    assert r.game_seconds_remaining == 2 * 900 + 120
    assert r.half_seconds_remaining == 120
    r = RecommendRequest(**{**BASE, "quarter": 3, "clock_seconds": 600})
    assert r.half_seconds_remaining == 900 + 600
