import pytest
from fastapi.testclient import TestClient

from backend.data_loader import get_store
from backend.main import app
from backend.team_stats import CATEGORIAS, categorizar
from backend.teams import TEAM_CODES, TEAMS


@pytest.fixture(scope="module")
def store():
    return get_store()


@pytest.fixture(scope="module")
def client():
    with TestClient(app) as c:
        yield c


def test_hay_32_equipos_con_division_y_conferencia():
    assert len(TEAMS) == 32
    assert {t.conference for t in TEAMS.values()} == {"AFC", "NFC"}
    for conf in ("AFC", "NFC"):
        for div in ("Este", "Norte", "Sur", "Oeste"):
            assert sum(1 for t in TEAMS.values() if t.conference == conf and t.division == div) == 4


def test_los_equipos_coinciden_con_los_datos(store):
    assert set(TEAM_CODES) == set(store.pbp["posteam"].dropna().unique())
    assert set(TEAM_CODES) == set(store.bdb["possessionTeam"].unique())
    assert set(TEAM_CODES) == set(store.bdb["defensiveTeam"].unique())


def test_todos_los_equipos_tienen_perfil_completo(store):
    assert set(store.teams.profiles) == set(TEAM_CODES)
    for p in store.teams.profiles.values():
        o, d = p.offense, p.defense
        assert o.plays > 1000
        assert len(o.categories) == 9
        assert o.preferred and o.most_effective and o.signature and o.strength
        assert 0.3 < o.pass_rate < 0.8
        assert d.preferred_coverage and d.most_effective_coverage and d.signature_coverage
        assert d.preferred_coverage.label.endswith(("(Man)", "(Zone)"))
        assert d.man_rate is not None and 0 <= d.man_rate <= 1
        assert d.blitz_rate is not None and 0 <= d.blitz_rate <= 1
        assert d.pressure_rate is not None and 0 <= d.pressure_rate <= 1


def test_preferida_es_la_mas_usada_y_efectiva_la_de_mayor_epa(store):
    for p in store.teams.profiles.values():
        o = p.offense
        assert o.preferred.n == max(c.n for c in o.categories)
        ok = [c for c in o.categories if c.n >= 30]
        assert o.most_effective.epa_adj == max(c.epa_adj for c in ok)
        d = p.defense
        man_zone = [c for c in d.coverages if c.label.endswith(("(Man)", "(Zone)"))]
        assert d.preferred_coverage.n == max(c.n for c in man_zone)
        elegibles = [c for c in man_zone if c.n >= 25]
        assert d.most_effective_coverage.epa_adj == min(c.epa_adj for c in elegibles)


def test_las_proporciones_de_uso_suman_uno(store):
    for p in store.teams.profiles.values():
        assert sum(c.share for c in p.offense.categories) == pytest.approx(1.0, abs=1e-6)


def test_suavizado_acerca_las_muestras_pequenas_a_la_liga(store):
    for p in store.teams.profiles.values():
        for c in p.offense.categories:
            # el EPA suavizado queda entre el observado y el de la liga: nunca más lejos que el observado
            liga = c.epa_adj - c.edge
            assert abs(c.epa_adj - liga) <= abs(c.epa - liga) + 1e-9


def test_categorizar_excluye_capturas_y_scrambles(store):
    cat = categorizar(store.pbp)
    sacks = store.pbp["sack"] == 1
    assert cat[sacks].isna().all()
    scr = store.pbp["qb_scramble"] == 1
    assert cat[scr].isna().all()
    assert set(cat.dropna().unique()) <= set(CATEGORIAS)


def test_deltas_son_pequenos_y_acotados(store):
    for ab in TEAM_CODES:
        for t, v in store.teams.off_delta[ab].items():
            assert abs(v) < 0.25, (ab, t, v)
        for t, v in store.teams.def_delta[ab].items():
            assert abs(v) < 0.25, (ab, t, v)
        assert abs(store.teams.conv_off[ab]) < 0.2 and abs(store.teams.conv_def[ab]) < 0.2


def test_api_lista_y_perfil(client):
    lista = client.get("/api/teams").json()
    assert len(lista) == 32
    assert {"info", "preferred_offense", "most_effective_offense", "preferred_defense", "most_effective_defense"} <= set(lista[0])
    kc = client.get("/api/teams/KC").json()
    assert kc["info"]["name"] == "Kansas City Chiefs"
    assert kc["seasons"] == [2021, 2022, 2023]
    assert len(kc["offense"]["categories"]) == 9
    assert client.get("/api/teams/kc").status_code == 200
    assert client.get("/api/teams/XXX").status_code == 404


BASE = {"mode": "offense", "down": 3, "yards_to_go": 5, "yardline_100": 40, "score_diff": 0, "quarter": 2, "clock_seconds": 500}


@pytest.mark.parametrize("campos", [
    {"team": "XXX"}, {"opponent": "ZZZ"}, {"team": "KC", "opponent": "KC"},
])
def test_peticion_rechaza_equipos_invalidos(client, campos):
    assert client.post("/api/recommend", json={**BASE, **campos}).status_code == 422
