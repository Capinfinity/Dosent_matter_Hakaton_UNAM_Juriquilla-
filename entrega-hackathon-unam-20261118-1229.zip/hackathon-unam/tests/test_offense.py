import pytest
from fastapi.testclient import TestClient

from backend.data_loader import get_store
from backend.engines.offense import recommend_offense
from backend.main import app
from backend.schemas import RecommendRequest


@pytest.fixture(scope="module")
def store():
    return get_store()


def correr(store, **kw):
    base = dict(mode="offense", down=3, yards_to_go=10, yardline_100=60, score_diff=0, quarter=2, clock_seconds=500)
    return recommend_offense(RecommendRequest(**{**base, **kw}), store)


def por_clave(r):
    return {o.key: o for o in r.options}


def test_devuelve_las_cuatro_opciones_ordenadas(store):
    r = correr(store)
    assert set(por_clave(r)) == {"run", "pass_short", "pass_deep", "pass_pa"}
    scores = [o.score for o in r.options]
    assert scores == sorted(scores, reverse=True)
    assert r.best == r.options[0].key
    assert all(o.score_metric == "EPA" and o.n_samples > 0 for o in r.options)


def test_la_carrera_funciona_mejor_en_distancia_corta(store):
    corta = por_clave(correr(store, yards_to_go=2))["run"]
    larga = por_clave(correr(store, yards_to_go=10))["run"]
    assert corta.success_rate > larga.success_rate
    assert corta.score > larga.score


def test_una_cobertura_cambia_los_pases_pero_no_la_carrera(store):
    sin = por_clave(correr(store))
    con = por_clave(correr(store, rival_coverage="Cover-0"))
    assert con["run"].score == sin["run"].score
    assert con["pass_deep"].score != sin["pass_deep"].score
    assert con["pass_deep"].detail["ajuste_bdb"] > 0  # Cover-0 favorece el pase largo en BDB
    assert con["pass_deep"].detail["muestra_bdb"] > 0


def test_datos_opcionales_combinados_no_rompen(store):
    r = correr(store, rival_coverage="Cover-3", formation="SHOTGUN", personnel="1 RB, 1 TE, 3 WR",
               defenders_in_box=6, timeouts=2)
    assert r.options and r.context["ajustes_bdb"] == 4


def test_cobertura_inexistente_no_rompe_y_baja_la_confianza(store):
    r = correr(store, rival_coverage="Inventada")
    assert r.options
    assert any("no se ajustó" in w for w in r.warnings)


def test_el_marcador_y_el_reloj_cambian_el_resultado(store):
    a = {o.key: o.score for o in correr(store, quarter=2, clock_seconds=800).options}
    b = {o.key: o.score for o in correr(store, score_diff=-14, quarter=4, clock_seconds=90).options}
    assert a != b


def test_api_modo_ofensivo():
    with TestClient(app) as c:
        r = c.post("/api/recommend", json={
            "mode": "offense", "down": 3, "yards_to_go": 4, "yardline_100": 50, "score_diff": 0,
            "quarter": 3, "clock_seconds": 400, "rival_coverage": "Cover-3",
        })
    assert r.status_code == 200
    d = r.json()
    assert d["mode"] == "offense" and len(d["options"]) == 4
