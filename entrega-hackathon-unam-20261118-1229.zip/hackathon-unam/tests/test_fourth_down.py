import pytest
from fastapi.testclient import TestClient

from backend.data_loader import get_store
from backend.engines.fourth_down import recommend_fourth_down
from backend.main import app
from backend.schemas import RecommendRequest


@pytest.fixture(scope="module")
def store():
    return get_store()


def correr(store, **kw):
    base = dict(mode="fourth_down", down=4, yards_to_go=1, yardline_100=40, score_diff=0, quarter=2, clock_seconds=500)
    return recommend_fourth_down(RecommendRequest(**{**base, **kw}), store)


def test_4y1_en_terreno_rival_va_por_el_primero(store):
    r = correr(store, yards_to_go=1, yardline_100=40, quarter=1, clock_seconds=600)
    assert r.best == "go"


def test_4y10_en_campo_propio_despeja(store):
    r = correr(store, yards_to_go=10, yardline_100=75)
    assert r.best == "punt"


def test_4y15_desde_la_media_cancha_despeja(store):
    r = correr(store, yards_to_go=15, yardline_100=70)
    assert r.best == "punt"


def test_perdiendo_por_4_al_final_en_la_yarda_2_patea_gol_de_campo(store):
    r = correr(store, yards_to_go=2, yardline_100=2, score_diff=-4, quarter=4, clock_seconds=60)
    assert r.best == "fg"


def test_conversion_es_mayor_en_distancia_corta(store):
    corta = next(o for o in correr(store, yards_to_go=1).options if o.key == "go")
    larga = next(o for o in correr(store, yards_to_go=10).options if o.key == "go")
    assert corta.success_rate > larga.success_rate


def test_opciones_ordenadas_y_con_esquema(store):
    r = correr(store, yards_to_go=3, yardline_100=35)
    scores = [o.score for o in r.options]
    assert scores == sorted(scores, reverse=True)
    assert r.best == r.options[0].key
    for o in r.options:
        assert o.score_metric == "WPA" and o.n_samples > 0


def test_gol_de_campo_descartado_si_la_patada_es_muy_larga(store):
    r = correr(store, yards_to_go=5, yardline_100=60)
    assert "fg" not in {o.key for o in r.options}
    assert any("Gol de campo descartado" in n for n in r.notes)


def test_despeje_descartado_cerca_de_la_zona_de_anotacion(store):
    r = correr(store, yards_to_go=3, yardline_100=20)
    assert "punt" not in {o.key for o in r.options}


def test_el_reloj_y_el_marcador_cambian_los_valores(store):
    temprano = {o.key: o.score for o in correr(store, yards_to_go=5, yardline_100=30, quarter=1, clock_seconds=600).options}
    tarde = {o.key: o.score for o in correr(store, yards_to_go=5, yardline_100=30, score_diff=-8, quarter=4, clock_seconds=100).options}
    assert temprano != tarde


def test_situacion_extrema_no_rompe_la_api():
    with TestClient(app) as c:
        r = c.post("/api/recommend", json={
            "mode": "fourth_down", "down": 4, "yards_to_go": 30, "yardline_100": 99,
            "score_diff": 50, "quarter": 4, "clock_seconds": 10,
        })
    assert r.status_code in (200, 422)
    if r.status_code == 200:
        assert r.json()["options"]
    else:
        assert "similares" in r.json()["detail"]
