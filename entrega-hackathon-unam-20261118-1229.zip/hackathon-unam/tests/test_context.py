"""Pruebas de sensibilidad: el marcador y el reloj deben cambiar la recomendación de forma explicable."""
import pytest

from backend.data_loader import get_store
from backend.engines.common import confianza, describir_situacion, empate_tecnico
from backend.engines.fourth_down import recommend_fourth_down
from backend.engines.offense import recommend_offense
from backend.engines.defense import recommend_defense
from backend.schemas import Option, RecommendRequest


@pytest.fixture(scope="module")
def store():
    return get_store()


def cuarto(store, **kw):
    base = dict(mode="fourth_down", down=4, yards_to_go=3, yardline_100=30, score_diff=0, quarter=2, clock_seconds=500)
    return recommend_fourth_down(RecommendRequest(**{**base, **kw}), store)


def test_perdiendo_por_3_con_30_segundos_se_patea_gol_de_campo(store):
    r = cuarto(store, score_diff=-3, quarter=4, clock_seconds=30)
    assert r.best == "fg"


def test_la_misma_situacion_al_inicio_del_juego_va_por_el_primero(store):
    r = cuarto(store, score_diff=-3, quarter=1, clock_seconds=600)
    assert r.best == "go"


def test_ganando_por_10_en_campo_propio_se_despeja_y_perdiendo_se_arriesga(store):
    ganando = cuarto(store, yards_to_go=8, yardline_100=60, score_diff=10, quarter=4, clock_seconds=240)
    perdiendo = cuarto(store, yards_to_go=8, yardline_100=60, score_diff=-10, quarter=4, clock_seconds=240)
    assert ganando.best == "punt"
    assert perdiendo.best == "go"


def test_todos_los_modos_incluyen_la_situacion_en_el_contexto(store):
    base = dict(down=3, yards_to_go=5, yardline_100=40, score_diff=-8, quarter=4, clock_seconds=100)
    for fn, modo in ((recommend_fourth_down, "fourth_down"), (recommend_offense, "offense"), (recommend_defense, "defense")):
        d = {**base, "down": 4} if modo == "fourth_down" else base
        r = fn(RecommendRequest(mode=modo, **d), store)
        assert r.context["situacion"] == "Perdiendo por una anotación o menos · últimos 2 minutos del juego"


@pytest.mark.parametrize("diff,seg,q,clock,esperado", [
    (0, 3000, 1, 600, "Empatado · 1º cuarto"),
    (14, 1000, 3, 500, "Ganando por más de una anotación · 3º cuarto"),
    (3, 100, 4, 100, "Ganando por una anotación o menos · últimos 2 minutos del juego"),
    (-10, 1900, 2, 100, "Perdiendo por más de una anotación · últimos 2 minutos del primer tiempo"),
    (-9, 500, 5, 500, "Perdiendo por más de una anotación · tiempo extra"),
    (-8, 500, 5, 500, "Perdiendo por una anotación o menos · tiempo extra"),
])
def test_describir_situacion(diff, seg, q, clock, esperado):
    assert describir_situacion(diff, seg, q, clock) == esperado


def _op(key, score, metrica="WPA"):
    return Option(key=key, label=key, score=score, score_metric=metrica, n_samples=50, confidence="media")


def test_empate_tecnico():
    assert empate_tecnico([_op("a", 0.010), _op("b", 0.008)])
    assert not empate_tecnico([_op("a", 0.050), _op("b", 0.008)])
    assert empate_tecnico([_op("a", 0.10, "EPA"), _op("b", 0.09, "EPA")])
    assert not empate_tecnico([_op("a", 0.10, "EPA"), _op("b", 0.05, "EPA")])
    assert empate_tecnico([_op("a", 0.1)]) == []


@pytest.mark.parametrize("n,esperado", [(0, "baja"), (29, "baja"), (30, "media"), (99, "media"), (100, "alta")])
def test_confianza(n, esperado):
    assert confianza(n) == esperado
