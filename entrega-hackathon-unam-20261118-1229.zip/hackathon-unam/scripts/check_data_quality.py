"""Valida los datos contra la base de conocimiento (Datos/base_de_conocimiento_nfl_big_data_bowl.txt).

Cruza las jugadas de Big Data Bowl con nflverse (2021) y cuenta diferencias en down, distancia,
cuarto, reloj, marcador y posición en el campo. También lista los valores categóricos
(coberturas, formaciones, resultados) y los nulos de las columnas clave.

Uso: .venv/bin/python scripts/check_data_quality.py
"""
from __future__ import annotations

from pathlib import Path

import numpy as np
import pandas as pd

RAIZ = Path(__file__).resolve().parent.parent
DATA = RAIZ / "data"


def pct(n: int, total: int) -> str:
    return f"{n} de {total} ({100 * n / max(total, 1):.2f} %)"


def main() -> None:
    plays = pd.read_csv(DATA / "plays.csv", low_memory=False)
    games = pd.read_csv(DATA / "games.csv")
    pbp = pd.read_csv(DATA / "nflverse_pbp_filtered.csv", low_memory=False)

    nfl = (
        pbp[pbp["season"] == 2021]
        .drop_duplicates(["old_game_id", "play_id"])
        .rename(columns={
            "old_game_id": "gameId", "play_id": "playId", "down": "nfl_down", "ydstogo": "nfl_ydstogo",
            "qtr": "nfl_qtr", "yards_gained": "nfl_yards", "score_differential": "nfl_scorediff",
            "yardline_100": "nfl_yardline_100", "game_seconds_remaining": "nfl_game_seconds",
        })[["gameId", "playId", "nfl_down", "nfl_ydstogo", "nfl_qtr", "nfl_yards", "nfl_scorediff",
            "nfl_yardline_100", "nfl_game_seconds", "posteam"]]
    )
    m = plays.merge(nfl, on=["gameId", "playId"], how="inner").merge(
        games[["gameId", "homeTeamAbbr"]], on="gameId", how="left"
    )
    print(f"Jugadas BDB: {len(plays)}; con pareja en nflverse: {pct(len(m), len(plays))}")

    # Reloj del juego según BDB (15 min por cuarto, cuenta regresiva)
    mmss = m["gameClock"].str.split(":", expand=True).astype(int)
    clock = mmss[0] * 60 + mmss[1]
    game_sec = np.where(m["quarter"] <= 4, (4 - m["quarter"]) * 900 + clock, clock)

    # Marcador desde la perspectiva de la ofensiva
    local = m["possessionTeam"].eq(m["homeTeamAbbr"])
    dif_bdb = np.where(local, m["preSnapHomeScore"] - m["preSnapVisitorScore"],
                       m["preSnapVisitorScore"] - m["preSnapHomeScore"])

    # Yardas a la zona rival según el formato TV (yardlineSide + yardlineNumber)
    en_campo_propio = m["yardlineSide"].eq(m["possessionTeam"])
    yl100_tv = np.where(m["yardlineSide"].isna(), 50, np.where(en_campo_propio, 100 - m["yardlineNumber"], m["yardlineNumber"]))

    print("\nDiferencias BDB contra nflverse en jugadas emparejadas:")
    print("  down:                ", pct(int((m["down"] != m["nfl_down"]).sum()), len(m)))
    print("  yardas para primero: ", pct(int((m["yardsToGo"] != m["nfl_ydstogo"]).sum()), len(m)))
    print("  cuarto:              ", pct(int((m["quarter"] != m["nfl_qtr"]).sum()), len(m)))
    print("  reloj (más de 2 s):  ", pct(int(((game_sec - m["nfl_game_seconds"]).abs() > 2).sum()), len(m)))
    con_marcador = m["nfl_scorediff"].notna()
    print("  marcador:            ", pct(int((pd.Series(dif_bdb, index=m.index)[con_marcador] != m["nfl_scorediff"][con_marcador]).sum()),
                                         int(con_marcador.sum())))
    con_yl = m["nfl_yardline_100"].notna()
    print("  posición en campo:   ", pct(int((pd.Series(yl100_tv, index=m.index)[con_yl] != m["nfl_yardline_100"][con_yl]).sum()),
                                         int(con_yl.sum())), "(formato TV contra yardline_100)")
    print("  yardas de jugada:    ", pct(int((m["playResult"] != m["nfl_yards"]).sum()), len(m)),
          "(playResult incluye castigos; yards_gained de nflverse no)")
    print("  posesión (equipo):   ", pct(int((m["possessionTeam"] != m["posteam"]).sum()), len(m)))

    print("\nCoberturas:", plays["pff_passCoverage"].value_counts(dropna=False).to_dict())
    print("Tipos de cobertura:", plays["pff_passCoverageType"].value_counts(dropna=False).to_dict())
    print("Formaciones:", plays["offenseFormation"].value_counts(dropna=False).to_dict())
    print("Resultados de pase:", plays["passResult"].value_counts(dropna=False).to_dict())
    print("Nulos en columnas clave:",
          {c: int(plays[c].isna().sum()) for c in ["down", "yardsToGo", "pff_passCoverage", "offenseFormation",
                                                    "defendersInBox", "personnelO", "pff_playAction"]})
    print("Defensores en la caja:", plays["defendersInBox"].value_counts(dropna=False).sort_index().to_dict())
    print("yardsToGo máximo:", int(plays["yardsToGo"].max()), "| down 4:", int((plays["down"] == 4).sum()))


if __name__ == "__main__":
    main()
