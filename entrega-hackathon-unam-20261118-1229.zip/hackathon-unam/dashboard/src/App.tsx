import { useEffect, useRef, useState } from 'react'
import { getMeta, getTeam, getTeams, recommend } from './api'
import PlayPanel from './components/PlayPanel'
import Results from './components/Results'
import SituationForm from './components/SituationForm'
import TeamCard from './components/TeamCard'
import TeamMenu from './components/TeamMenu'
import type { Meta, Mode, RecommendRequest, RecommendResponse, TeamProfile, TeamSummary } from './types'

const MODOS: { id: Mode; titulo: string; ayuda: string }[] = [
  { id: 'fourth_down', titulo: '4º down', ayuda: 'Patear, gol de campo o ir por el primero' },
  { id: 'offense', titulo: 'Ofensiva', ayuda: 'Carrera o pase según la defensa rival' },
  { id: 'defense', titulo: 'Defensiva', ayuda: 'Cobertura contra la ofensiva rival' },
]

interface Partido {
  team: string
  opponent: string
}

export default function App() {
  const [partido, setPartido] = useState<Partido | null>(null)
  const [equipos, setEquipos] = useState<TeamSummary[]>([])
  const [perfiles, setPerfiles] = useState<{ mine: TeamProfile | null; rival: TeamProfile | null }>({ mine: null, rival: null })
  const [verPerfiles, setVerPerfiles] = useState(false)

  const [mode, setMode] = useState<Mode>('fourth_down')
  const [meta, setMeta] = useState<Meta | null>(null)
  const [cargando, setCargando] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const [resultado, setResultado] = useState<RecommendResponse | null>(null)
  const [ultima, setUltima] = useState<RecommendRequest | null>(null)
  const [situacion, setSituacion] = useState({ down: 4, yardline_100: 40, yards_to_go: 2 })
  const [consulta, setConsulta] = useState(0) // sube con cada resultado nuevo: reinicia la simulación
  const yaConsulto = useRef(false)
  const secuencia = useRef(0)

  useEffect(() => {
    getMeta().then(setMeta).catch(() => setError('No se pudo cargar el catálogo de datos. Revisa que el servidor esté activo.'))
    getTeams().then(setEquipos).catch(() => setError('No se pudo cargar la lista de equipos. Revisa que el servidor esté activo.'))
  }, [])

  useEffect(() => {
    if (!partido) return
    setPerfiles({ mine: null, rival: null })
    Promise.all([getTeam(partido.team), getTeam(partido.opponent)])
      .then(([mine, rival]) => setPerfiles({ mine, rival }))
      .catch(() => setError('No se pudieron cargar los perfiles de los equipos.'))
  }, [partido])

  function cambiarModo(m: Mode) {
    setMode(m)
    setResultado(null)
    setError(null)
    yaConsulto.current = false
    secuencia.current++
  }

  function confirmarPartido(team: string, opponent: string) {
    setPartido({ team, opponent })
    setResultado(null)
    setError(null)
  }

  async function consultar(req: RecommendRequest) {
    const mia = ++secuencia.current // si llega una consulta más nueva, esta respuesta se descarta
    yaConsulto.current = true
    setSituacion({ down: req.down, yardline_100: req.yardline_100, yards_to_go: req.yards_to_go })
    setCargando(true)
    setError(null)
    try {
      const r = await recommend(req)
      if (mia !== secuencia.current) return
      setResultado(r)
      setUltima(req)
      setConsulta((n) => n + 1)
    } catch (e) {
      if (mia !== secuencia.current) return
      setResultado(null)
      setError(e instanceof Error ? e.message : 'Error desconocido')
    } finally {
      if (mia === secuencia.current) setCargando(false)
    }
  }

  // El campo sigue al formulario; si ya hay una recomendación, se recalcula sola
  function alCambiarFormulario(req: RecommendRequest) {
    setSituacion({ down: req.down, yardline_100: req.yardline_100, yards_to_go: req.yards_to_go })
    if (yaConsulto.current) void consultar(req)
  }

  const colorMio = perfiles.mine?.info.color ?? '#14532d'

  return (
    <div className="min-h-screen bg-gray-50 text-gray-900">
      <header className="px-6 py-4 text-white" style={{ backgroundColor: partido ? colorMio : '#14532d' }}>
        <div className="mx-auto flex max-w-6xl flex-wrap items-center justify-between gap-3">
          <div>
            <h1 className="text-xl font-bold">Asistente de jugadas NFL</h1>
            <p className="text-sm opacity-90">
              {partido
                ? `${partido.team} contra ${partido.opponent}`
                : 'Recomendación según la situación, el marcador, el reloj y el rival'}
            </p>
          </div>
          {partido && (
            <div className="flex gap-2">
              <button type="button" onClick={() => setVerPerfiles(!verPerfiles)} aria-expanded={verPerfiles}
                className="rounded border border-white/60 px-3 py-1.5 text-sm hover:bg-white/10">
                {verPerfiles ? 'Ocultar perfiles' : 'Ver perfiles'}
              </button>
              <button type="button" onClick={() => setPartido(null)}
                className="rounded border border-white/60 px-3 py-1.5 text-sm hover:bg-white/10">
                Cambiar equipos
              </button>
            </div>
          )}
        </div>
      </header>

      <main className="mx-auto max-w-6xl space-y-4 p-4">
        {!partido ? (
          equipos.length > 0 ? (
            <TeamMenu teams={equipos} initialTeam={null} initialOpponent={null} onConfirm={confirmarPartido} />
          ) : error ? (
            <p role="alert" className="rounded-lg border border-red-300 bg-red-50 p-3 text-sm text-red-700">{error}</p>
          ) : (
            <p className="text-sm text-gray-500">Cargando equipos…</p>
          )
        ) : (
          <>
            {verPerfiles && (
              <div className="grid gap-4 md:grid-cols-2">
                <TeamCard perfil={perfiles.mine} rol="Tu equipo" />
                <TeamCard perfil={perfiles.rival} rol="Rival" />
              </div>
            )}

            <nav className="flex flex-wrap gap-2" role="tablist" aria-label="Modo">
              {MODOS.map((m) => (
                <button
                  key={m.id}
                  role="tab"
                  aria-selected={mode === m.id}
                  onClick={() => cambiarModo(m.id)}
                  className={`rounded-lg border px-4 py-2 text-left text-sm ${
                    mode === m.id ? 'border-green-800 bg-green-800 text-white' : 'border-gray-300 bg-white hover:bg-gray-100'
                  }`}
                >
                  <span className="block font-semibold">{m.titulo}</span>
                  <span className={`block text-xs ${mode === m.id ? 'text-green-100' : 'text-gray-500'}`}>{m.ayuda}</span>
                </button>
              ))}
            </nav>

            <div className="grid gap-4 md:grid-cols-[360px_1fr]">
              <SituationForm key={mode} meta={meta} loading={cargando} mode={mode}
                team={partido.team} opponent={partido.opponent} onSubmit={consultar} onLive={alCambiarFormulario} />
              <div>
                {error && <p role="alert" className="rounded-lg border border-red-300 bg-red-50 p-3 text-sm text-red-700">{error}</p>}
                {!error && !resultado && !cargando && (
                  <p className="rounded-lg border border-dashed border-gray-300 p-6 text-sm text-gray-500">
                    Llena la situación y pulsa “Recomendar jugada”. Abajo puedes explorar cualquier jugada en el campo.
                  </p>
                )}
                {resultado && <Results data={resultado} />}
              </div>
            </div>

            <PlayPanel mode={mode} request={ultima} result={resultado} situation={situacion} consulta={consulta}
              mine={perfiles.mine} rival={perfiles.rival} />
          </>
        )}
      </main>
    </div>
  )
}
