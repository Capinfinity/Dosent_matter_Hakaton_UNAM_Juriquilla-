import { FIELD_LENGTH, type BallSeg, type Dot, type Pt } from './geometry'

// Equipos especiales. Coordenadas relativas a la LOS y al centro del campo.
// Medidas: el sostenedor (holder) se coloca a 7 yardas de la LOS; el despejador (punter) a 15 yardas.

type XY = [number, number]

interface Spot {
  role: string
  label: string
  kind: Dot['kind']
  at: XY
  to?: XY
  t0?: number
  t1?: number
}

const dot = (s: Spot, ghost = false): Dot => {
  const start: Pt = { x: s.at[0], y: s.at[1] }
  const path = s.to ? [start, { x: s.to[0], y: s.to[1] }] : [start]
  return {
    id: `O-${s.role}`, label: s.label, role: s.role, unit: 'off', ghost, kind: s.kind,
    start, path, t0: s.t0 ?? 0.1, t1: s.t1 ?? 0.6,
  }
}

const LINEA: Spot[] = [
  { role: 'LS', label: 'LS', kind: 'ol', at: [-0.5, 0] },
  { role: 'LG', label: 'LG', kind: 'ol', at: [-0.5, 1.3] },
  { role: 'RG', label: 'RG', kind: 'ol', at: [-0.5, -1.3] },
  { role: 'LT', label: 'LT', kind: 'ol', at: [-0.5, 2.6] },
  { role: 'RT', label: 'RT', kind: 'ol', at: [-0.5, -2.6] },
  { role: 'TEL', label: 'TE', kind: 'ol', at: [-0.5, 3.9] },
  { role: 'TER', label: 'TE', kind: 'ol', at: [-0.5, -3.9] },
]

export interface SpecialScene {
  dots: Dot[]
  ball: BallSeg[]
  focusX: [number, number]
  title: string
  description: string
  kickNote: string
}

/** Gol de campo. La distancia de la patada es la distancia a la línea de gol + 17 yardas (10 de la zona de anotación + 7 del sostenedor). */
export function fieldGoalScene(xLos: number, yardline100: number): SpecialScene {
  const dots = [
    ...LINEA,
    { role: 'WL', label: 'W', kind: 'ol', at: [-1.5, 5.2] },
    { role: 'WR', label: 'W', kind: 'ol', at: [-1.5, -5.2] },
    { role: 'H', label: 'H', kind: 'skill', at: [-7, 0.6] },
    { role: 'K', label: 'K', kind: 'st', at: [-10.8, -2.4], to: [-8.2, -0.9], t0: 0.14, t1: 0.4 },
  ].map((s) => dot(s as Spot))
  const dist = yardline100 + 17
  return {
    dots,
    ball: [
      { type: 'carry', id: 'O-LS', t0: 0, t1: 0.08 },
      { type: 'flight', from: 'O-LS', toId: 'O-H', t0: 0.08, t1: 0.2, arc: 0.1 },
      { type: 'carry', id: 'O-H', t0: 0.2, t1: 0.4 },
      { type: 'flight', from: 'O-H', toRel: { x: FIELD_LENGTH - xLos, y: 0 }, t0: 0.4, t1: 0.9, arc: 1.2 },
    ],
    focusX: [xLos - 14, FIELD_LENGTH],
    title: 'Gol de campo',
    description:
      'El centro (LS) pasa el balón al sostenedor (H) a 7 yardas de la línea de golpeo; el pateador (K) avanza y patea entre los postes.',
    kickNote: `Patada de ${dist} yardas: ${yardline100} hasta la línea de gol, más 10 de la zona de anotación y 7 del sostenedor. Los postes miden 6.17 yardas (18 pies 6 pulgadas) de ancho.`,
  }
}

/** Despeje: el despejador se coloca a 15 yardas y los gunners corren hacia el campo rival. */
export function puntScene(xLos: number): SpecialScene {
  const dots = [
    ...LINEA,
    { role: 'GL', label: 'G', kind: 'skill', at: [-0.5, 22], to: [42, 19], t0: 0.12, t1: 0.9 },
    { role: 'GR', label: 'G', kind: 'skill', at: [-0.5, -22], to: [42, -19], t0: 0.12, t1: 0.9 },
    { role: 'PP', label: 'PP', kind: 'ol', at: [-4, 0] },
    { role: 'P', label: 'P', kind: 'st', at: [-15, 0], to: [-13, 0], t0: 0.3, t1: 0.4 },
  ].map((s) => dot(s as Spot))
  const destino = Math.min(FIELD_LENGTH - 10 - xLos, 45) // el balón no pasa de la línea de gol
  return {
    dots,
    ball: [
      { type: 'carry', id: 'O-LS', t0: 0, t1: 0.1 },
      { type: 'flight', from: 'O-LS', toId: 'O-P', t0: 0.1, t1: 0.28, arc: 0.15 },
      { type: 'carry', id: 'O-P', t0: 0.28, t1: 0.4 },
      { type: 'flight', from: 'O-P', toRel: { x: destino, y: 0 }, t0: 0.4, t1: 0.95, arc: 1.4 },
    ],
    focusX: [xLos - 18, Math.min(FIELD_LENGTH, xLos + destino + 12)],
    title: 'Despeje',
    description:
      'El centro pasa el balón al despejador (P), a unas 15 yardas de la línea de golpeo. Los gunners (G) corren por las bandas para cubrir la patada.',
    kickNote: `Despeje promedio de 45 yardas desde la yarda ${Math.round(xLos - 10)} propia. El protector personal (PP) se coloca a 4 yardas detrás de la línea.`,
  }
}
