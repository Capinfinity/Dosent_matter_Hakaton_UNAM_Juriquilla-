// Medidas reglamentarias del campo (en yardas) y utilidades geométricas.
//
// Sistema de coordenadas de la base de conocimiento de Big Data Bowl:
//   x: 0 a 120 (zona de anotación de 10 + campo de 100 + zona de anotación de 10)
//   y: 0 a 53.33 (ancho). En pantalla y crece hacia arriba (la ofensiva ataca hacia la derecha).
//
// Las jugadas se escriben en coordenadas RELATIVAS a la línea de golpeo (LOS) y al centro del campo:
//   x > 0: hacia la zona de anotación rival (adelante); x < 0: detrás de la LOS.
//   y > 0: hacia la IZQUIERDA de la ofensiva (arriba en pantalla); y < 0: a su derecha.

export const FIELD_LENGTH = 120
export const FIELD_WIDTH = 53.33
export const END_ZONE = 10
export const MID_Y = FIELD_WIDTH / 2 // 26.665
export const HASH_FROM_SIDELINE = 70.75 / 3 // 70 pies 9 pulgadas = 23.58 yardas
export const GOAL_POST_WIDTH = 18.5 / 3 // 18 pies 6 pulgadas = 6.17 yardas
export const GOAL_POST_X_LEFT = 0
export const GOAL_POST_X_RIGHT = FIELD_LENGTH

export interface Pt {
  x: number
  y: number
}

export type Unit = 'off' | 'def'

export interface Dot {
  id: string
  label: string
  role: string
  unit: Unit
  ghost: boolean // true: unidad de contexto (rival), false: la unidad que se estudia
  kind: 'qb' | 'ol' | 'skill' | 'dl' | 'lb' | 'db' | 'st'
  start: Pt
  path: Pt[] // incluye el punto inicial como primer elemento
  t0: number // el movimiento empieza en este instante normalizado (0 a 1)
  t1: number // y termina en este
  assignedTo?: string // id del receptor al que marca (cobertura hombre)
}

export interface Zone {
  id: string
  label: string
  cx: number
  cy: number
  rx: number
  ry: number
}

export type BallSeg =
  | { type: 'carry'; id: string; t0: number; t1: number }
  | { type: 'flight'; from: string; toId?: string; toRel?: Pt; t0: number; t1: number; arc: number }

export interface Scene {
  title: string
  description: string
  xLos: number // posición absoluta de la LOS (0 a 120)
  dots: Dot[]
  zones: Zone[]
  ball: BallSeg[]
  mainUnit: Unit
  notes: string[]
  focusX?: [number, number] // tramo del campo (absoluto) que debe quedar visible; si no, se centra en la LOS
}

export const clamp = (v: number, lo: number, hi: number) => Math.min(hi, Math.max(lo, v))

export function segLen(a: Pt, b: Pt): number {
  return Math.hypot(b.x - a.x, b.y - a.y)
}

export function pathLength(path: Pt[]): number {
  let s = 0
  for (let i = 1; i < path.length; i++) s += segLen(path[i - 1], path[i])
  return s
}

/** Punto situado a una fracción f (0 a 1) de la longitud de la trayectoria. */
export function pointAlong(path: Pt[], f: number): Pt {
  if (path.length === 0) return { x: 0, y: 0 }
  if (path.length === 1 || f <= 0) return path[0]
  const total = pathLength(path)
  if (total === 0 || f >= 1) return path[path.length - 1]
  let objetivo = total * f
  for (let i = 1; i < path.length; i++) {
    const l = segLen(path[i - 1], path[i])
    if (objetivo <= l) {
      const k = l === 0 ? 0 : objetivo / l
      return { x: path[i - 1].x + (path[i].x - path[i - 1].x) * k, y: path[i - 1].y + (path[i].y - path[i - 1].y) * k }
    }
    objetivo -= l
  }
  return path[path.length - 1]
}

/** Parte recorrida de la trayectoria hasta la fracción f. */
export function partialPath(path: Pt[], f: number): Pt[] {
  if (path.length < 2 || f <= 0) return [path[0]]
  const total = pathLength(path)
  if (f >= 1 || total === 0) return path
  const out: Pt[] = [path[0]]
  let objetivo = total * f
  for (let i = 1; i < path.length; i++) {
    const l = segLen(path[i - 1], path[i])
    if (objetivo >= l) {
      out.push(path[i])
      objetivo -= l
    } else {
      const k = l === 0 ? 0 : objetivo / l
      out.push({ x: path[i - 1].x + (path[i].x - path[i - 1].x) * k, y: path[i - 1].y + (path[i].y - path[i - 1].y) * k })
      break
    }
  }
  return out
}

export function dotPos(d: Dot, t: number): Pt {
  if (d.path.length <= 1) return d.start
  const f = d.t1 <= d.t0 ? (t >= d.t1 ? 1 : 0) : clamp((t - d.t0) / (d.t1 - d.t0), 0, 1)
  return pointAlong(d.path, f)
}

export function dotProgress(d: Dot, t: number): number {
  if (d.t1 <= d.t0) return t >= d.t1 ? 1 : 0
  return clamp((t - d.t0) / (d.t1 - d.t0), 0, 1)
}

export interface BallState {
  p: Pt
  lift: number // 0 a 1: altura aparente del balón en vuelo
}

export function ballState(scene: Scene, t: number): BallState {
  const find = (id: string) => scene.dots.find((d) => d.id === id)
  const segs = scene.ball
  if (segs.length === 0) return { p: { x: 0, y: 0 }, lift: 0 }
  const first = segs[0]
  const last = segs[segs.length - 1]
  const seg = t <= first.t0 ? first : t >= last.t1 ? last : segs.find((s) => t >= s.t0 && t <= s.t1) ?? last
  if (seg.type === 'carry') {
    const d = find(seg.id)
    return { p: d ? dotPos(d, t) : { x: 0, y: 0 }, lift: 0 }
  }
  const from = find(seg.from)
  const a = from ? dotPos(from, seg.t0) : { x: 0, y: 0 }
  const target = seg.toId ? find(seg.toId) : undefined
  const b = target ? dotPos(target, seg.t1) : seg.toRel ?? a
  const f = clamp((t - seg.t0) / Math.max(1e-6, seg.t1 - seg.t0), 0, 1)
  return {
    p: { x: a.x + (b.x - a.x) * f, y: a.y + (b.y - a.y) * f },
    lift: seg.arc * Math.sin(Math.PI * f),
  }
}

export const mirrorPt = (p: Pt): Pt => ({ x: p.x, y: -p.y })

/** Convierte un punto relativo (LOS, centro) a coordenadas SVG del campo (y hacia abajo). */
export function toSvg(p: Pt, xLos: number): Pt {
  return { x: xLos + p.x, y: FIELD_WIDTH - (MID_Y + p.y) }
}

/** LOS absoluta a partir de las yardas que faltan para la zona de anotación rival (la ofensiva ataca a la derecha). */
export function xLosFromYardline100(yardline100: number): number {
  return clamp(FIELD_LENGTH - END_ZONE - yardline100, END_ZONE + 0.5, FIELD_LENGTH - END_ZONE - 0.5)
}
