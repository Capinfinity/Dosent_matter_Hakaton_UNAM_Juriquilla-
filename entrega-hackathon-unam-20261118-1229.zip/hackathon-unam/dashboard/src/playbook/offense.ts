import type { BallSeg, Dot, Pt } from './geometry'

// ---------------------------------------------------------------------------------------------
// Formaciones ofensivas (11 jugadores). Coordenadas relativas a la LOS y al centro del campo.
// Medidas: linieros separados 1.3 yd entre centros, ala cerrada a 3.9 yd del centro, receptor abierto
// a 21 yd (a unas 5 yd de la banda), mariscal en shotgun a 5 yd, bajo el centro a 1.3 yd.
// ---------------------------------------------------------------------------------------------

export type FormationName = 'SHOTGUN' | 'EMPTY' | 'SINGLEBACK' | 'I_FORM' | 'PISTOL'

interface Spot {
  role: string
  label: string
  kind: Dot['kind']
  x: number
  y: number
}

const OL: Spot[] = [
  { role: 'LT', label: 'LT', kind: 'ol', x: -0.5, y: 2.6 },
  { role: 'LG', label: 'LG', kind: 'ol', x: -0.5, y: 1.3 },
  { role: 'C', label: 'C', kind: 'ol', x: -0.5, y: 0 },
  { role: 'RG', label: 'RG', kind: 'ol', x: -0.5, y: -1.3 },
  { role: 'RT', label: 'RT', kind: 'ol', x: -0.5, y: -2.6 },
]

const spot = (role: string, label: string, kind: Dot['kind'], x: number, y: number): Spot => ({ role, label, kind, x, y })

const FORMATIONS: Record<FormationName, Spot[]> = {
  SHOTGUN: [
    ...OL,
    spot('QB', 'QB', 'qb', -5, 0), spot('RB', 'RB', 'skill', -5, -1.8), spot('TE', 'TE', 'skill', -0.5, -3.9),
    spot('X', 'X', 'skill', -0.5, 21), spot('SLOT', 'S', 'skill', -1.5, 9), spot('Z', 'Z', 'skill', -1.3, -21),
  ],
  EMPTY: [
    ...OL,
    spot('QB', 'QB', 'qb', -5, 0), spot('TE', 'TE', 'skill', -0.5, -3.9),
    spot('X', 'X', 'skill', -0.5, 21), spot('SLOT', 'S', 'skill', -1.5, 11), spot('SLOT2', 'S', 'skill', -1.5, -11),
    spot('Z', 'Z', 'skill', -0.5, -21),
  ],
  SINGLEBACK: [
    ...OL,
    spot('QB', 'QB', 'qb', -1.3, 0), spot('RB', 'RB', 'skill', -6, 0), spot('TE', 'TE', 'skill', -0.5, -3.9),
    spot('X', 'X', 'skill', -0.5, 21), spot('SLOT', 'S', 'skill', -1.5, 9), spot('Z', 'Z', 'skill', -1.3, -21),
  ],
  I_FORM: [
    ...OL,
    spot('QB', 'QB', 'qb', -1.3, 0), spot('FB', 'FB', 'skill', -4, 0), spot('RB', 'RB', 'skill', -6.5, 0),
    spot('TE', 'TE', 'skill', -0.5, -3.9), spot('X', 'X', 'skill', -0.5, 21), spot('Z', 'Z', 'skill', -1.3, -21),
  ],
  PISTOL: [
    ...OL,
    spot('QB', 'QB', 'qb', -3.5, 0), spot('RB', 'RB', 'skill', -6.8, 0), spot('TE', 'TE', 'skill', -0.5, -3.9),
    spot('X', 'X', 'skill', -0.5, 21), spot('SLOT', 'S', 'skill', -1.5, 9), spot('Z', 'Z', 'skill', -1.3, -21),
  ],
}

/** Convierte las formaciones de Big Data Bowl en las que dibuja la app. */
export function normalizarFormacion(f?: string | null): FormationName {
  const k = (f ?? '').toUpperCase()
  if (k === 'EMPTY') return 'EMPTY'
  if (k === 'SINGLEBACK' || k === 'JUMBO') return 'SINGLEBACK'
  if (k === 'I_FORM') return 'I_FORM'
  if (k === 'PISTOL') return 'PISTOL'
  return 'SHOTGUN' // SHOTGUN, WILDCAT y vacío
}

export const FORMACIONES_DISPONIBLES: FormationName[] = ['SHOTGUN', 'EMPTY', 'SINGLEBACK', 'I_FORM', 'PISTOL']

// ---------------------------------------------------------------------------------------------
// Jugadas. Cada ruta es la lista de puntos que sigue el jugador después de su posición inicial.
// ---------------------------------------------------------------------------------------------

type XY = [number, number]

export interface RouteSpec {
  pts: XY[]
  t0?: number
  t1?: number
}

export interface PlaySpec {
  id: string
  name: string
  kind: 'run' | 'pass'
  formation: FormationName
  mirror?: boolean // refleja formación y rutas (de izquierda a derecha)
  description: string
  routes: Record<string, RouteSpec>
  ball: BallSpec[]
  target?: string // receptor al que va el pase
}

type BallSpec =
  | { type: 'carry'; role: string; t0: number; t1: number }
  | { type: 'flight'; fromRole: string; toRole: string; t0: number; t1: number; arc: number }

const r = (t0: number, t1: number, ...pts: XY[]): RouteSpec => ({ pts, t0, t1 })

/** Giro de los linieros en una carrera por zonas: pasos laterales hacia el lado del corte. */
function zonaOL(dx: number, dy: number): Record<string, RouteSpec> {
  const out: Record<string, RouteSpec> = {}
  for (const o of OL) out[o.role] = r(0.08, 0.5, [o.x + dx, o.y + dy])
  return out
}

export const OFFENSE_PLAYS: PlaySpec[] = [
  // ---------------- Carreras ----------------
  {
    id: 'run_middle',
    name: 'Carrera por el centro (Inside Zone)',
    kind: 'run',
    formation: 'I_FORM',
    description:
      'El mariscal entrega a los 2 yardas de profundidad. El fullback abre el hueco entre el guardia y el centro y el corredor lo sigue.',
    routes: {
      ...zonaOL(1.2, 0.5),
      QB: r(0, 0.2, [-2.6, -0.8]),
      FB: r(0.05, 0.5, [-0.8, 1.6], [2.5, 2.2]),
      RB: r(0.12, 1, [-4.5, 0.3], [-0.5, 0.9], [3, 1.4], [8, 1]),
      TE: r(0.08, 0.5, [0.8, -2.6]),
      X: r(0.1, 0.8, [6, 20]),
      Z: r(0.1, 0.8, [5, -19]),
    },
    ball: [
      { type: 'carry', role: 'QB', t0: 0, t1: 0.2 },
      { type: 'carry', role: 'RB', t0: 0.2, t1: 1 },
    ],
  },
  {
    id: 'run_left',
    name: 'Carrera por la izquierda (Outside Zone)',
    kind: 'run',
    formation: 'SINGLEBACK',
    description:
      'Carrera por zonas hacia el exterior izquierdo. Los linieros se desplazan lateralmente y el corredor lee el bloqueo antes de cortar hacia arriba.',
    routes: {
      ...zonaOL(0.8, 1.6),
      QB: r(0, 0.15, [-2.4, 1.5]),
      TE: r(0.08, 0.5, [0.5, -2.2]),
      RB: r(0.12, 1, [-5.5, 2.5], [-2, 6.5], [1.5, 10], [6, 14]),
      X: r(0.1, 0.8, [5, 20]),
      SLOT: r(0.1, 0.8, [5, 10]),
      Z: r(0.1, 0.8, [6, -19]),
    },
    ball: [
      { type: 'carry', role: 'QB', t0: 0, t1: 0.15 },
      { type: 'carry', role: 'RB', t0: 0.15, t1: 1 },
    ],
  },
  // ---------------- Pases cortos ----------------
  {
    id: 'pass_short_left',
    name: 'Pase corto a la izquierda (Quick Out)',
    kind: 'pass',
    formation: 'SHOTGUN',
    description:
      'Pase rápido hacia la banda izquierda. El receptor abierto corre 5 yardas y rompe hacia afuera; el slot lo apoya en el flat.',
    routes: {
      QB: r(0, 0.25, [-6.5, 0]),
      X: r(0.05, 0.45, [5, 21], [5, 24.5]),
      SLOT: r(0.05, 0.6, [2, 9], [3, 16]),
      TE: r(0.05, 0.7, [4, -3.9], [4.5, -9]),
      Z: r(0.05, 0.8, [14, -21]),
      RB: r(0.1, 0.7, [-4.5, -5], [-2, -12]),
      ...Object.fromEntries(OL.map((o) => [o.role, r(0, 0.3, [o.x - 1, o.y])])),
    },
    ball: [
      { type: 'carry', role: 'QB', t0: 0, t1: 0.28 },
      { type: 'flight', fromRole: 'QB', toRole: 'X', t0: 0.28, t1: 0.45, arc: 0.35 },
      { type: 'carry', role: 'X', t0: 0.45, t1: 1 },
    ],
    target: 'X',
  },
  {
    id: 'pass_short_middle',
    name: 'Pase corto al centro (Slant + Curl)',
    kind: 'pass',
    formation: 'SHOTGUN',
    description:
      'El receptor abierto corre un slant hacia el centro y el slot un curl a 8 yardas. El mariscal lanza al slot al terminar su regreso.',
    routes: {
      QB: r(0, 0.3, [-6.8, 0]),
      X: r(0.05, 0.6, [2.5, 20], [8, 13]),
      SLOT: r(0.05, 0.6, [8, 8.5], [6.5, 9.5]),
      TE: r(0.05, 0.7, [3, -3.9], [4, -12]),
      Z: r(0.05, 0.6, [5, -21], [4, -21]),
      RB: r(0.1, 0.7, [-4, -6], [0, -10]),
      ...Object.fromEntries(OL.map((o) => [o.role, r(0, 0.3, [o.x - 1, o.y])])),
    },
    ball: [
      { type: 'carry', role: 'QB', t0: 0, t1: 0.38 },
      { type: 'flight', fromRole: 'QB', toRole: 'SLOT', t0: 0.38, t1: 0.6, arc: 0.4 },
      { type: 'carry', role: 'SLOT', t0: 0.6, t1: 1 },
    ],
    target: 'SLOT',
  },
  // ---------------- Pases largos ----------------
  {
    id: 'pass_deep_left',
    name: 'Pase largo a la izquierda (Go + Post)',
    kind: 'pass',
    formation: 'SHOTGUN',
    description:
      'El receptor abierto corre una ruta vertical por la banda izquierda mientras el slot corre un post para abrir espacio. Caída de 7 yardas del mariscal.',
    routes: {
      QB: r(0, 0.3, [-8, 0]),
      X: r(0.05, 0.75, [24, 21]),
      SLOT: r(0.05, 0.75, [10, 9], [20, 2]),
      TE: r(0.05, 0.75, [10, -3.9], [18, -3.9]),
      Z: r(0.05, 0.75, [10, -21], [10, -10]),
      RB: r(0, 0.4, [-5.5, -2.5]),
      ...Object.fromEntries(OL.map((o) => [o.role, r(0, 0.4, [o.x - 1.2, o.y])])),
    },
    ball: [
      { type: 'carry', role: 'QB', t0: 0, t1: 0.33 },
      { type: 'flight', fromRole: 'QB', toRole: 'X', t0: 0.33, t1: 0.75, arc: 1 },
      { type: 'carry', role: 'X', t0: 0.75, t1: 1 },
    ],
    target: 'X',
  },
  {
    id: 'pass_deep_middle',
    name: 'Pase largo al centro (Post + Seam)',
    kind: 'pass',
    formation: 'SHOTGUN',
    description:
      'Cuatro rutas verticales: el slot corre un seam por el centro, el receptor izquierdo un post y el derecho una ruta vertical por la banda.',
    routes: {
      QB: r(0, 0.3, [-8, 0]),
      X: r(0.05, 0.75, [10, 20], [22, 6]),
      SLOT: r(0.05, 0.75, [24, 7]),
      TE: r(0.05, 0.75, [18, -3.9]),
      Z: r(0.05, 0.75, [24, -21]),
      RB: r(0, 0.4, [-5.5, -2.5]),
      ...Object.fromEntries(OL.map((o) => [o.role, r(0, 0.4, [o.x - 1.2, o.y])])),
    },
    ball: [
      { type: 'carry', role: 'QB', t0: 0, t1: 0.33 },
      { type: 'flight', fromRole: 'QB', toRole: 'SLOT', t0: 0.33, t1: 0.75, arc: 1 },
      { type: 'carry', role: 'SLOT', t0: 0.75, t1: 1 },
    ],
    target: 'SLOT',
  },
  // ---------------- Play action ----------------
  {
    id: 'play_action',
    name: 'Play action con bootleg',
    kind: 'pass',
    formation: 'SINGLEBACK',
    description:
      'El mariscal finge la entrega al corredor y sale en bootleg hacia la derecha. El ala cerrada cruza por detrás de los apoyadores y recibe el pase.',
    routes: {
      QB: r(0, 0.55, [-3, 0], [-5.5, -4], [-6, -9]),
      RB: r(0, 0.45, [-3, 0.3], [0.5, 0.8], [2.5, 1.2]),
      TE: r(0.05, 0.75, [3, -3.9], [6, 4]),
      X: r(0.05, 0.75, [10, 21], [20, 8]),
      Z: r(0.05, 0.75, [12, -21], [20, -12]),
      SLOT: r(0.05, 0.75, [8, 9], [14, 14]),
      ...Object.fromEntries(OL.map((o) => [o.role, r(0.05, 0.4, [o.x + 0.3, o.y - 0.6])])),
    },
    ball: [
      { type: 'carry', role: 'QB', t0: 0, t1: 0.55 },
      { type: 'flight', fromRole: 'QB', toRole: 'TE', t0: 0.55, t1: 0.75, arc: 0.5 },
      { type: 'carry', role: 'TE', t0: 0.75, t1: 1 },
    ],
    target: 'TE',
  },
]

const mirrorXY = (p: XY): XY => [p[0], -p[1]]

function mirrorSpec(s: PlaySpec, id: string, name: string, description: string): PlaySpec {
  return {
    ...s,
    id,
    name,
    description,
    mirror: true,
    routes: Object.fromEntries(Object.entries(s.routes).map(([k, v]) => [k, { ...v, pts: v.pts.map(mirrorXY) }])),
  }
}

const byId = (id: string) => OFFENSE_PLAYS.find((p) => p.id === id)!

// Variantes hacia la derecha: se reflejan las de la izquierda
OFFENSE_PLAYS.push(
  mirrorSpec(byId('run_left'), 'run_right', 'Carrera por la derecha (Outside Zone)',
    'Carrera por zonas hacia el exterior derecho. Los linieros se desplazan lateralmente y el corredor lee el bloqueo antes de cortar hacia arriba.'),
  mirrorSpec(byId('pass_short_left'), 'pass_short_right', 'Pase corto a la derecha (Quick Out)',
    'Pase rápido hacia la banda derecha. El receptor abierto corre 5 yardas y rompe hacia afuera; el slot lo apoya en el flat.'),
  mirrorSpec(byId('pass_deep_left'), 'pass_deep_right', 'Pase largo a la derecha (Go + Post)',
    'El receptor abierto corre una ruta vertical por la banda derecha mientras el slot corre un post para abrir espacio. Caída de 7 yardas del mariscal.'),
)

export const OFFENSE_PLAY_IDS = OFFENSE_PLAYS.map((p) => p.id)

export function getOffensePlay(id: string): PlaySpec | undefined {
  return OFFENSE_PLAYS.find((p) => p.id === id)
}

// ---------------------------------------------------------------------------------------------
// Construcción de jugadores
// ---------------------------------------------------------------------------------------------

export function formationSpots(name: FormationName, mirror = false): Spot[] {
  return FORMATIONS[name].map((s) => ({ ...s, y: mirror ? -s.y : s.y }))
}

export function offenseDots(spec: PlaySpec, ghost: boolean): Dot[] {
  const spots = formationSpots(spec.formation, spec.mirror)
  return spots.map((s): Dot => {
    const start: Pt = { x: s.x, y: s.y }
    const ruta = spec.routes[s.role]
    const path = ruta ? [start, ...ruta.pts.map(([x, y]): Pt => ({ x, y }))] : [start]
    // Sin ruta: los linieros y el resto del backfield se quedan en su lugar
    return {
      id: `O-${s.role}`, label: s.label, role: s.role, unit: 'off', ghost, kind: s.kind,
      start, path, t0: ruta?.t0 ?? 0.05, t1: ruta?.t1 ?? 0.8,
    }
  })
}

export function offenseBall(spec: PlaySpec): BallSeg[] {
  return spec.ball.map((b): BallSeg =>
    b.type === 'carry'
      ? { type: 'carry', id: `O-${b.role}`, t0: b.t0, t1: b.t1 }
      : { type: 'flight', from: `O-${b.fromRole}`, toId: `O-${b.toRole}`, t0: b.t0, t1: b.t1, arc: b.arc },
  )
}

/** Concepto de pase genérico para mostrar rutas cuando se estudia una defensa. */
const GENERIC_ROUTES: Record<string, RouteSpec> = {
  QB: r(0, 0.3, [-7, 0]),
  X: r(0.05, 0.75, [10, 21], [22, 17]),
  SLOT: r(0.05, 0.75, [6, 9], [14, 3]),
  SLOT2: r(0.05, 0.75, [7, -11], [18, -11]),
  Z: r(0.05, 0.75, [10, -21], [10, -9]),
  TE: r(0.05, 0.75, [5, -3.9], [8, -12]),
  RB: r(0.1, 0.7, [-4, -6], [0, -13]),
  FB: r(0.1, 0.7, [-2, 3], [2, 9]),
}

export function genericPassConcept(formation: FormationName): PlaySpec {
  const spots = FORMATIONS[formation]
  const routes: Record<string, RouteSpec> = {}
  for (const s of spots) {
    if (GENERIC_ROUTES[s.role]) routes[s.role] = GENERIC_ROUTES[s.role]
    else if (s.kind === 'ol') routes[s.role] = r(0, 0.3, [s.x - 1, s.y])
  }
  return {
    id: `generic_${formation}`,
    name: `Concepto de pase desde ${formation}`,
    kind: 'pass',
    formation,
    description: 'Rutas de ejemplo de la ofensiva rival para ver cómo responde cada cobertura.',
    routes,
    ball: [{ type: 'carry', role: 'QB', t0: 0, t1: 1 }],
  }
}
