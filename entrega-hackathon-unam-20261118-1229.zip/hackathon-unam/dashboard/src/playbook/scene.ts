import { COVERAGES, defenseDots, getCoverage, runFitDots } from './defense'
import type { Scene } from './geometry'
import {
  genericPassConcept, getOffensePlay, normalizarFormacion, offenseBall, offenseDots, OFFENSE_PLAYS,
} from './offense'
import { fieldGoalScene, puntScene } from './special'

export interface BuildOpts {
  playId: string
  xLos: number // posición absoluta de la LOS (0 a 120)
  yardline100: number
  ghostCoverage?: string // defensa rival que se dibuja al estudiar una jugada ofensiva
  ghostFormation?: string // formación rival que se dibuja al estudiar una cobertura
}

export interface PlayOption {
  id: string
  label: string
  group: 'Ofensiva' | 'Defensiva' | 'Especiales'
}

export const PLAY_OPTIONS: PlayOption[] = [
  ...OFFENSE_PLAYS.map((p): PlayOption => ({ id: p.id, label: p.name, group: 'Ofensiva' })),
  ...COVERAGES.map((c): PlayOption => ({ id: c.id, label: c.name, group: 'Defensiva' })),
  { id: 'field_goal', label: 'Gol de campo', group: 'Especiales' },
  { id: 'punt', label: 'Despeje', group: 'Especiales' },
]

export function unitOf(playId: string): 'off' | 'def' {
  return getCoverage(playId) ? 'def' : 'off'
}

export function buildScene(o: BuildOpts): Scene | null {
  if (o.playId === 'field_goal') {
    const s = fieldGoalScene(o.xLos, o.yardline100)
    return {
      title: s.title, description: s.description, xLos: o.xLos, dots: s.dots, zones: [], ball: s.ball,
      mainUnit: 'off', notes: [s.kickNote], focusX: s.focusX,
    }
  }
  if (o.playId === 'punt') {
    const s = puntScene(o.xLos)
    return {
      title: s.title, description: s.description, xLos: o.xLos, dots: s.dots, zones: [], ball: s.ball,
      mainUnit: 'off', notes: [s.kickNote], focusX: s.focusX,
    }
  }

  const jugada = getOffensePlay(o.playId)
  if (jugada) {
    const cob = getCoverage(o.ghostCoverage ?? 'Cover-3') ?? COVERAGES[3]
    const ataque = offenseDots(jugada, false)
    const defensa = jugada.kind === 'run' ? runFitDots(cob, true) : defenseDots(cob, ataque, true)
    return {
      title: jugada.name,
      description: jugada.description,
      xLos: o.xLos,
      dots: [...ataque, ...defensa.dots],
      zones: jugada.kind === 'pass' ? defensa.zones : [],
      ball: offenseBall(jugada),
      mainUnit: 'off',
      notes: [
        jugada.kind === 'run'
          ? `La defensa rival (${cob.id}) cierra los huecos de la carrera.`
          : `Defensa rival dibujada: ${cob.name}.`,
      ],
    }
  }

  const cobertura = getCoverage(o.playId)
  if (cobertura) {
    const formacion = normalizarFormacion(o.ghostFormation)
    const concepto = genericPassConcept(formacion)
    const ataque = offenseDots(concepto, true)
    const defensa = defenseDots(cobertura, ataque, false)
    return {
      title: cobertura.name,
      description: cobertura.description,
      xLos: o.xLos,
      dots: [...ataque, ...defensa.dots],
      zones: defensa.zones,
      ball: [{ type: 'carry', id: 'O-QB', t0: 0, t1: 1 }],
      mainUnit: 'def',
      notes: [
        `Ofensiva rival dibujada: formación ${formacion} con un concepto de pase de ejemplo.`,
        cobertura.family === 'Man'
          ? 'Las líneas punteadas unen a cada defensor con el receptor que marca.'
          : 'Las zonas sombreadas muestran el área que protege cada defensor.',
      ],
    }
  }
  return null
}
