import type { Dot, Pt, Zone } from './geometry'

// ---------------------------------------------------------------------------------------------
// Coberturas defensivas desde una alineación nickel (4 linieros, 2 apoyadores, 3 esquineros, 2 safeties).
// Los nombres coinciden con `pff_passCoverage` de Big Data Bowl.
// Coordenadas relativas a la LOS y al centro del campo (y > 0: izquierda de la ofensiva).
// ---------------------------------------------------------------------------------------------

export type DefRole = 'DEL' | 'DTL' | 'DTR' | 'DER' | 'LB1' | 'LB2' | 'CBL' | 'CBR' | 'NCB' | 'FS' | 'SS'

type Asg = { type: 'rush' } | { type: 'zone'; zone: string } | { type: 'man' }
type XY = [number, number]

interface ZoneSpec {
  id: string
  label: string
  c: XY
  r: XY // semiejes (rx, ry)
}

export interface CoverageSpec {
  id: string
  name: string
  family: 'Man' | 'Zone' | 'Mixta'
  description: string
  align: Partial<Record<DefRole, XY>>
  asg: Record<DefRole, Asg>
  zones: ZoneSpec[]
}

const DL: Record<'DEL' | 'DTL' | 'DTR' | 'DER', XY> = {
  DEL: [0.5, 4.5], DTL: [0.5, 1.4], DTR: [0.5, -1.4], DER: [0.5, -4.5],
}
const RUSH: Asg = { type: 'rush' }
const MAN: Asg = { type: 'man' }
const Z = (zone: string): Asg => ({ type: 'zone', zone })
const DL_RUSH = { DEL: RUSH, DTL: RUSH, DTR: RUSH, DER: RUSH } as const

const LABELS: Record<DefRole, string> = {
  DEL: 'DE', DTL: 'DT', DTR: 'DT', DER: 'DE', LB1: 'M', LB2: 'W', CBL: 'CB', CBR: 'CB', NCB: 'NB', FS: 'FS', SS: 'SS',
}

const KIND: Record<DefRole, Dot['kind']> = {
  DEL: 'dl', DTL: 'dl', DTR: 'dl', DER: 'dl', LB1: 'lb', LB2: 'lb', CBL: 'db', CBR: 'db', NCB: 'db', FS: 'db', SS: 'db',
}

// Zonas profundas y de media distancia (yardas desde la LOS)
const DEEP_HALF_L: ZoneSpec = { id: 'deep_half_L', label: '½', c: [19, 13], r: [8, 12.5] }
const DEEP_HALF_R: ZoneSpec = { id: 'deep_half_R', label: '½', c: [19, -13], r: [8, 12.5] }
const FLAT_L: ZoneSpec = { id: 'flat_L', label: 'Flat', c: [4, 15.5], r: [4, 6] }
const FLAT_R: ZoneSpec = { id: 'flat_R', label: 'Flat', c: [4, -15.5], r: [4, 6] }
const CURL_L: ZoneSpec = { id: 'curl_L', label: 'Curl', c: [7, 9], r: [4, 4] }
const CURL_R: ZoneSpec = { id: 'curl_R', label: 'Curl', c: [7, -9], r: [4, 4] }
const HOOK_L: ZoneSpec = { id: 'hook_L', label: 'Hook', c: [8, 4], r: [4, 3.5] }
const HOOK_R: ZoneSpec = { id: 'hook_R', label: 'Hook', c: [8, -4], r: [4, 3.5] }
const HOLE: ZoneSpec = { id: 'hole', label: 'Hole', c: [9, 0], r: [4, 4] }
const THIRD_L: ZoneSpec = { id: 'third_L', label: '⅓', c: [19, 17], r: [8, 9.5] }
const THIRD_M: ZoneSpec = { id: 'third_M', label: '⅓', c: [19, 0], r: [8, 7.5] }
const THIRD_R: ZoneSpec = { id: 'third_R', label: '⅓', c: [19, -17], r: [8, 9.5] }
const Q_L: ZoneSpec = { id: 'q_L', label: '¼', c: [19, 19.5], r: [8, 7] }
const Q_ML: ZoneSpec = { id: 'q_ML', label: '¼', c: [19, 6.5], r: [8, 6] }
const Q_MR: ZoneSpec = { id: 'q_MR', label: '¼', c: [19, -6.5], r: [8, 6] }
const Q_R: ZoneSpec = { id: 'q_R', label: '¼', c: [19, -19.5], r: [8, 7] }
const MID_DEEP: ZoneSpec = { id: 'deep_mid', label: 'Centro', c: [19, 0], r: [8, 13] }

export const COVERAGES: CoverageSpec[] = [
  {
    id: 'Cover-0', name: 'Cover-0 (hombre puro con blitz)', family: 'Man',
    description: 'Hombre a hombre sin ayuda profunda. Seis rushers (los 4 de línea y los 2 apoyadores) buscan llegar al mariscal antes de que un receptor se libere.',
    align: { CBL: [1.5, 21], CBR: [1.5, -21], NCB: [1.5, 9], SS: [2.5, -4.5], FS: [7, -1.8], LB1: [4.5, 2.5], LB2: [4.5, -2.5] },
    asg: { ...DL_RUSH, LB1: RUSH, LB2: RUSH, CBL: MAN, CBR: MAN, NCB: MAN, SS: MAN, FS: MAN },
    zones: [],
  },
  {
    id: 'Cover-1', name: 'Cover-1 (hombre con un safety profundo)', family: 'Man',
    description: 'Cada defensor sigue a un receptor y el free safety cuida el fondo del campo. Un apoyador queda libre en la zona del medio (hole).',
    align: { CBL: [6, 21], CBR: [6, -21], NCB: [5, 9], SS: [4.5, -5.5], FS: [13, 0], LB1: [4.5, 2.5], LB2: [6, -1] },
    asg: { ...DL_RUSH, LB1: MAN, LB2: Z('hole'), CBL: MAN, CBR: MAN, NCB: MAN, SS: MAN, FS: Z('deep_mid') },
    zones: [MID_DEEP, HOLE],
  },
  {
    id: 'Cover-2', name: 'Cover-2 (zona con dos safeties profundos)', family: 'Zone',
    description: 'Dos safeties dividen el fondo en mitades y cinco defensores cubren las zonas cortas. Débil en el centro profundo, fuerte contra pases cortos.',
    align: { CBL: [5, 21], CBR: [5, -21], NCB: [5, 9], SS: [13, -9], FS: [13, 9], LB1: [4.5, 2.5], LB2: [4.5, -2.5] },
    asg: { ...DL_RUSH, LB1: Z('hole'), LB2: Z('curl_R'), CBL: Z('flat_L'), CBR: Z('flat_R'), NCB: Z('curl_L'), SS: Z('deep_half_R'), FS: Z('deep_half_L') },
    zones: [DEEP_HALF_L, DEEP_HALF_R, FLAT_L, FLAT_R, CURL_L, CURL_R, HOLE],
  },
  {
    id: 'Cover-3', name: 'Cover-3 (zona de tres tercios profundos)', family: 'Zone',
    description: 'Los dos esquineros y el free safety dividen el fondo en tercios; cuatro defensores cubren las zonas cortas. Sólida contra el pase largo, débil en los flats.',
    align: { CBL: [6, 21], CBR: [6, -21], NCB: [5, 10], SS: [5, -11], FS: [13, 0], LB1: [4.5, 3], LB2: [4.5, -3] },
    asg: { ...DL_RUSH, LB1: Z('hook_L'), LB2: Z('hook_R'), CBL: Z('third_L'), CBR: Z('third_R'), NCB: Z('flat_L'), SS: Z('flat_R'), FS: Z('third_M') },
    zones: [THIRD_L, THIRD_M, THIRD_R, FLAT_L, FLAT_R, HOOK_L, HOOK_R],
  },
  {
    id: 'Quarters', name: 'Quarters / Cover-4 (cuatro cuartos profundos)', family: 'Zone',
    description: 'Cuatro defensores dividen el fondo en cuartos y tres cubren las zonas cortas. Protege bien contra el pase largo y se adapta a rutas por dentro.',
    align: { CBL: [6, 21], CBR: [6, -21], NCB: [5, 10], SS: [10, -6], FS: [10, 6], LB1: [4.5, 3], LB2: [4.5, -3] },
    asg: { ...DL_RUSH, LB1: Z('hook_L'), LB2: Z('hook_R'), CBL: Z('q_L'), CBR: Z('q_R'), NCB: Z('curl_L'), SS: Z('q_MR'), FS: Z('q_ML') },
    zones: [Q_L, Q_ML, Q_MR, Q_R, CURL_L, HOOK_L, HOOK_R],
  },
  {
    id: 'Cover-6', name: 'Cover-6 (cuartos de un lado, mitades del otro)', family: 'Mixta',
    description: 'Híbrido: el lado izquierdo juega Quarters y el derecho Cover-2. Combina la protección profunda de los cuartos con el apoyo de un flat.',
    align: { CBL: [6, 21], CBR: [5, -21], NCB: [5, 10], SS: [13, -9], FS: [10, 6], LB1: [4.5, 3], LB2: [4.5, -3] },
    asg: { ...DL_RUSH, LB1: Z('hook_L'), LB2: Z('curl_R'), CBL: Z('q_L'), CBR: Z('flat_R'), NCB: Z('curl_L'), SS: Z('deep_half_R'), FS: Z('q_ML') },
    zones: [Q_L, Q_ML, DEEP_HALF_R, FLAT_R, CURL_L, HOOK_L, CURL_R],
  },
  {
    id: '2-Man', name: '2-Man (hombre con dos safeties profundos)', family: 'Man',
    description: 'Dos safeties cuidan las mitades del fondo y el resto marca hombre a hombre, con contacto en la línea. Fuerte contra rutas cortas, débil contra scrambles.',
    align: { CBL: [1.5, 21], CBR: [1.5, -21], NCB: [1.5, 9], SS: [13, -9], FS: [13, 9], LB1: [4.5, 2.5], LB2: [4.5, -2.5] },
    asg: { ...DL_RUSH, LB1: MAN, LB2: MAN, CBL: MAN, CBR: MAN, NCB: MAN, SS: Z('deep_half_R'), FS: Z('deep_half_L') },
    zones: [DEEP_HALF_L, DEEP_HALF_R],
  },
]

export const COVERAGE_IDS = COVERAGES.map((c) => c.id)

export function getCoverage(id: string): CoverageSpec | undefined {
  return COVERAGES.find((c) => c.id === id)
}

const ROLES: DefRole[] = ['DEL', 'DTL', 'DTR', 'DER', 'LB1', 'LB2', 'CBL', 'CBR', 'NCB', 'FS', 'SS']

function startOf(spec: CoverageSpec, role: DefRole): Pt {
  const a = (spec.align[role] ?? (role in DL ? DL[role as keyof typeof DL] : [5, 0])) as XY
  return { x: a[0], y: a[1] }
}

const OFFSET_HOMBRE: Pt = { x: 1, y: 0 } // el defensor marca un poco más profundo que su receptor

const kindEsLinea = (role: DefRole) => KIND[role] === 'dl'

/** Cobertura con rutas de respuesta a las del ataque rival (`off`). */
export function defenseDots(spec: CoverageSpec, off: Dot[], ghost: boolean): { dots: Dot[]; zones: Zone[] } {
  const zonas: Zone[] = spec.zones.map((z) => ({ id: z.id, label: z.label, cx: z.c[0], cy: z.c[1], rx: z.r[0], ry: z.r[1] }))
  const receptores = off.filter((d) => d.kind === 'skill').sort((a, b) => b.start.y - a.start.y)
  const hombres = ROLES.filter((r) => spec.asg[r].type === 'man').sort((a, b) => startOf(spec, b).y - startOf(spec, a).y)
  const pareja = new Map<DefRole, Dot>()
  hombres.forEach((r, i) => {
    if (receptores[i]) pareja.set(r, receptores[i])
  })

  const dots = ROLES.map((role): Dot => {
    const start = startOf(spec, role)
    const asg = spec.asg[role]
    const base: Dot = {
      id: `D-${role}`, label: LABELS[role], role, unit: 'def', ghost, kind: KIND[role],
      start, path: [start], t0: 0.1, t1: 0.6,
    }
    if (asg.type === 'rush') {
      // Los linieros chocan con la protección (que retrocede ~1 yd); quien viene de más atrás (blitz) llega a la altura de la línea
      const meta: Pt = kindEsLinea(role) ? { x: -0.2, y: start.y * 0.9 } : { x: -0.6, y: start.y * 0.4 }
      return { ...base, path: [start, meta], t0: 0.03, t1: 0.5 }
    }
    if (asg.type === 'zone') {
      const z = spec.zones.find((q) => q.id === asg.zone)
      if (!z) return base
      const anclaje: Pt = { x: z.c[0] - z.r[0] * 0.3, y: z.c[1] }
      return { ...base, path: [start, anclaje], t0: 0.08, t1: 0.55 }
    }
    const rec = pareja.get(role)
    if (!rec) return base
    const seguir = rec.path.map((p): Pt => ({ x: p.x + OFFSET_HOMBRE.x, y: p.y + OFFSET_HOMBRE.y }))
    return {
      ...base, path: [start, ...seguir], t0: Math.max(0, rec.t0 - 0.02), t1: Math.min(1, rec.t1 + 0.04), assignedTo: rec.id,
    }
  })
  return { dots, zones: zonas }
}

/** Respuesta de la defensa ante una carrera: la línea ataca los huecos y los demás cierran hacia el balón. */
export function runFitDots(spec: CoverageSpec, ghost: boolean): { dots: Dot[]; zones: Zone[] } {
  const dots = ROLES.map((role): Dot => {
    const start = startOf(spec, role)
    const kind = KIND[role]
    let meta: Pt
    if (kind === 'dl') meta = { x: 1.6, y: start.y * 0.6 }
    else if (kind === 'lb') meta = { x: 2.8, y: start.y * 0.5 }
    else if (role === 'NCB') meta = { x: 4, y: 6 }
    else if (role === 'CBL' || role === 'CBR') meta = { x: start.x + 2.5, y: start.y * 0.85 }
    else meta = { x: 6.5, y: start.y * 0.5 }
    return {
      id: `D-${role}`, label: LABELS[role], role, unit: 'def', ghost, kind,
      start, path: [start, meta], t0: 0.1, t1: 0.7,
    }
  })
  return { dots, zones: [] }
}
