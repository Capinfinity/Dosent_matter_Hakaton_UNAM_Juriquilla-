import type { PlayStat, TeamProfile } from '../types'

const pct = (v: number | null | undefined, d = 0) => (v === null || v === undefined ? '—' : `${(v * 100).toFixed(d)} %`)
const epa = (v: number) => `${v >= 0 ? '+' : ''}${v.toFixed(2)}`
const pts = (v: number) => `${v >= 0 ? '+' : ''}${(v * 100).toFixed(1)} pts`

function Fila({ titulo, jugada, detalle, ayuda }: { titulo: string; jugada: PlayStat | null; detalle: string; ayuda: string }) {
  return (
    <div className="flex items-start justify-between gap-2 py-1" title={ayuda}>
      <span className="text-xs text-gray-500">{titulo}</span>
      <span className="text-right text-sm">
        <span className="font-semibold text-gray-900">{jugada ? jugada.label : '—'}</span>
        {jugada && <span className="block text-xs text-gray-500">{detalle}</span>}
      </span>
    </div>
  )
}

export default function TeamCard({ perfil, rol }: { perfil: TeamProfile | null; rol: string }) {
  if (!perfil) {
    return <div className="rounded-lg border border-gray-200 bg-white p-4 text-sm text-gray-500">Cargando {rol}…</div>
  }
  const { info, offense: o, defense: d } = perfil
  const [y0, y1] = [perfil.seasons[0], perfil.seasons[perfil.seasons.length - 1]]
  return (
    <article className="overflow-hidden rounded-lg border border-gray-200 bg-white shadow-sm" aria-label={`Perfil de ${info.name}`}>
      <header className="px-4 py-2" style={{ backgroundColor: info.color, color: luminosa(info.color) ? '#111' : '#fff' }}>
        <p className="text-xs uppercase tracking-wide opacity-80">{rol}</p>
        <h3 className="text-lg font-bold">{info.name}</h3>
        <p className="text-xs opacity-80">{info.conference} {info.division}</p>
      </header>

      <div className="divide-y divide-gray-100 px-4 pb-3">
        <section className="py-2">
          <h4 className="text-xs font-semibold uppercase text-green-800">Ofensiva · {y0}–{y1}</h4>
          <p className="text-xs text-gray-500">{o.plays.toLocaleString('es-MX')} jugadas · pase {pct(o.pass_rate)}</p>
          <Fila titulo="Más usada" jugada={o.preferred} ayuda="La jugada que más repite entre los 9 tipos"
            detalle={o.preferred ? `${pct(o.preferred.share)} de sus jugadas · ${o.preferred.n} veces` : ''} />
          <Fila titulo="Más efectiva" jugada={o.most_effective} ayuda="Mayor EPA por jugada, suavizado hacia la liga según la muestra"
            detalle={o.most_effective ? `EPA ${epa(o.most_effective.epa_adj)} · ${o.most_effective.n} jugadas` : ''} />
          <Fila titulo="Sello" jugada={o.signature} ayuda="La jugada que usa más que el promedio de la liga"
            detalle={o.signature ? `${pts(o.signature.lift)} más que la liga` : ''} />
          <Fila titulo="Fortaleza" jugada={o.strength} ayuda="La jugada donde rinde más que la liga"
            detalle={o.strength ? `EPA ${pts(o.strength.edge).replace(' pts', '')} sobre la liga` : ''} />
        </section>

        <section className="py-2">
          <h4 className="text-xs font-semibold uppercase text-red-800">Defensa · {y0}–{y1}</h4>
          <p className="text-xs text-gray-500">
            Blitz {pct(d.blitz_rate)} · presión {pct(d.pressure_rate)} · hombre {pct(d.man_rate)}
          </p>
          <Fila titulo="Cobertura preferida" jugada={d.preferred_coverage} ayuda="Cobertura Man o Zone que más usa (Big Data Bowl 2021)"
            detalle={d.preferred_coverage ? `${pct(d.preferred_coverage.share)} de sus jugadas · ${d.preferred_coverage.n} veces` : ''} />
          <Fila titulo="Más efectiva" jugada={d.most_effective_coverage} ayuda="Menor EPA permitido, suavizado hacia la liga según la muestra"
            detalle={d.most_effective_coverage ? `EPA permitido ${epa(d.most_effective_coverage.epa_adj)} · ${d.most_effective_coverage.n} jugadas` : ''} />
          <Fila titulo="Sello" jugada={d.signature_coverage} ayuda="La cobertura que usa más que el promedio de la liga"
            detalle={d.signature_coverage ? `${pts(d.signature_coverage.lift)} más que la liga` : ''} />
          <Fila titulo="Más vulnerable" jugada={d.vulnerability} ayuda="El tipo de jugada donde más EPA permite"
            detalle={d.vulnerability ? `EPA permitido ${epa(d.vulnerability.epa_adj)}` : ''} />
        </section>
      </div>
    </article>
  )
}

function luminosa(hex: string): boolean {
  const n = parseInt(hex.replace('#', ''), 16)
  const lum = (0.299 * ((n >> 16) & 255) + 0.587 * ((n >> 8) & 255) + 0.114 * (n & 255)) / 255
  return lum > 0.65
}
