import { useEffect, useRef, useState } from 'react'
import type { Meta, Mode, RecommendRequest } from '../types'

interface Props {
  meta: Meta | null
  loading: boolean
  mode: Mode
  team?: string
  opponent?: string
  onSubmit: (req: RecommendRequest) => void
  /** Se llama (con una pausa breve) cada vez que el formulario cambia y es válido. */
  onLive?: (req: RecommendRequest) => void
}

interface Estado {
  down: string
  yardsToGo: string
  yardline: string
  scoreDiff: string
  quarter: string
  minutes: string
  seconds: string
  coverage: string
  formation: string
  personnel: string
  box: string
  timeouts: string
}

const INICIAL: Estado = {
  down: '4', yardsToGo: '2', yardline: '40', scoreDiff: '-3', quarter: '4',
  minutes: '5', seconds: '00', coverage: '', formation: '', personnel: '', box: '', timeouts: '',
}

const campo = 'w-full rounded border border-gray-300 px-2 py-1.5 text-sm focus:border-green-700 focus:outline-none focus:ring-1 focus:ring-green-700'
const etiqueta = 'mb-1 block text-xs font-medium text-gray-700'

function entero(txt: string): number | null {
  if (txt.trim() === '' || !/^-?\d+$/.test(txt.trim())) return null
  return parseInt(txt, 10)
}

export function construirPeticion(e: Estado, mode: Mode): RecommendRequest | string {
  const down = mode === 'fourth_down' ? 4 : entero(e.down)
  const ytg = entero(e.yardsToGo)
  const yl = entero(e.yardline)
  const sd = entero(e.scoreDiff)
  const q = entero(e.quarter)
  const min = entero(e.minutes)
  const sec = entero(e.seconds)

  if (down === null || down < 1 || down > 4) return 'El down debe estar entre 1 y 4.'
  if (ytg === null || ytg < 1 || ytg > 99) return 'Las yardas para el primero deben estar entre 1 y 99.'
  if (yl === null || yl < 1 || yl > 99) return 'La posición en el campo debe estar entre 1 y 99 yardas.'
  if (ytg > yl) return 'Las yardas para el primero no pueden superar la distancia a la zona de anotación.'
  if (sd === null || sd < -60 || sd > 60) return 'La diferencia de marcador debe estar entre -60 y 60.'
  if (q === null || q < 1 || q > 5) return 'El cuarto debe estar entre 1 y 5 (5 = tiempo extra).'
  if (min === null || min < 0 || sec === null || sec < 0 || sec > 59) return 'El reloj es inválido (minutos ≥ 0, segundos 0 a 59).'
  const reloj = min * 60 + sec
  const limite = q === 5 ? 600 : 900
  if (reloj > limite) return `El reloj no puede pasar de ${limite / 60}:00 en este cuarto.`

  const req: RecommendRequest = {
    mode, down, yards_to_go: ytg, yardline_100: yl, score_diff: sd, quarter: q, clock_seconds: reloj,
  }
  if (e.coverage && mode !== 'defense') req.rival_coverage = e.coverage
  if (e.formation) req.formation = e.formation
  if (e.personnel) req.personnel = e.personnel
  if (e.box.trim() !== '') {
    const b = entero(e.box)
    if (b === null || b < 3 || b > 11) return 'Los defensores en la caja deben estar entre 3 y 11.'
    req.defenders_in_box = b
  }
  if (e.timeouts.trim() !== '') {
    const t = entero(e.timeouts)
    if (t === null || t < 0 || t > 3) return 'Los tiempos fuera deben estar entre 0 y 3.'
    req.timeouts = t
  }
  return req
}

export default function SituationForm({ meta, loading, mode, team, opponent, onSubmit, onLive }: Props) {
  const [e, setE] = useState<Estado>(INICIAL)
  const [abierto, setAbierto] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const onLiveRef = useRef(onLive)
  onLiveRef.current = onLive

  // Avisa a la pantalla de cada cambio válido (con 350 ms de pausa para no saturar mientras se escribe)
  useEffect(() => {
    const r = construirPeticion(e, mode)
    if (typeof r === 'string') return
    const id = setTimeout(
      () => onLiveRef.current?.({ ...r, ...(team ? { team } : {}), ...(opponent ? { opponent } : {}) }),
      350,
    )
    return () => clearTimeout(id)
  }, [e, mode, team, opponent])

  const set = (k: keyof Estado) => (ev: { target: { value: string } }) => setE({ ...e, [k]: ev.target.value })

  function enviar(ev: React.FormEvent) {
    ev.preventDefault()
    const r = construirPeticion(e, mode)
    if (typeof r === 'string') {
      setError(r)
      return
    }
    setError(null)
    onSubmit({ ...r, ...(team ? { team } : {}), ...(opponent ? { opponent } : {}) })
  }

  const rival = mode === 'defense' ? 'ofensiva rival' : 'defensa rival'

  return (
    <form onSubmit={enviar} className="space-y-4 rounded-lg border border-gray-200 bg-white p-4 shadow-sm">
      <h2 className="text-sm font-semibold text-gray-900">Situación de juego</h2>

      <div className="grid grid-cols-2 gap-3">
        <div>
          <label className={etiqueta} htmlFor="down">Down</label>
          {mode === 'fourth_down' ? (
            <input id="down" className={`${campo} bg-gray-100`} value="4" disabled />
          ) : (
            <select id="down" className={campo} value={e.down} onChange={set('down')}>
              {[1, 2, 3, 4].map((d) => <option key={d} value={d}>{d}º</option>)}
            </select>
          )}
        </div>
        <div>
          <label className={etiqueta} htmlFor="ytg">Yardas para el primero</label>
          <input id="ytg" className={campo} inputMode="numeric" value={e.yardsToGo} onChange={set('yardsToGo')} />
        </div>
        <div className="col-span-2">
          <label className={etiqueta} htmlFor="yl">Yardas a la zona de anotación rival (1 a 99)</label>
          <input id="yl" className={campo} inputMode="numeric" value={e.yardline} onChange={set('yardline')} />
          <p className="mt-1 text-xs text-gray-500">Ejemplo: 40 = línea de 40 del rival; 80 = tu propia yarda 20.</p>
        </div>
        <div className="col-span-2">
          <label className={etiqueta} htmlFor="sd">Tu marcador menos el del rival</label>
          <input id="sd" className={campo} inputMode="numeric" value={e.scoreDiff} onChange={set('scoreDiff')} />
        </div>
        <div>
          <label className={etiqueta} htmlFor="q">Cuarto</label>
          <select id="q" className={campo} value={e.quarter} onChange={set('quarter')}>
            {[1, 2, 3, 4].map((c) => <option key={c} value={c}>{c}º</option>)}
            <option value="5">Tiempo extra</option>
          </select>
        </div>
        <div>
          <span className={etiqueta}>Reloj del cuarto</span>
          <div className="flex items-center gap-1">
            <input aria-label="Minutos" className={campo} inputMode="numeric" value={e.minutes} onChange={set('minutes')} />
            <span>:</span>
            <input aria-label="Segundos" className={campo} inputMode="numeric" value={e.seconds} onChange={set('seconds')} />
          </div>
        </div>
      </div>

      <div className="rounded border border-gray-200">
        <button
          type="button"
          onClick={() => setAbierto(!abierto)}
          aria-expanded={abierto}
          className="flex w-full items-center justify-between px-3 py-2 text-left text-sm font-medium text-gray-800"
        >
          Más datos (opcional)
          <span aria-hidden>{abierto ? '−' : '+'}</span>
        </button>
        {abierto && (
          <div className="grid grid-cols-2 gap-3 border-t border-gray-200 p-3">
            {mode !== 'defense' && (
              <div className="col-span-2">
                <label className={etiqueta} htmlFor="cov">Cobertura de la {rival}</label>
                <select id="cov" className={campo} value={e.coverage} onChange={set('coverage')}>
                  <option value="">No sé / sin dato</option>
                  {meta?.coverages.map((c) => <option key={c} value={c}>{c}</option>)}
                </select>
              </div>
            )}
            <div className="col-span-2">
              <label className={etiqueta} htmlFor="form">Formación ofensiva</label>
              <select id="form" className={campo} value={e.formation} onChange={set('formation')}>
                <option value="">Sin dato</option>
                {meta?.formations.map((f) => <option key={f} value={f}>{f}</option>)}
              </select>
            </div>
            <div className="col-span-2">
              <label className={etiqueta} htmlFor="pers">Personal ofensivo</label>
              <select id="pers" className={campo} value={e.personnel} onChange={set('personnel')}>
                <option value="">Sin dato</option>
                {meta?.personnel.map((p) => <option key={p} value={p}>{p}</option>)}
              </select>
            </div>
            <div>
              <label className={etiqueta} htmlFor="box">Defensores en la caja</label>
              <input id="box" className={campo} inputMode="numeric" placeholder="3 a 11" value={e.box} onChange={set('box')} />
            </div>
            <div>
              <label className={etiqueta} htmlFor="to">Tus tiempos fuera</label>
              <input id="to" className={campo} inputMode="numeric" placeholder="0 a 3" value={e.timeouts} onChange={set('timeouts')} />
            </div>
          </div>
        )}
      </div>

      {error && <p role="alert" className="rounded bg-red-50 px-3 py-2 text-sm text-red-700">{error}</p>}

      <button
        type="submit"
        disabled={loading}
        className="w-full rounded bg-green-800 px-4 py-2 text-sm font-semibold text-white hover:bg-green-900 disabled:opacity-60"
      >
        {loading ? 'Calculando…' : 'Recomendar jugada'}
      </button>
    </form>
  )
}
