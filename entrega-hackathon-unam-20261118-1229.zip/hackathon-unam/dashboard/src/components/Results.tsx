import { Bar, BarChart, CartesianGrid, Cell, ResponsiveContainer, Tooltip, XAxis, YAxis } from 'recharts'
import type { Confidence, Option, RecommendResponse } from '../types'

const COLOR_CONF: Record<Confidence, string> = {
  alta: 'bg-green-100 text-green-800',
  media: 'bg-yellow-100 text-yellow-800',
  baja: 'bg-red-100 text-red-800',
}

function fmtScore(o: Option): string {
  const v = o.score_metric === 'WPA' ? `${(o.score * 100).toFixed(1)} pp` : o.score.toFixed(3)
  return `${o.score >= 0 ? '+' : ''}${v}`
}

function fmtPct(v: number | null): string {
  return v === null ? '—' : `${(v * 100).toFixed(0)}%`
}

export default function Results({ data }: { data: RecommendResponse }) {
  const mejor = data.options.find((o) => o.key === data.best) ?? data.options[0]
  const metrica = mejor.score_metric
  const grafica = data.options.map((o) => ({
    nombre: o.label,
    valor: metrica === 'WPA' ? +(o.score * 100).toFixed(2) : +o.score.toFixed(3),
    esMejor: o.key === data.best,
  }))
  const unidad = metrica === 'WPA' ? 'Cambio en prob. de victoria (puntos porcentuales)' : 'EPA por jugada'

  return (
    <section className="space-y-4" aria-live="polite">
      <div className="rounded-lg border border-green-700 bg-green-50 p-4">
        <p className="text-xs font-medium uppercase tracking-wide text-green-800">Recomendación</p>
        <p className="text-2xl font-bold text-green-900">{mejor.label}</p>
        {typeof data.context.situacion === 'string' && (
          <p className="text-sm text-green-900">{data.context.situacion}</p>
        )}
        <p className="text-sm text-green-900">
          {metrica}: {fmtScore(mejor)} · Muestra: {mejor.n_samples} jugadas · Confianza {mejor.confidence}
        </p>
      </div>

      {data.warnings.length > 0 && (
        <ul className="space-y-1 rounded-lg border border-yellow-300 bg-yellow-50 p-3 text-sm text-yellow-900">
          {data.warnings.map((w) => <li key={w}>⚠ {w}</li>)}
        </ul>
      )}

      <div className="overflow-x-auto rounded-lg border border-gray-200 bg-white shadow-sm">
        <table className="w-full text-left text-sm">
          <thead className="bg-gray-50 text-xs uppercase text-gray-600">
            <tr>
              <th className="px-3 py-2">Opción</th>
              <th className="px-3 py-2">{metrica}</th>
              <th className="px-3 py-2">Éxito</th>
              <th className="px-3 py-2">Muestra</th>
              <th className="px-3 py-2">Confianza</th>
            </tr>
          </thead>
          <tbody>
            {data.options.map((o) => (
              <tr key={o.key} className={o.key === data.best ? 'bg-green-50 font-semibold' : ''}>
                <td className="px-3 py-2">{o.key === data.best ? '★ ' : ''}{o.label}</td>
                <td className="px-3 py-2 tabular-nums">{fmtScore(o)}</td>
                <td className="px-3 py-2 tabular-nums">{fmtPct(o.success_rate)}</td>
                <td className="px-3 py-2 tabular-nums">{o.n_samples}</td>
                <td className="px-3 py-2">
                  <span className={`rounded-full px-2 py-0.5 text-xs ${COLOR_CONF[o.confidence]}`}>{o.confidence}</span>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      <div className="rounded-lg border border-gray-200 bg-white p-4 shadow-sm">
        <p className="mb-2 text-xs text-gray-600">{unidad}</p>
        <div style={{ width: '100%', height: 40 + grafica.length * 44 }}>
          <ResponsiveContainer>
            <BarChart data={grafica} layout="vertical" margin={{ left: 20, right: 20 }}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis type="number" />
              <YAxis type="category" dataKey="nombre" width={120} />
              <Tooltip />
              <Bar dataKey="valor">
                {grafica.map((g) => <Cell key={g.nombre} fill={g.esMejor ? '#2F7D4F' : '#9CA3AF'} />)}
              </Bar>
            </BarChart>
          </ResponsiveContainer>
        </div>
      </div>

      {data.notes.length > 0 && (
        <ul className="space-y-1 text-xs text-gray-600">
          {data.notes.map((n) => <li key={n}>{n}</li>)}
        </ul>
      )}
    </section>
  )
}
