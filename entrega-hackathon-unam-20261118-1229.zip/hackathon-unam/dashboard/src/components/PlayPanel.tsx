import { useEffect, useMemo, useRef, useState } from 'react'
import { COVERAGE_IDS } from '../playbook/defense'
import { xLosFromYardline100 } from '../playbook/geometry'
import { FORMACIONES_DISPONIBLES } from '../playbook/offense'
import { buildScene, PLAY_OPTIONS, unitOf } from '../playbook/scene'
import type { Mode, RecommendRequest, RecommendResponse, TeamProfile } from '../types'
import FieldView, { type TeamColors } from './FieldView'

interface Props {
  mode: Mode
  request: RecommendRequest | null
  result: RecommendResponse | null
  situation: { down: number; yardline_100: number; yards_to_go: number }
  consulta: number // sube con cada resultado nuevo, aunque la jugada recomendada sea la misma
  mine: TeamProfile | null
  rival: TeamProfile | null
}

const DURACION_S = 6

/** Mejor variante (izquierda, centro o derecha) de un tipo de jugada según el EPA de tu equipo. */
function mejorVariante(prefijo: 'run' | 'pass_short' | 'pass_deep', perfil: TeamProfile | null): string {
  const cand = (perfil?.offense.categories ?? []).filter((c) => c.id.startsWith(`${prefijo}_`))
  if (cand.length === 0) return `${prefijo}_middle`
  return cand.reduce((a, b) => (b.epa_adj > a.epa_adj ? b : a)).id
}

export function jugadaRecomendada(mode: Mode, best: string, yardsToGo: number, mine: TeamProfile | null): string {
  if (mode === 'defense') return COVERAGE_IDS.includes(best) ? best : 'Cover-3'
  if (mode === 'fourth_down') {
    if (best === 'fg') return 'field_goal'
    if (best === 'punt') return 'punt'
    return yardsToGo <= 2 ? 'run_middle' : mejorVariante('pass_short', mine)
  }
  if (best === 'run') return mejorVariante('run', mine)
  if (best === 'pass_short') return mejorVariante('pass_short', mine)
  if (best === 'pass_deep') return mejorVariante('pass_deep', mine)
  return 'play_action'
}

function distancia(a: string, b: string): number {
  const f = (h: string) => {
    const n = parseInt(h.replace('#', ''), 16)
    return [(n >> 16) & 255, (n >> 8) & 255, n & 255]
  }
  const [r1, g1, b1] = f(a)
  const [r2, g2, b2] = f(b)
  return Math.hypot(r1 - r2, g1 - g2, b1 - b2)
}

/** Si los dos equipos tienen colores casi iguales, el rival usa su color secundario. */
function colores(mine: TeamProfile | null, rival: TeamProfile | null): { main: TeamColors; rival: TeamColors | null } {
  const m = mine ? { abbr: mine.info.abbr, color: mine.info.color, color2: mine.info.color2 } : { abbr: '', color: '#1d4ed8', color2: '#ffffff' }
  if (!rival) return { main: m, rival: null }
  let r = { abbr: rival.info.abbr, color: rival.info.color, color2: rival.info.color2 }
  if (distancia(m.color, r.color) < 70) r = { ...r, color: r.color2, color2: r.color }
  return { main: m, rival: r }
}

function useAnimacion(velocidad: number) {
  const [t, setT] = useState(0)
  const [reproduciendo, setReproduciendo] = useState(false)
  const tRef = useRef(0)
  const ultimo = useRef(0)

  useEffect(() => {
    if (!reproduciendo) return
    let raf = 0
    ultimo.current = 0
    const paso = (ts: number) => {
      if (ultimo.current === 0) ultimo.current = ts
      const dt = (ts - ultimo.current) / 1000
      ultimo.current = ts
      tRef.current = Math.min(1, tRef.current + (dt * velocidad) / DURACION_S)
      setT(tRef.current)
      if (tRef.current >= 1) setReproduciendo(false)
      else raf = requestAnimationFrame(paso)
    }
    raf = requestAnimationFrame(paso)
    return () => cancelAnimationFrame(raf)
  }, [reproduciendo, velocidad])

  const ir = (v: number) => {
    tRef.current = v
    setT(v)
  }
  const reiniciar = (auto: boolean) => {
    ir(0)
    setReproduciendo(auto)
  }
  const alternar = () => {
    if (tRef.current >= 1) ir(0)
    setReproduciendo((p) => !p)
  }
  return { t, reproduciendo, ir, reiniciar, alternar }
}

export default function PlayPanel({ mode, request, result, situation, consulta, mine, rival }: Props) {
  const recomendada = useMemo(
    () => (result ? jugadaRecomendada(mode, result.best, situation.yards_to_go, mine) : null),
    [mode, result, situation.yards_to_go, mine],
  )
  const inicial = mode === 'defense' ? 'Cover-3' : mode === 'fourth_down' ? 'run_middle' : 'pass_short_middle'
  const [playId, setPlayId] = useState<string>(recomendada ?? inicial)
  const [view, setView] = useState<'zoom' | 'full'>('zoom')
  const [velocidad, setVelocidad] = useState(1)
  const [coberturaRival, setCoberturaRival] = useState<string | null>(null)
  const [formacionRival, setFormacionRival] = useState<string | null>(null)
  const anim = useAnimacion(velocidad)

  // Cada resultado nuevo (aunque recomiende la misma jugada) o cambio de modo selecciona su jugada y la reproduce
  useEffect(() => {
    setPlayId(recomendada ?? inicial)
    anim.reiniciar(recomendada !== null)
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [recomendada, mode, consulta])

  const unidad = unitOf(playId)
  const ghostCob =
    coberturaRival ??
    (request?.rival_coverage && COVERAGE_IDS.includes(request.rival_coverage) ? request.rival_coverage : null) ??
    (rival?.defense.preferred_coverage && COVERAGE_IDS.includes(rival.defense.preferred_coverage.id) ? rival.defense.preferred_coverage.id : null) ??
    'Cover-3'
  const ghostForm = formacionRival ?? request?.formation ?? rival?.offense.formations[0]?.id ?? 'SHOTGUN'

  const xLos = xLosFromYardline100(situation.yardline_100)
  const escena = useMemo(
    () => buildScene({ playId, xLos, yardline100: situation.yardline_100, ghostCoverage: ghostCob, ghostFormation: ghostForm }),
    [playId, xLos, situation.yardline_100, ghostCob, ghostForm],
  )
  const col = colores(mine, rival)

  const elegir = (id: string) => {
    setPlayId(id)
    anim.reiniciar(true)
  }

  if (!escena) return null

  const grupos = ['Ofensiva', 'Defensiva', 'Especiales'] as const
  return (
    <section className="space-y-3 rounded-lg border border-gray-200 bg-white p-4 shadow-sm" aria-label="Simulación en el campo">
      <div className="flex flex-wrap items-end justify-between gap-3">
        <div>
          <h2 className="text-sm font-semibold text-gray-900">Simulación en el campo</h2>
          <p className="text-xs text-gray-500">
            Vista aérea · {mine?.info.abbr ?? 'Tu equipo'} {unidad === 'off' ? 'ataca' : 'defiende'}
            {rival ? ` contra ${rival.info.abbr}` : ''} · {situation.down}º y {situation.yards_to_go} · LOS en la yarda {situation.yardline_100 <= 50 ? `${situation.yardline_100} rival` : `${100 - situation.yardline_100} propia`}
          </p>
        </div>
        <div>
          <label htmlFor="jugada" className="mb-1 block text-xs font-medium text-gray-700">Jugada</label>
          <select id="jugada" value={playId} onChange={(e) => elegir(e.target.value)}
            className="rounded border border-gray-300 px-2 py-1.5 text-sm">
            {grupos.map((g) => (
              <optgroup key={g} label={g}>
                {PLAY_OPTIONS.filter((p) => p.group === g).map((p) => (
                  <option key={p.id} value={p.id}>{p.label}{p.id === recomendada ? '  ★ recomendada' : ''}</option>
                ))}
              </optgroup>
            ))}
          </select>
        </div>
      </div>

      <FieldView scene={escena} t={anim.t} main={col.main} rival={col.rival} view={view} yardsToGo={situation.yards_to_go} />

      <div className="flex flex-wrap items-center gap-2">
        <button type="button" onClick={anim.alternar}
          className="rounded bg-green-800 px-3 py-1.5 text-sm font-semibold text-white hover:bg-green-900">
          {anim.reproduciendo ? '⏸ Pausa' : anim.t >= 1 ? '↺ Repetir' : '▶ Simular'}
        </button>
        <button type="button" onClick={() => anim.reiniciar(false)}
          className="rounded border border-gray-300 px-3 py-1.5 text-sm hover:bg-gray-50">Inicio</button>
        <input aria-label="Avance de la jugada" type="range" min={0} max={1000} value={Math.round(anim.t * 1000)}
          onChange={(e) => anim.ir(Number(e.target.value) / 1000)} className="min-w-[8rem] flex-1" />
        <label className="flex items-center gap-1 text-xs text-gray-700">
          Velocidad
          <select value={velocidad} onChange={(e) => setVelocidad(Number(e.target.value))} className="rounded border border-gray-300 px-1 py-1 text-sm">
            <option value={0.5}>0.5×</option><option value={1}>1×</option><option value={2}>2×</option>
          </select>
        </label>
        <div className="flex overflow-hidden rounded border border-gray-300 text-sm" role="group" aria-label="Vista">
          {(['zoom', 'full'] as const).map((v) => (
            <button key={v} type="button" aria-pressed={view === v} onClick={() => setView(v)}
              className={`px-2 py-1.5 ${view === v ? 'bg-gray-800 text-white' : 'hover:bg-gray-50'}`}>
              {v === 'zoom' ? 'Zoom a la jugada' : 'Campo completo'}
            </button>
          ))}
        </div>
      </div>

      <div className="flex flex-wrap gap-3 text-xs text-gray-700">
        {unidad === 'off' && escena.dots.some((d) => d.unit === 'def') && (
          <label className="flex items-center gap-1">
            Defensa rival
            <select value={ghostCob} onChange={(e) => setCoberturaRival(e.target.value)} className="rounded border border-gray-300 px-1 py-1">
              {COVERAGE_IDS.map((c) => <option key={c} value={c}>{c}</option>)}
            </select>
          </label>
        )}
        {unidad === 'def' && (
          <label className="flex items-center gap-1">
            Formación rival
            <select value={ghostForm} onChange={(e) => setFormacionRival(e.target.value)} className="rounded border border-gray-300 px-1 py-1">
              {FORMACIONES_DISPONIBLES.map((f) => <option key={f} value={f}>{f}</option>)}
            </select>
          </label>
        )}
      </div>

      <div className="space-y-1 text-sm">
        <p className="font-semibold text-gray-900">{escena.title}</p>
        <p className="text-gray-700">{escena.description}</p>
        {escena.notes.map((n) => <p key={n} className="text-xs text-gray-500">{n}</p>)}
      </div>

      <p className="border-t border-gray-100 pt-2 text-xs text-gray-500">
        <span className="font-semibold">Leyenda:</span> ● ofensiva · ■ defensiva · línea azul = línea de golpeo (LOS) · línea amarilla = primer down ·
        flechas = rutas · línea roja punteada = marca hombre a hombre · zonas sombreadas = áreas de cobertura.
        {' '}Campo reglamentario: 120 × 53.33 yardas (100 de juego y 2 zonas de anotación de 10); hash marks a 70 pies 9 pulgadas (23.58 yd) de cada banda; postes de 6.17 yd.
      </p>
    </section>
  )
}
