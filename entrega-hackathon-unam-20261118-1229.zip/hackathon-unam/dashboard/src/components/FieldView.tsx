import {
  END_ZONE, FIELD_LENGTH, FIELD_WIDTH, GOAL_POST_WIDTH, HASH_FROM_SIDELINE, MID_Y,
  ballState, clamp, dotPos, dotProgress, partialPath, toSvg,
  type Dot, type Pt, type Scene,
} from '../playbook/geometry'

export interface TeamColors {
  abbr: string
  color: string
  color2: string
}

interface Props {
  scene: Scene
  t: number // 0 a 1
  main: TeamColors // equipo del usuario
  rival: TeamColors | null
  view: 'zoom' | 'full'
  yardsToGo: number
}

function luminancia(hex: string): number {
  const h = hex.replace('#', '')
  const n = parseInt(h.length === 3 ? h.split('').map((c) => c + c).join('') : h, 16)
  const [r, g, b] = [(n >> 16) & 255, (n >> 8) & 255, n & 255].map((v) => {
    const s = v / 255
    return s <= 0.03928 ? s / 12.92 : Math.pow((s + 0.055) / 1.055, 2.4)
  })
  return 0.2126 * r + 0.7152 * g + 0.0722 * b
}

const textoSobre = (fondo: string) => (luminancia(fondo) > 0.4 ? '#111111' : '#ffffff')

function ventana(scene: Scene, view: 'zoom' | 'full'): [number, number] {
  if (view === 'full') return [0, FIELD_LENGTH]
  let [a, b] = scene.focusX ?? [scene.xLos - 18, scene.xLos + 46]
  a -= 2
  b += 2
  const ancho = Math.max(b - a, 44)
  if (b - a < ancho) b = a + ancho
  a = clamp(a, 0, FIELD_LENGTH - ancho)
  b = Math.min(FIELD_LENGTH, Math.max(b, a + ancho))
  return [a, b]
}

const p2 = (p: Pt) => `${p.x.toFixed(2)},${p.y.toFixed(2)}`

function flecha(path: Pt[]): string | null {
  if (path.length < 2) return null
  const fin = path[path.length - 1]
  let prev = path[path.length - 2]
  for (let i = path.length - 2; i >= 0; i--) {
    prev = path[i]
    if (Math.hypot(fin.x - prev.x, fin.y - prev.y) > 0.3) break
  }
  const dx = fin.x - prev.x
  const dy = fin.y - prev.y
  const l = Math.hypot(dx, dy)
  if (l < 0.01) return null
  const ux = dx / l
  const uy = dy / l
  const L = 1.0
  const W = 0.45
  const base = { x: fin.x - ux * L, y: fin.y - uy * L }
  const a = { x: base.x - uy * W, y: base.y + ux * W }
  const b = { x: base.x + uy * W, y: base.y - ux * W }
  return `${p2(fin)} ${p2(a)} ${p2(b)}`
}

export default function FieldView({ scene, t, main, rival, view, yardsToGo }: Props) {
  const [x0, x1] = ventana(scene, view)
  const zoom = view === 'zoom'
  const xLos = scene.xLos
  const aSvg = (p: Pt) => toSvg(p, xLos)
  const colorDe = (d: Dot) => (d.ghost ? rival ?? { abbr: '', color: '#6b7280', color2: '#ffffff' } : main)

  // Zona de anotación que ataca la ofensiva (derecha)
  const derecha = scene.mainUnit === 'off' ? rival : main
  const izquierda = scene.mainUnit === 'off' ? main : rival
  const ezIzq = izquierda ?? { abbr: '', color: '#374151', color2: '#fff' }
  const ezDer = derecha ?? { abbr: '', color: '#374151', color2: '#fff' }

  const lineaPrimerDown = Math.min(xLos + yardsToGo, FIELD_LENGTH - END_ZONE)
  const num = (x: number) => (x <= 60 ? x - 10 : 110 - x)

  const franjas: number[] = []
  for (let x = END_ZONE; x < FIELD_LENGTH - END_ZONE; x += 5) franjas.push(x)

  const hash: number[] = []
  for (let x = END_ZONE + 1; x < FIELD_LENGTH - END_ZONE; x++) if (x % 5 !== 0) hash.push(x)

  const bola = ballState(scene, t)
  const bp = aSvg(bola.p)
  const dotsOrdenados = [...scene.dots].sort((a, b) => Number(b.ghost) - Number(a.ghost)) // el rival debajo
  const posiciones = new Map(scene.dots.map((d) => [d.id, dotPos(d, t)]))

  return (
    <svg
      viewBox={`${x0} 0 ${x1 - x0} ${FIELD_WIDTH}`}
      className="w-full rounded-lg border border-gray-300 bg-green-800"
      role="img"
      aria-label={`Campo de futbol americano en vista aérea: ${scene.title}`}
    >
      {/* Césped con franjas de 5 yardas */}
      <rect x={0} y={0} width={FIELD_LENGTH} height={FIELD_WIDTH} fill="#2f7d3a" />
      {franjas.map((x, i) => (
        <rect key={x} x={x} y={0} width={5} height={FIELD_WIDTH} fill={i % 2 ? '#2b7536' : '#34853f'} />
      ))}

      {/* Zonas de anotación (10 yardas) */}
      <rect x={0} y={0} width={END_ZONE} height={FIELD_WIDTH} fill={ezIzq.color} opacity={0.9} />
      <rect x={FIELD_LENGTH - END_ZONE} y={0} width={END_ZONE} height={FIELD_WIDTH} fill={ezDer.color} opacity={0.9} />
      <text x={5} y={MID_Y} transform={`rotate(-90 5 ${MID_Y})`} textAnchor="middle" dominantBaseline="central"
        fontSize={4.2} fontWeight={700} fill={textoSobre(ezIzq.color)} letterSpacing={0.4}>{ezIzq.abbr}</text>
      <text x={FIELD_LENGTH - 5} y={MID_Y} transform={`rotate(90 ${FIELD_LENGTH - 5} ${MID_Y})`} textAnchor="middle"
        dominantBaseline="central" fontSize={4.2} fontWeight={700} fill={textoSobre(ezDer.color)} letterSpacing={0.4}>{ezDer.abbr}</text>

      {/* Líneas cada 5 yardas, línea de gol y de media cancha */}
      {Array.from({ length: 21 }, (_, i) => END_ZONE + i * 5).map((x) => (
        <line key={x} x1={x} y1={0} x2={x} y2={FIELD_WIDTH} stroke="#fff"
          strokeWidth={x === END_ZONE || x === FIELD_LENGTH - END_ZONE ? 0.3 : x === 60 ? 0.22 : 0.14} opacity={0.9} />
      ))}
      <line x1={0} y1={0.15} x2={FIELD_LENGTH} y2={0.15} stroke="#fff" strokeWidth={0.3} />
      <line x1={0} y1={FIELD_WIDTH - 0.15} x2={FIELD_LENGTH} y2={FIELD_WIDTH - 0.15} stroke="#fff" strokeWidth={0.3} />

      {/* Hash marks a 70 pies 9 pulgadas de cada banda (23.58 yd) y marcas en las bandas */}
      {hash.map((x) => (
        <g key={x} stroke="#fff" strokeWidth={0.1} opacity={0.85}>
          <line x1={x} y1={HASH_FROM_SIDELINE - 0.33} x2={x} y2={HASH_FROM_SIDELINE + 0.33} />
          <line x1={x} y1={FIELD_WIDTH - HASH_FROM_SIDELINE - 0.33} x2={x} y2={FIELD_WIDTH - HASH_FROM_SIDELINE + 0.33} />
          <line x1={x} y1={0.3} x2={x} y2={1.0} />
          <line x1={x} y1={FIELD_WIDTH - 1.0} x2={x} y2={FIELD_WIDTH - 0.3} />
        </g>
      ))}

      {/* Números de yardas */}
      {Array.from({ length: 9 }, (_, i) => 20 + i * 10).map((x) => (
        <g key={x} fill="#fff" opacity={0.8} fontSize={2.6} fontWeight={700} textAnchor="middle" dominantBaseline="central">
          <text x={x} y={9.5} transform={`rotate(180 ${x} 9.5)`}>{num(x)}</text>
          <text x={x} y={FIELD_WIDTH - 9.5}>{num(x)}</text>
        </g>
      ))}

      {/* Postes (6.17 yd de ancho) al fondo de cada zona de anotación */}
      {[0.25, FIELD_LENGTH - 0.25].map((x) => (
        <g key={x} stroke="#fdd835" strokeWidth={0.3}>
          <line x1={x} y1={MID_Y - GOAL_POST_WIDTH / 2} x2={x} y2={MID_Y + GOAL_POST_WIDTH / 2} />
          <circle cx={x} cy={MID_Y - GOAL_POST_WIDTH / 2} r={0.28} fill="#fdd835" />
          <circle cx={x} cy={MID_Y + GOAL_POST_WIDTH / 2} r={0.28} fill="#fdd835" />
        </g>
      ))}

      {/* Zonas de cobertura */}
      {scene.zones.map((z) => {
        const c = aSvg({ x: z.cx, y: z.cy })
        const col = '#ffffff'
        return (
          <g key={z.id} opacity={scene.mainUnit === 'def' ? 1 : 0.6}>
            <ellipse cx={c.x} cy={c.y} rx={z.rx} ry={z.ry} fill={col} fillOpacity={0.07} stroke={col} strokeOpacity={0.55}
              strokeWidth={0.14} strokeDasharray="0.6 0.4" />
            {zoom && (
              <text x={c.x} y={c.y} textAnchor="middle" dominantBaseline="central" fontSize={1.2} fill="#fff" opacity={0.9}>{z.label}</text>
            )}
          </g>
        )
      })}

      {/* Línea de golpeo y línea de primer down */}
      <line x1={xLos} y1={0} x2={xLos} y2={FIELD_WIDTH} stroke="#42a5f5" strokeWidth={0.28} />
      <line x1={lineaPrimerDown} y1={0} x2={lineaPrimerDown} y2={FIELD_WIDTH} stroke="#fdd835" strokeWidth={0.28} />
      {zoom && (
        <g fontSize={1.1} fill="#fff" fontWeight={600}>
          <text x={xLos - 0.4} y={2.2} textAnchor="end">LOS</text>
          <text x={lineaPrimerDown + 0.4} y={2.2}>1.er down</text>
        </g>
      )}

      {/* Rutas planeadas (punteadas), recorrido (sólido) y puntas de flecha */}
      {dotsOrdenados.map((d) => {
        if (d.path.length < 2) return null
        if (d.kind === 'ol' && !d.ghost) return null
        const col = d.unit === 'off' ? '#ffffff' : '#ffd54f'
        const op = d.ghost ? 0.4 : 0.95
        const plan = d.path.map(aSvg)
        const hecho = partialPath(d.path, dotProgress(d, t)).map(aSvg)
        const punta = flecha(plan)
        return (
          <g key={`r-${d.id}`} opacity={op}>
            <polyline points={plan.map(p2).join(' ')} fill="none" stroke={col} strokeWidth={0.14} strokeDasharray="0.5 0.4" />
            {hecho.length > 1 && <polyline points={hecho.map(p2).join(' ')} fill="none" stroke={col} strokeWidth={0.28} />}
            {punta && <polygon points={punta} fill={col} />}
          </g>
        )
      })}

      {/* Marca hombre a hombre */}
      {scene.dots.filter((d) => d.assignedTo).map((d) => {
        const a = posiciones.get(d.id)
        const b = d.assignedTo ? posiciones.get(d.assignedTo) : undefined
        if (!a || !b) return null
        const pa = aSvg(a)
        const pb = aSvg(b)
        return (
          <line key={`m-${d.id}`} x1={pa.x} y1={pa.y} x2={pb.x} y2={pb.y} stroke="#ef5350" strokeWidth={0.18}
            strokeDasharray="0.4 0.3" opacity={d.ghost ? 0.5 : 0.95} />
        )
      })}

      {/* Jugadores: ofensiva = círculo, defensiva = cuadro redondeado */}
      {dotsOrdenados.map((d) => {
        const c = colorDe(d)
        const p = aSvg(posiciones.get(d.id) ?? d.start)
        const r = d.kind === 'ol' ? 0.6 : 0.68
        const op = d.ghost ? 0.72 : 1
        return (
          <g key={d.id} opacity={op}>
            {d.unit === 'off' ? (
              <circle cx={p.x} cy={p.y} r={r} fill={c.color} stroke={d.kind === 'qb' ? '#fdd835' : '#fff'}
                strokeWidth={d.kind === 'qb' ? 0.25 : 0.14} />
            ) : (
              <rect x={p.x - r} y={p.y - r} width={r * 2} height={r * 2} rx={0.25} fill={c.color} stroke="#fff" strokeWidth={0.14} />
            )}
            {zoom && (
              <text x={p.x} y={p.y} textAnchor="middle" dominantBaseline="central" fontSize={d.label.length > 2 ? 0.55 : 0.7}
                fontWeight={700} fill={textoSobre(c.color)}>{d.label}</text>
            )}
          </g>
        )
      })}

      {/* Balón con sombra según su altura */}
      <ellipse cx={bp.x + bola.lift * 0.5} cy={bp.y + bola.lift * 0.9} rx={0.38} ry={0.22} fill="#000" opacity={0.25 * (bola.lift > 0 ? 1 : 0)} />
      <ellipse cx={bp.x} cy={bp.y - bola.lift * 0.4} rx={0.5 * (1 + bola.lift * 0.6)} ry={0.32 * (1 + bola.lift * 0.6)}
        fill="#8d5524" stroke="#fff" strokeWidth={0.1} />

      {/* Escala */}
      {zoom && (
        <g transform={`translate(${x0 + 1.5} ${FIELD_WIDTH - 2.2})`} fill="#fff" fontSize={1}>
          <line x1={0} y1={0} x2={10} y2={0} stroke="#fff" strokeWidth={0.25} />
          <line x1={0} y1={-0.4} x2={0} y2={0.4} stroke="#fff" strokeWidth={0.2} />
          <line x1={10} y1={-0.4} x2={10} y2={0.4} stroke="#fff" strokeWidth={0.2} />
          <text x={5} y={-0.8} textAnchor="middle">10 yardas</text>
        </g>
      )}
    </svg>
  )
}
