import { useEffect, useRef, useState } from 'react'
import { getTeam } from '../api'
import type { TeamProfile, TeamSummary } from '../types'
import TeamCard from './TeamCard'

interface Props {
  teams: TeamSummary[]
  initialTeam: string | null
  initialOpponent: string | null
  onConfirm: (team: string, opponent: string) => void
}

const DIVISIONES = ['Este', 'Norte', 'Sur', 'Oeste']

function Selector({ titulo, teams, value, bloqueado, onChange }: {
  titulo: string
  teams: TeamSummary[]
  value: string | null
  bloqueado: string | null
  onChange: (abbr: string) => void
}) {
  return (
    <section aria-label={titulo} className="rounded-lg border border-gray-200 bg-white p-3 shadow-sm">
      <h2 className="mb-2 text-sm font-semibold text-gray-900">{titulo}</h2>
      {(['AFC', 'NFC'] as const).map((conf) => (
        <div key={conf} className="mb-2">
          <p className="mb-1 text-xs font-semibold text-gray-500">{conf}</p>
          <div className="grid grid-cols-2 gap-x-3 gap-y-1 sm:grid-cols-4">
            {DIVISIONES.map((div) => (
              <div key={div}>
                <p className="text-[10px] uppercase text-gray-400">{div}</p>
                <div className="flex flex-col gap-1">
                  {teams
                    .filter((t) => t.info.conference === conf && t.info.division === div)
                    .map((t) => {
                      const activo = value === t.info.abbr
                      const off = bloqueado === t.info.abbr
                      return (
                        <button
                          key={t.info.abbr}
                          type="button"
                          disabled={off}
                          aria-pressed={activo}
                          title={t.info.name}
                          onClick={() => onChange(t.info.abbr)}
                          className={`flex items-center gap-1 rounded border px-1.5 py-1 text-left text-xs transition ${
                            activo ? 'border-gray-900 bg-gray-100 font-bold ring-1 ring-gray-900' : 'border-gray-200 hover:bg-gray-50'
                          } ${off ? 'cursor-not-allowed opacity-30' : ''}`}
                        >
                          <span className="inline-block h-3 w-3 shrink-0 rounded-full border border-gray-300"
                            style={{ background: `linear-gradient(135deg, ${t.info.color} 50%, ${t.info.color2} 50%)` }} />
                          <span className="truncate">{t.info.abbr}</span>
                        </button>
                      )
                    })}
                </div>
              </div>
            ))}
          </div>
        </div>
      ))}
    </section>
  )
}

export default function TeamMenu({ teams, initialTeam, initialOpponent, onConfirm }: Props) {
  const [team, setTeam] = useState<string | null>(initialTeam)
  const [opponent, setOpponent] = useState<string | null>(initialOpponent)
  const [perfiles, setPerfiles] = useState<Record<string, TeamProfile>>({})
  const [error, setError] = useState<string | null>(null)

  const pedidos = useRef(new Set<string>())

  useEffect(() => {
    for (const abbr of [team, opponent]) {
      if (abbr && !pedidos.current.has(abbr)) {
        pedidos.current.add(abbr)
        getTeam(abbr)
          .then((p) => setPerfiles((prev) => ({ ...prev, [abbr]: p })))
          .catch(() => {
            pedidos.current.delete(abbr)
            setError(`No se pudo cargar el perfil de ${abbr}.`)
          })
      }
    }
  }, [team, opponent])

  return (
    <div className="space-y-4">
      <div>
        <h2 className="text-xl font-bold text-gray-900">Elige el partido</h2>
        <p className="text-sm text-gray-600">
          Selecciona con qué equipo quieres probar y contra cuál. Las recomendaciones se ajustan a las tendencias de ambos.
        </p>
      </div>

      <div className="grid gap-4 lg:grid-cols-2">
        <Selector titulo="Tu equipo" teams={teams} value={team} bloqueado={opponent} onChange={setTeam} />
        <Selector titulo="Equipo rival" teams={teams} value={opponent} bloqueado={team} onChange={setOpponent} />
      </div>

      {error && <p role="alert" className="rounded border border-red-300 bg-red-50 p-2 text-sm text-red-700">{error}</p>}

      <div className="grid gap-4 md:grid-cols-2">
        {team ? <TeamCard perfil={perfiles[team] ?? null} rol="Tu equipo" /> : <Vacio texto="Elige tu equipo" />}
        {opponent ? <TeamCard perfil={perfiles[opponent] ?? null} rol="Rival" /> : <Vacio texto="Elige el equipo rival" />}
      </div>

      <div className="flex items-center justify-between gap-3">
        <p className="text-xs text-gray-500">
          Estadísticas de las temporadas 2021 a 2023 (nflverse) y de Big Data Bowl 2021, semanas 1 a 8 (coberturas y formaciones).
        </p>
        <button
          type="button"
          disabled={!team || !opponent}
          onClick={() => team && opponent && onConfirm(team, opponent)}
          className="rounded bg-green-800 px-5 py-2 text-sm font-semibold text-white hover:bg-green-900 disabled:cursor-not-allowed disabled:opacity-50"
        >
          Continuar
        </button>
      </div>
    </div>
  )
}

function Vacio({ texto }: { texto: string }) {
  return <div className="rounded-lg border border-dashed border-gray-300 p-6 text-center text-sm text-gray-400">{texto}</div>
}
