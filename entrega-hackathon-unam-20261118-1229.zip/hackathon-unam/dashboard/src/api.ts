import type { Meta, RecommendRequest, RecommendResponse, TeamProfile, TeamSummary } from './types'

// Rutas relativas SIN diagonal inicial: la app se publica en una subruta.
async function leer<T>(r: Response): Promise<T> {
  if (r.ok) return (await r.json()) as T
  let msg = `Error ${r.status}`
  try {
    const body = await r.json()
    if (Array.isArray(body.detail)) {
      msg = body.detail
        .map((d: { loc?: string[]; msg: string }) => `${(d.loc ?? []).slice(1).join('.')}: ${d.msg}`)
        .join('; ')
    } else if (typeof body.detail === 'string') {
      msg = body.detail
    }
  } catch {
    /* cuerpo no JSON */
  }
  throw new Error(msg)
}

export async function getMeta(): Promise<Meta> {
  return leer<Meta>(await fetch('api/meta'))
}

export async function getTeams(): Promise<TeamSummary[]> {
  return leer<TeamSummary[]>(await fetch('api/teams'))
}

export async function getTeam(abbr: string): Promise<TeamProfile> {
  return leer<TeamProfile>(await fetch(`api/teams/${encodeURIComponent(abbr)}`))
}

export async function recommend(req: RecommendRequest): Promise<RecommendResponse> {
  return leer<RecommendResponse>(
    await fetch('api/recommend', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(req),
    }),
  )
}
