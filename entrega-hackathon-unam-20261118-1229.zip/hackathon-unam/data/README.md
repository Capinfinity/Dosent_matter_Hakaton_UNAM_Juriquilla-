# Datos

Todo se genera con `.venv/bin/python scripts/prepare_data.py` (usa `--force` para descargar de nuevo).
Los archivos originales de Big Data Bowl no se modifican. La app solo lee estos archivos.

## Fuentes

| Archivo | Fuente | Contenido |
|---|---|---|
| `games.csv` | [Big Data Bowl (repositorio del equipo)](https://github.com/ThompsonJamesBliss/nfl-big-data-bowl-regional-event-data/tree/main/data) | Juegos de 2021, semanas 1 a 8 |
| `plays.csv` | idem | Solo jugadas de pase (dropbacks), con cobertura PFF, formación, personal y defensores en la caja |
| `pffScoutingData.csv` | idem | Datos PFF por jugador y jugada (no los usa la app por ahora) |
| `nflverse_pbp_filtered.csv` | [nflverse-data](https://github.com/nflverse/nflverse-data/releases/tag/pbp), 2018 a 2023 | Play-by-play filtrado (derivado) |

## Unión BDB y nflverse

`gameId` = `old_game_id` y `playId` = `play_id`. En 2021, 8.034 de 8.557 jugadas de BDB (93,9 %) tienen pareja.

## Columnas de `nflverse_pbp_filtered.csv`

Solo se conservan jugadas `pass`, `run`, `punt` y `field_goal` con down, `yardline_100` y EPA.

- Identificación: `season`, `week`, `old_game_id`, `play_id`, `posteam`, `defteam`
- Situación: `qtr`, `down`, `ydstogo`, `yardline_100` (yardas a la zona de anotación rival), `game_seconds_remaining`, `half_seconds_remaining`, `score_differential` (del equipo en posesión), `posteam_timeouts_remaining`, `defteam_timeouts_remaining`
- Jugada: `play_type`, `pass_length` (short/deep), `pass_location`, `run_location`, `yards_gained`, `qb_scramble`, `sack`, `interception`, `touchdown`, `penalty`
- Valor: `epa`, `wp`, `wpa`, `success`
- 4º down y pateos: `fourth_down_converted`, `fourth_down_failed`, `field_goal_result`, `kick_distance`, `return_yards`, `punt_blocked`

## Limitaciones conocidas

- nflverse **no** trae cobertura, formación ni defensores en la caja en este archivo. Esos datos solo existen en BDB (pases de 2021, semanas 1 a 8).
- BDB no tiene carreras ni pateos. Esos salen de nflverse.
- Con una sola ventana de 8 semanas hay pocas jugadas por combinación de cobertura y formación. La app muestra el tamaño de muestra.

## Validación contra la base de conocimiento

`.venv/bin/python scripts/check_data_quality.py` cruza las 8.034 jugadas de Big Data Bowl que tienen pareja en nflverse (2021) y compara down, distancia, cuarto, reloj, marcador, posición en el campo y posesión: **0 diferencias** en todos. La única diferencia es esperada: `playResult` de BDB incluye castigos y `yards_gained` de nflverse no (155 jugadas, 1,9 %).

Detalles de los datos que la app ya trata:

- Los CSV de la carpeta `Datos/` son idénticos a los de `data/`.
- Los 32 equipos usan las mismas abreviaturas en todas las fuentes (por ejemplo `LA` y `LV`).
- 523 jugadas de BDB (6,1 %) no tienen pareja en nflverse y no entran en los cálculos de EPA.
- `defendersInBox` trae valores poco creíbles (1 o 2 defensores en 6 jugadas); el motor solo recomienda cajas de 5 a 8.
- Hay coberturas especiales (Prevent, Red Zone, Goal Line, Bracket, Miscellaneous) que no son una elección comparable, por lo que no se ofrecen como recomendación defensiva.
- La fórmula de la base de conocimiento para la distancia de gol de campo (yardas a la línea de gol + 17) es la que usa el motor de 4º down.
