"""Clasificación de los datos por equipo: jugadas preferidas, jugadas más efectivas y ajustes.

Fuentes:
- nflverse (temporadas TEAM_SEASONS): carreras y pases por zona y profundidad, con EPA.
- Big Data Bowl 2021 (semanas 1 a 8): formación, cobertura, resultado de pase, presión y blitz.

Definiciones:
- Jugada preferida: la de mayor uso del equipo (ofensiva: entre 9 tipos de jugada; defensiva: entre las
  coberturas Man o Zone).
- Jugada más efectiva: mayor EPA a favor (ofensiva) o menor EPA permitido (defensiva), con el EPA
  suavizado hacia el promedio de la liga para no premiar muestras pequeñas, y con muestra mínima.
- Los ajustes («deltas») que usan los motores son la diferencia entre el equipo y la liga, atenuada por la muestra.
"""
from __future__ import annotations

from dataclasses import dataclass, field

import pandas as pd

from backend.schemas import (
    DefenseProfile, OffenseProfile, PlayStat, TeamInfo, TeamProfile, TeamSummary,
)
from backend.teams import TEAMS

TEAM_SEASONS = (2021, 2022, 2023)  # temporadas recientes: los equipos cambian de un año a otro

K_CAT = 40         # suavizado del EPA por tipo de jugada (jugadas virtuales de la liga)
K_COBERTURA = 30   # suavizado del EPA permitido por cobertura
K_FORMACION = 30
K_DELTA = 100      # atenuación de los ajustes por tipo (carrera, pase corto, pase largo)
K_DELTA_COB = 40
K_CONV = 20        # atenuación del ajuste de conversión en 4º down
MIN_EFECTIVA = 30  # muestra mínima para nombrar una jugada «más efectiva» (ofensiva)
MIN_EFECTIVA_COB = 25

POSICIONES = ("left", "middle", "right")
_LADO = {"left": "a la izquierda", "middle": "al centro", "right": "a la derecha"}
_LADO_CARRERA = {"left": "por la izquierda", "middle": "por el centro", "right": "por la derecha"}

# id -> (etiqueta, tipo para los ajustes)
CATEGORIAS: dict[str, tuple[str, str]] = {}
for _p in POSICIONES:
    CATEGORIAS[f"run_{_p}"] = (f"Carrera {_LADO_CARRERA[_p]}", "run")
for _p in POSICIONES:
    CATEGORIAS[f"pass_short_{_p}"] = (f"Pase corto {_LADO[_p]}", "pass_short")
for _p in POSICIONES:
    CATEGORIAS[f"pass_deep_{_p}"] = (f"Pase largo {_LADO[_p]}", "pass_deep")

TIPOS = ("run", "pass_short", "pass_deep")


@dataclass
class TeamStats:
    profiles: dict[str, TeamProfile] = field(default_factory=dict)
    off_delta: dict[str, dict[str, float]] = field(default_factory=dict)   # equipo -> tipo -> delta de EPA
    def_delta: dict[str, dict[str, float]] = field(default_factory=dict)   # equipo -> tipo -> delta de EPA permitido
    cov_delta: dict[str, dict[str, float]] = field(default_factory=dict)   # equipo -> cobertura -> delta EPA permitido
    cov_mix: dict[str, dict[str, float]] = field(default_factory=dict)     # equipo -> cobertura -> proporción de uso
    form_mix: dict[str, dict[str, float]] = field(default_factory=dict)    # equipo -> formación -> proporción de uso
    conv_off: dict[str, float] = field(default_factory=dict)               # 4º down: conversión sobre lo esperado
    conv_def: dict[str, float] = field(default_factory=dict)               # 4º down: conversión permitida sobre lo esperado

    def summaries(self) -> list[TeamSummary]:
        out = []
        for abbr in sorted(self.profiles):
            p = self.profiles[abbr]
            out.append(TeamSummary(
                info=p.info,
                preferred_offense=p.offense.preferred.label if p.offense.preferred else None,
                most_effective_offense=p.offense.most_effective.label if p.offense.most_effective else None,
                preferred_defense=p.defense.preferred_coverage.label if p.defense.preferred_coverage else None,
                most_effective_defense=p.defense.most_effective_coverage.label if p.defense.most_effective_coverage else None,
            ))
        return out


# ---------------------------------------------------------------- utilidades
def categorizar(pbp: pd.DataFrame) -> pd.Series:
    """Asigna a cada jugada uno de los 9 tipos (o NA). Las capturas y los scrambles se excluyen."""
    cat = pd.Series(pd.NA, index=pbp.index, dtype="object")
    corre = (pbp["play_type"] == "run") & (pbp["qb_scramble"] != 1) & pbp["run_location"].isin(POSICIONES)
    cat[corre] = "run_" + pbp.loc[corre, "run_location"]
    pasa = (
        (pbp["play_type"] == "pass") & (pbp["sack"] != 1)
        & pbp["pass_length"].isin(["short", "deep"]) & pbp["pass_location"].isin(POSICIONES)
    )
    cat[pasa] = "pass_" + pbp.loc[pasa, "pass_length"] + "_" + pbp.loc[pasa, "pass_location"]
    return cat


def _suavizar(n: int, valor: float, liga: float, k: float) -> float:
    return (n * valor + k * liga) / (n + k)


def _stat(id_: str, label: str, sub: pd.DataFrame, total: int, liga: float, k: float,
          liga_share: float = 0.0) -> PlayStat:
    n = int(len(sub))
    epa = float(sub["epa"].mean()) if n else 0.0
    share = (n / total) if total else 0.0
    epa_adj = _suavizar(n, epa, liga, k)
    return PlayStat(
        id=id_, label=label, n=n, share=share, epa=epa, epa_adj=epa_adj,
        success_rate=float(sub["success"].mean()) if n and sub["success"].notna().any() else 0.0,
        lift=share - liga_share, edge=epa_adj - liga,
    )


def _tasa(serie: pd.Series) -> float | None:
    return float(serie.mean()) if len(serie) else None


def _bucket_distancia(d: pd.Series) -> pd.Series:
    return pd.cut(d, bins=[0, 1, 2, 4, 7, 100], labels=["1", "2", "3-4", "5-7", "8+"])


# ---------------------------------------------------------------- construcción
def build_team_stats(pbp: pd.DataFrame, bdb: pd.DataFrame) -> TeamStats:
    ts = TeamStats()

    reciente = pbp[pbp["season"].isin(TEAM_SEASONS)].copy()
    reciente["cat"] = categorizar(reciente)
    reciente["tipo"] = reciente["cat"].map(lambda c: CATEGORIAS[c][1] if isinstance(c, str) else pd.NA)
    cat = reciente[reciente["cat"].notna()]
    liga_cat = cat.groupby("cat")["epa"].mean()
    liga_tipo = cat.groupby("tipo")["epa"].mean()

    share_cat = cat["cat"].value_counts(normalize=True)

    b = bdb[bdb["matched"]]
    liga_cob = b.groupby("pff_passCoverage")["epa"].mean()
    liga_form = b.groupby("offenseFormation")["epa"].mean()
    share_cob = b["pff_passCoverage"].value_counts(normalize=True)
    share_form = b["offenseFormation"].value_counts(normalize=True)

    # 4º down: conversión esperada según la distancia (liga, todas las temporadas)
    go = pbp[(pbp["down"] == 4) & pbp["play_type"].isin(["pass", "run"]) & pbp["fourth_down_converted"].notna()].copy()
    go["bucket"] = _bucket_distancia(go["ydstogo"])
    go["conv"] = (go["fourth_down_converted"] == 1).astype(float)
    esperado = go.groupby("bucket", observed=True)["conv"].mean()
    go["sobre"] = go["conv"] - go["bucket"].map(esperado).astype(float)

    for abbr, info in TEAMS.items():
        # ---------- ofensiva (nflverse)
        o = cat[cat["posteam"] == abbr]
        d = cat[cat["defteam"] == abbr]
        todas_o = reciente[reciente["posteam"] == abbr]
        n_corr = int((todas_o["play_type"] == "run").sum())
        n_pase = int((todas_o["play_type"] == "pass").sum())
        categorias = [
            _stat(cid, CATEGORIAS[cid][0], o[o["cat"] == cid], len(o), float(liga_cat[cid]), K_CAT,
                  float(share_cat[cid]))
            for cid in CATEGORIAS
        ]
        preferida = max(categorias, key=lambda s: s.n) if len(o) else None
        sello = max(categorias, key=lambda s: s.lift) if len(o) else None
        efectivas = [s for s in categorias if s.n >= MIN_EFECTIVA]
        mejor = max(efectivas, key=lambda s: s.epa_adj) if efectivas else None
        fortaleza = max(efectivas, key=lambda s: s.edge) if efectivas else None

        # ---------- ofensiva (BDB)
        bo = bdb[bdb["possessionTeam"] == abbr]
        bom = b[b["possessionTeam"] == abbr]
        formaciones = [
            _stat(str(f), str(f), g, len(bom), float(liga_form[f]), K_FORMACION, float(share_form[f]))
            for f, g in bom.groupby("offenseFormation") if f in liga_form.index
        ]
        formaciones.sort(key=lambda s: s.n, reverse=True)
        intentos = bo["passResult"].isin(["C", "I", "IN"])
        passing = {
            "completion_pct": _tasa((bo.loc[intentos, "passResult"] == "C").astype(float)),
            "interception_rate": _tasa((bo.loc[intentos, "passResult"] == "IN").astype(float)),
            "sack_rate": _tasa((bo["passResult"] == "S").astype(float)),
            "yards_per_play": _tasa(bo["playResult"]),
            "play_action_rate": _tasa(bo["pff_playAction"].astype(float)),
            "dropbacks_bdb": float(len(bo)),
        }

        # ---------- defensiva (nflverse)
        cobertura_nfl = reciente[reciente["defteam"] == abbr]
        vulnerabilidad = None
        if len(d):
            tipos_perm = [
                _stat(cid, CATEGORIAS[cid][0], d[d["cat"] == cid], len(d), float(liga_cat[cid]), K_CAT,
                      float(share_cat[cid]))
                for cid in CATEGORIAS
            ]
            cand = [s for s in tipos_perm if s.n >= MIN_EFECTIVA]
            vulnerabilidad = max(cand, key=lambda s: s.epa_adj) if cand else None

        # ---------- defensiva (BDB)
        bd = bdb[bdb["defensiveTeam"] == abbr]
        bdm = b[b["defensiveTeam"] == abbr]
        coberturas: list[PlayStat] = []
        for c, g in bdm.groupby("pff_passCoverage"):
            tipo = g["pff_passCoverageType"].dropna().mode()
            etiqueta = f"{c} ({tipo.iloc[0]})" if len(tipo) else str(c)
            # share sobre todas las jugadas BDB del equipo con cobertura registrada
            coberturas.append(_stat(str(c), etiqueta, g, len(bdm), float(liga_cob[c]), K_COBERTURA,
                                    float(share_cob[c])))
        coberturas.sort(key=lambda s: s.n, reverse=True)
        elegibles = [s for s in coberturas if s.label.endswith(("(Man)", "(Zone)"))]
        pref_c = elegibles[0] if elegibles else None
        sello_c = max(elegibles, key=lambda s: s.lift) if elegibles else None
        efect_c = [s for s in elegibles if s.n >= MIN_EFECTIVA_COB]
        mejor_c = min(efect_c, key=lambda s: s.epa_adj) if efect_c else None
        n_mz = int(bdm["pff_passCoverageType"].isin(["Man", "Zone"]).sum())
        intentos_d = bd["passResult"].isin(["C", "I", "IN"])
        passing_perm = {
            "completion_pct": _tasa((bd.loc[intentos_d, "passResult"] == "C").astype(float)),
            "interception_rate": _tasa((bd.loc[intentos_d, "passResult"] == "IN").astype(float)),
            "sack_rate": _tasa((bd["passResult"] == "S").astype(float)),
            "yards_per_play": _tasa(bd["playResult"]),
        }

        ts.profiles[abbr] = TeamProfile(
            info=info,
            seasons=list(TEAM_SEASONS),
            offense=OffenseProfile(
                plays=int(len(todas_o)),
                pass_rate=(n_pase / (n_pase + n_corr)) if (n_pase + n_corr) else 0.0,
                categories=categorias, preferred=preferida, most_effective=mejor,
                signature=sello, strength=fortaleza,
                formations=formaciones, passing=passing,
            ),
            defense=DefenseProfile(
                plays=int(len(cobertura_nfl)),
                epa_allowed_run=float(cobertura_nfl.loc[cobertura_nfl["play_type"] == "run", "epa"].mean()),
                epa_allowed_pass=float(cobertura_nfl.loc[cobertura_nfl["play_type"] == "pass", "epa"].mean()),
                coverages=coberturas, preferred_coverage=pref_c, most_effective_coverage=mejor_c,
                signature_coverage=sello_c, vulnerability=vulnerabilidad,
                man_rate=(float((bdm["pff_passCoverageType"] == "Man").sum()) / n_mz) if n_mz else None,
                blitz_rate=_tasa((bd["n_rushers"] >= 5).astype(float)) if "n_rushers" in bd else None,
                pressure_rate=_tasa(bd["pressure"].astype(float)) if "pressure" in bd else None,
                passing_allowed=passing_perm,
            ),
        )

        # ---------- ajustes para los motores
        def delta_tipo(df: pd.DataFrame) -> dict[str, float]:
            out = {}
            for t in TIPOS:
                s = df[df["tipo"] == t]
                n = len(s)
                out[t] = (n / (n + K_DELTA)) * (float(s["epa"].mean()) - float(liga_tipo[t])) if n else 0.0
            return out

        ts.off_delta[abbr] = delta_tipo(o)
        ts.def_delta[abbr] = delta_tipo(d)
        ts.cov_delta[abbr] = {
            str(c): (len(g) / (len(g) + K_DELTA_COB)) * (float(g["epa"].mean()) - float(liga_cob[c]))
            for c, g in bdm.groupby("pff_passCoverage") if c in liga_cob.index
        }
        total_cob = float(len(bd["pff_passCoverage"].dropna()))
        ts.cov_mix[abbr] = {
            str(c): n / total_cob for c, n in bd["pff_passCoverage"].value_counts().items()
        } if total_cob else {}
        total_f = float(len(bo["offenseFormation"].dropna()))
        ts.form_mix[abbr] = {
            str(f): n / total_f for f, n in bo["offenseFormation"].value_counts().items()
        } if total_f else {}
        g_o = go[go["posteam"] == abbr]
        g_d = go[go["defteam"] == abbr]
        ts.conv_off[abbr] = float(g_o["sobre"].mean()) * len(g_o) / (len(g_o) + K_CONV) if len(g_o) else 0.0
        ts.conv_def[abbr] = float(g_d["sobre"].mean()) * len(g_d) / (len(g_d) + K_CONV) if len(g_d) else 0.0

    return ts

