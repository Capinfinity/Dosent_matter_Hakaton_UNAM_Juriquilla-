"""Motores de recomendación. `recommend` despacha según el modo."""
from __future__ import annotations

from backend.data_loader import DataStore
from backend.engines.defense import recommend_defense
from backend.engines.fourth_down import recommend_fourth_down
from backend.engines.offense import recommend_offense
from backend.schemas import RecommendRequest, RecommendResponse


def recommend(req: RecommendRequest, store: DataStore) -> RecommendResponse:
    if req.mode == "fourth_down":
        return recommend_fourth_down(req, store)
    if req.mode == "offense":
        return recommend_offense(req, store)
    return recommend_defense(req, store)
