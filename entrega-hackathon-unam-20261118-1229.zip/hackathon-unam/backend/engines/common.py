"""Utilidades compartidas por los motores."""
from __future__ import annotations

import pandas as pd

from backend.schemas import Confidence, Option

MIN_N = 30          # muestra mínima deseada por opción
FACTORES = (1, 2, 3, 4, 6)  # cuántas veces se ensancha la ventana de búsqueda


def confianza(n: int) -> Confidence:
    if n >= 100:
        return "alta"
    if n >= MIN_N:
        return "media"
    return "baja"


UMBRAL_EMPATE = {"WPA": 0.005, "EPA": 0.02}  # diferencia mínima para distinguir la mejor opción


def describir_situacion(score_diff: int, game_seconds: int, quarter: int, clock_seconds: int) -> str:
    """Resume el contexto de marcador y reloj en una frase (para mostrar en pantalla)."""
    if score_diff == 0:
        marcador = "Empatado"
    elif score_diff > 0:
        marcador = "Ganando por más de una anotación" if score_diff >= 9 else "Ganando por una anotación o menos"
    else:
        marcador = "Perdiendo por más de una anotación" if score_diff <= -9 else "Perdiendo por una anotación o menos"

    if quarter == 5:
        reloj = "tiempo extra"
    elif quarter == 4 and game_seconds <= 120:
        reloj = "últimos 2 minutos del juego"
    elif quarter == 2 and clock_seconds <= 120:
        reloj = "últimos 2 minutos del primer tiempo"
    else:
        reloj = f"{quarter}º cuarto"
    return f"{marcador} · {reloj}"


def empate_tecnico(opciones: list[Option]) -> list[str]:
    """Avisa si las dos mejores opciones (ya ordenadas) casi no se distinguen."""
    if len(opciones) < 2:
        return []
    mejor, segunda = opciones[0], opciones[1]
    umbral = UMBRAL_EMPATE.get(mejor.score_metric, 0.0)
    if mejor.score - segunda.score < umbral:
        return [
            f"Empate técnico: «{mejor.label}» y «{segunda.label}» casi no se distinguen en los datos. "
            "Decide con otros criterios (reloj, tiempos fuera, plantel)."
        ]
    return []


def ventana_progresiva(
    df: pd.DataFrame,
    criterios: dict[str, tuple[float, float]],
    min_n: int = MIN_N,
) -> tuple[pd.DataFrame, int]:
    """Busca jugadas similares ensanchando la ventana hasta tener `min_n`.

    criterios: columna -> (valor buscado, ancho base). Una jugada entra si
    |columna - valor| <= ancho_base * factor, para todas las columnas.
    Devuelve (jugadas, factor usado). Si ni con la ventana más ancha se llega a
    `min_n`, devuelve lo que haya en la ventana más ancha.
    """
    sub = df
    for factor in FACTORES:
        mask = pd.Series(True, index=df.index)
        for col, (valor, ancho) in criterios.items():
            mask &= (df[col] - valor).abs() <= ancho * factor
        sub = df[mask]
        if len(sub) >= min_n:
            return sub, factor
    return sub, FACTORES[-1]
