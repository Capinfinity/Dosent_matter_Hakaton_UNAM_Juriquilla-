"""Motor defensivo: qué cobertura (y cuántos defensores en la caja) conviene contra una ofensiva.

Solo Big Data Bowl tiene cobertura, formación y defensores en la caja (pases de 2021,
semanas 1 a 8, unidos con EPA de nflverse). Para cada cobertura:
  1. se toma su EPA permitido promedio en todo BDB, y
  2. se busca el EPA permitido en jugadas similares (down, distancia, yarda, marcador, reloj
     y, si se indica, formación y personal del rival),
  3. se mezcla el EPA de las jugadas similares con el promedio de esa cobertura, dando más
     peso a la situación cuanto mayor sea su muestra (suavizado con K jugadas).
Si se elige un equipo rival y no se indica formación, se promedian las formaciones que usa ese
rival, ponderadas por su frecuencia. Si se elige tu equipo, se suma cuánto más o menos EPA permite
tu defensa con cada cobertura respecto a la liga (atenuado por la muestra).
El valor que se muestra es el EPA evitado = -(EPA permitido). Mayor es mejor para la defensa.
"""
from __future__ import annotations

import pandas as pd

from backend.data_loader import DataStore
from backend.engines.common import MIN_N, confianza, describir_situacion, empate_tecnico, ventana_progresiva
from backend.schemas import Option, RecommendRequest, RecommendResponse

K_SUAVIZADO = 30     # jugadas "virtuales" del promedio general de cada cobertura
MIN_TOTAL = 20       # una cobertura necesita al menos esto en todo BDB para ofrecerse
MIN_TOTAL_CAJA = 100
CAJA_MIN, CAJA_MAX = 5, 8
MIN_CAJA_SITUACION = 15  # jugadas similares mínimas para recomendar una caja
FACTOR_AMPLIO = 3
MIN_SHARE_FORMACION = 0.08  # formaciones del rival que se consideran al mezclar


def _suavizar(total: pd.DataFrame, sit: pd.DataFrame) -> tuple[float, float, int]:
    """Mezcla situación y promedio general. Devuelve (EPA permitido, éxito ofensivo, n situación)."""
    n = len(sit)
    epa_all, suc_all = float(total["epa"].mean()), float(total["success"].mean())
    if n == 0:
        return epa_all, suc_all, 0
    w = n / (n + K_SUAVIZADO)
    return (
        w * float(sit["epa"].mean()) + (1 - w) * epa_all,
        w * float(sit["success"].mean()) + (1 - w) * suc_all,
        n,
    )


def _escenarios(req: RecommendRequest, store: DataStore, b: pd.DataFrame) -> tuple[list[tuple[float, pd.Series]], str | None]:
    """Lista de (peso, filtro de jugadas) y una nota. Un solo escenario salvo que se mezclen formaciones del rival."""
    todo = pd.Series(True, index=b.index)
    if req.formation or req.personnel:
        f = todo.copy()
        if req.formation:
            f &= b["offenseFormation"] == req.formation
        if req.personnel:
            f &= b["personnelO"] == req.personnel
        return [(1.0, f)], None
    if req.opponent:
        mix = {k: s for k, s in store.teams.form_mix.get(req.opponent, {}).items() if s >= MIN_SHARE_FORMACION}
        if mix:
            total = sum(mix.values())
            esc = [(s / total, b["offenseFormation"] == k) for k, s in mix.items()]
            nota = (
                f"Sin formación indicada: se promedian las formaciones de {req.opponent} en Big Data Bowl ("
                + ", ".join(f"{k} {s:.0%}" for k, s in sorted(mix.items(), key=lambda kv: -kv[1])) + ")."
            )
            return esc, nota
    return [(1.0, todo)], None


def recommend_defense(req: RecommendRequest, store: DataStore) -> RecommendResponse:
    b = store.bdb
    b = b[b["matched"] & b["pff_passCoverage"].notna()]  # se conservan las capturas: cuentan a favor de la defensa
    if b.empty:
        raise ValueError("No hay datos de Big Data Bowl disponibles.")

    sd_ofensiva = -req.score_diff  # el marcador del usuario es el de la defensa
    d, y, t = req.yards_to_go, req.yardline_100, req.game_seconds_remaining
    criterios = {
        "yardsToGo": (d, max(2.0, 0.3 * d)),
        "yardline_100": (y, 15),
        "score_differential": (sd_ofensiva, 7),
        "game_seconds_remaining": (t, 600),
    }
    notas = [
        "Solo Big Data Bowl (pases de 2021, semanas 1 a 8) tiene cobertura y caja, así que la muestra es limitada. "
        "El valor es el EPA evitado: mayor es mejor para tu defensa.",
        "«Éxito» es la proporción de jugadas que la defensa evita que sean exitosas para la ofensiva.",
    ]
    if req.rival_coverage:
        notas.append("El dato «cobertura rival» no aplica en modo defensivo y se ignoró.")
    if req.defenders_in_box is not None:
        notas.append("Los defensores en la caja se recomiendan aparte (abajo); el valor que indicaste no filtra.")

    escenarios, nota_mezcla = _escenarios(req, store, b)
    if nota_mezcla:
        notas.append(nota_mezcla)
    unico = len(escenarios) == 1
    filtro_caja = escenarios[0][1] if unico else pd.Series(True, index=b.index)  # caja y Man/Zone: sin mezclar

    def situacion(grupo: pd.DataFrame, filtro: pd.Series) -> tuple[pd.DataFrame, int]:
        g = grupo[(grupo["down"] == req.down) & filtro[grupo.index]]
        return ventana_progresiva(g, criterios)

    # --- Coberturas ---
    # Se ofrecen solo coberturas Man o Zone. Prevent, Red Zone, Goal Line o Bracket son llamadas
    # especiales ligadas a la situación, no una elección entre alternativas comparables.
    ajuste_equipo = store.teams.cov_delta.get(req.team, {}) if req.team else {}
    opciones: list[Option] = []
    factores: dict[str, int] = {}
    excluidas: list[str] = []
    for cob, total in b.groupby("pff_passCoverage"):
        tipo = total["pff_passCoverageType"].dropna().mode()
        if not len(tipo) or tipo.iloc[0] not in ("Man", "Zone"):
            excluidas.append(str(cob))
            continue
        if len(total) < MIN_TOTAL:
            continue
        epa = suc = n_f = 0.0
        f_max = 1
        for peso, filtro in escenarios:
            sit, f = situacion(total, filtro)
            e, s, n = _suavizar(total, sit)
            epa, suc, n_f, f_max = epa + peso * e, suc + peso * s, n_f + peso * n, max(f_max, f)
        n = int(round(n_f))
        eq = float(ajuste_equipo.get(str(cob), 0.0))
        epa += eq
        opciones.append(Option(
            key=str(cob), label=f"{cob} ({tipo.iloc[0]})", score=-epa, score_metric="EPA", success_rate=1 - suc,
            n_samples=n, confidence=confianza(n),
            detail={"epa_permitido": epa, "muestra_total": float(len(total)), "ajuste_equipo": -eq},
        ))
        factores[str(cob)] = f_max
    if not opciones:
        raise ValueError("No hay jugadas similares suficientes para esta situación.")
    opciones.sort(key=lambda o: o.score, reverse=True)
    if excluidas:
        notas.append(f"Se excluyen llamadas especiales que no son una elección comparable: {', '.join(sorted(excluidas))}.")
    if req.team:
        notas.append(
            f"Ajuste por tu equipo ({req.team}): se suma cuánto más o menos EPA permite tu defensa con cada cobertura "
            "frente a la liga en Big Data Bowl (atenuado por la muestra)."
        )

    # --- Defensores en la caja (solo cantidades habituales con muestra suficiente) ---
    mejor_caja = None
    candidatas = []
    habituales = b[b["defendersInBox"].between(CAJA_MIN, CAJA_MAX)]
    for cajas, total in habituales.groupby("defendersInBox"):
        if len(total) < MIN_TOTAL_CAJA:
            continue
        sit, _ = situacion(total, filtro_caja)
        epa, _, n = _suavizar(total, sit)
        if n >= MIN_CAJA_SITUACION:
            candidatas.append((int(cajas), epa, n))
    if candidatas:
        mejor_caja = min(candidatas, key=lambda c: c[1])
        notas.append(
            f"Caja recomendada: {mejor_caja[0]} defensores (EPA permitido {mejor_caja[1]:+.2f}, "
            f"{mejor_caja[2]} jugadas similares)."
        )

    # --- Man contra Zone ---
    mz = []
    for tipo, total in b[b["pff_passCoverageType"].isin(["Man", "Zone"])].groupby("pff_passCoverageType"):
        sit, _ = situacion(total, filtro_caja)
        epa, _, n = _suavizar(total, sit)
        mz.append((str(tipo), epa, n))
    if len(mz) == 2:
        mejor = min(mz, key=lambda m: m[1])
        notas.append(f"Entre Man y Zone, {mejor[0]} permite menos EPA en situaciones similares ({mejor[1]:+.2f}).")

    advertencias: list[str] = []
    pocas = [o.label for o in opciones if o.n_samples < MIN_N]
    anchas = [o.label for o in opciones if o.n_samples >= MIN_N and factores[o.key] >= FACTOR_AMPLIO]
    if pocas:
        advertencias.append(
            "Muestra pequeña (menos de 30 jugadas similares) en: " + ", ".join(pocas)
            + ". Su valor se acerca al promedio general de esa cobertura."
        )
    if anchas:
        advertencias.append("Se amplió bastante el rango de búsqueda en: " + ", ".join(anchas) + ".")
    if len(pocas) == len(opciones):
        advertencias.append("Ninguna cobertura tiene muestra suficiente para esta situación; el orden refleja sobre todo promedios generales.")

    advertencias = empate_tecnico(opciones) + advertencias
    contexto: dict[str, str | int | float] = {
        "situacion": describir_situacion(req.score_diff, t, req.quarter, req.clock_seconds),
        "game_seconds_remaining": t,
        "score_diff_ofensiva": sd_ofensiva,
    }
    if mejor_caja:
        contexto["mejor_caja"] = mejor_caja[0]

    return RecommendResponse(
        mode="defense", best=opciones[0].key, options=opciones,
        notes=notas, warnings=advertencias, context=contexto,
    )
