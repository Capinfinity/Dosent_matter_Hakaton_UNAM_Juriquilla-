"""Motor de 4º down: ir por el primero, gol de campo o despejar.

Método (datos nflverse 2018-2023):
- Ir por el primero y gol de campo se modelan por separado en dos partes:
    valor = p(éxito) * WPA(éxito) + (1 - p(éxito)) * WPA(fracaso)
  La probabilidad p depende sobre todo de la distancia (yardas para el primero, o
  distancia de la patada). El WPA de cada resultado depende de la yarda, el marcador
  y el reloj. Así una distancia larga no se contamina con casos de 4º y 1.
- Despejar es el WPA promedio de despejes en 4º down similares.
WPA = cambio en la probabilidad de victoria del equipo en posesión.
"""
from __future__ import annotations

import pandas as pd

from backend.data_loader import DataStore
from backend.engines.common import MIN_N, confianza, describir_situacion, empate_tecnico, ventana_progresiva
from backend.schemas import Option, RecommendRequest, RecommendResponse

MAX_PATADA_GC = 66       # distancia máxima razonable de gol de campo (yardas)
MIN_YARDLINE_PUNT = 30   # más cerca que esto casi nunca se despeja
MIN_MUESTRA_OPCION = 5   # por debajo de esto no se estima la opción
MIN_N_RESULTADO = 15     # muestra deseada para el WPA de cada resultado (éxito o fracaso)
FACTOR_AMPLIO = 3        # desde este factor se avisa que se ensanchó mucho la búsqueda
AJUSTE_MAX_CONVERSION = 0.10  # tope del ajuste de conversión por equipo (10 puntos porcentuales)


def _binaria(
    plays: pd.DataFrame,
    exito: pd.Series,
    p: float,
    crit_exito: dict[str, tuple[float, float]],
    crit_fracaso: dict[str, tuple[float, float]],
) -> tuple[float, int, int, int] | None:
    """Valor esperado p*WPA(éxito) + (1-p)*WPA(fracaso). Devuelve (valor, n, n_exitos, factor máx)."""
    ok, f1 = ventana_progresiva(plays[exito], crit_exito, MIN_N_RESULTADO)
    ko, f2 = ventana_progresiva(plays[~exito], crit_fracaso, MIN_N_RESULTADO)
    if len(ok) < MIN_MUESTRA_OPCION or len(ko) < MIN_MUESTRA_OPCION:
        return None
    valor = p * float(ok["wpa"].mean()) + (1 - p) * float(ko["wpa"].mean())
    return valor, len(ok) + len(ko), len(ok), max(f1, f2)


def recommend_fourth_down(req: RecommendRequest, store: DataStore) -> RecommendResponse:
    pbp = store.pbp
    d4 = pbp[(pbp["down"] == 4) & pbp["wpa"].notna() & pbp["score_differential"].notna()]

    y, d = req.yardline_100, req.yards_to_go
    estado = {
        "yardline_100": (y, 5),
        "score_differential": (req.score_diff, 3),
        "game_seconds_remaining": (req.game_seconds_remaining, 240),
    }
    opciones: list[Option] = []
    factores: dict[str, int] = {}
    notas = [
        "Estimación empírica con jugadas de 4º down entre 2018 y 2023. El valor es el cambio esperado en "
        "la probabilidad de victoria (WPA). Ir por el primero tiene sesgo de selección: los equipos suelen "
        "intentarlo cuando la situación les favorece.",
    ]
    advertencias: list[str] = []

    # --- Ir por el primero ---
    go = d4[d4["play_type"].isin(["pass", "run"]) & d4["fourth_down_converted"].notna()].copy()
    convertida = go["fourth_down_converted"] == 1
    # p: depende de la distancia y algo de la zona del campo (todas las situaciones de marcador y reloj)
    muestra_p, f_p = ventana_progresiva(go, {"ydstogo": (d, max(1.0, 0.2 * d)), "yardline_100": (y, 15)})
    if len(muestra_p) >= MIN_MUESTRA_OPCION:
        p_go = float((muestra_p["fourth_down_converted"] == 1).mean())
        # Ajuste por equipo: conversión de tu ofensiva y conversión que permite la defensa rival, sobre lo esperado
        ajuste_p = 0.0
        if req.team:
            ajuste_p += store.teams.conv_off[req.team]
        if req.opponent:
            ajuste_p += store.teams.conv_def[req.opponent]
        ajuste_p = max(-AJUSTE_MAX_CONVERSION, min(AJUSTE_MAX_CONVERSION, ajuste_p))
        p_go = min(0.98, max(0.02, p_go + ajuste_p))
        if req.team or req.opponent:
            notas.append(
                f"Ajuste por equipo en la probabilidad de conversión: {ajuste_p * 100:+.1f} puntos porcentuales "
                "(tu ofensiva y la defensa rival frente a lo esperado según la distancia)."
            )
        res = _binaria(
            go, convertida, p_go,
            {**estado, "ydstogo": (d, max(2.0, 0.5 * d))},
            estado,
        )
        if res:
            valor, n, n_ok, f = res
            opciones.append(Option(
                key="go", label="Ir por el primero", score=valor, score_metric="WPA",
                success_rate=p_go, n_samples=n, confidence=confianza(min(n, len(muestra_p))),
                detail={"conversion": p_go, "muestra_conversion": float(len(muestra_p)), "ajuste_equipo": ajuste_p},
            ))
            factores["go"] = max(f, f_p)

    # --- Gol de campo ---
    dist_gc = y + 17
    if dist_gc <= MAX_PATADA_GC:
        todos_fg = pbp[(pbp["play_type"] == "field_goal") & pbp["field_goal_result"].notna()]
        muestra_p, f_p = ventana_progresiva(todos_fg, {"yardline_100": (y, 2)})
        fg4 = d4[(d4["play_type"] == "field_goal") & d4["field_goal_result"].notna()]
        if len(muestra_p) >= MIN_MUESTRA_OPCION and len(fg4) > 0:
            p_fg = float((muestra_p["field_goal_result"] == "made").mean())
            res = _binaria(fg4, fg4["field_goal_result"] == "made", p_fg, estado, estado)
            if res:
                valor, n, _, f = res
                opciones.append(Option(
                    key="fg", label="Gol de campo", score=valor, score_metric="WPA",
                    success_rate=p_fg, n_samples=n, confidence=confianza(min(n, len(muestra_p))),
                    detail={"fg_prob": p_fg, "kick_distance": float(dist_gc)},
                ))
                factores["fg"] = max(f, f_p)
    else:
        notas.append(f"Gol de campo descartado: la patada sería de {dist_gc} yardas.")

    # --- Despejar ---
    if y >= MIN_YARDLINE_PUNT:
        punt = d4[d4["play_type"] == "punt"]
        sub, f = ventana_progresiva(punt, estado)
        if len(sub) >= MIN_MUESTRA_OPCION:
            neto = (sub["kick_distance"] - sub["return_yards"].fillna(0)).dropna()
            opciones.append(Option(
                key="punt", label="Despejar", score=float(sub["wpa"].mean()), score_metric="WPA",
                success_rate=None, n_samples=len(sub), confidence=confianza(len(sub)),
                detail={"net_yards": float(neto.mean()) if len(neto) else None},
            ))
            factores["punt"] = f
    else:
        notas.append("Despeje descartado: estás demasiado cerca de la zona de anotación rival.")

    if not opciones:
        raise ValueError("No hay jugadas similares suficientes para esta situación.")

    for o in opciones:
        if factores.get(o.key, 1) >= FACTOR_AMPLIO:
            advertencias.append(f"Pocas jugadas muy similares para «{o.label}»: se amplió bastante el rango de búsqueda.")
        if o.n_samples < MIN_N:
            advertencias.append(f"Muestra pequeña para «{o.label}» ({o.n_samples} jugadas): tómalo con cautela.")

    opciones.sort(key=lambda o: o.score, reverse=True)
    advertencias = empate_tecnico(opciones) + advertencias
    return RecommendResponse(
        mode="fourth_down",
        best=opciones[0].key,
        options=opciones,
        notes=notas,
        warnings=advertencias,
        context={
            "situacion": describir_situacion(req.score_diff, req.game_seconds_remaining, req.quarter, req.clock_seconds),
            "game_seconds_remaining": req.game_seconds_remaining,
            "score_diff": req.score_diff,
            "kick_distance": dist_gc,
        },
    )
