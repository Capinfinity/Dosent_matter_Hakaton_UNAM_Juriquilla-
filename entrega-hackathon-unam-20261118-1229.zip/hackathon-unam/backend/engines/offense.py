"""Motor ofensivo: carrera, pase corto, pase largo y pase con play action.

Base: EPA y tasa de éxito de nflverse (2018-2023) en jugadas similares (down, distancia,
yarda, marcador, reloj). Las capturas (sacks) se reparten entre las opciones de pase.

Ajuste por defensa rival (opcional): con los datos de Big Data Bowl (pases de 2021,
semanas 1 a 8) se compara el EPA de las jugadas con la cobertura, formación, personal o
defensores en la caja indicados contra el promedio de BDB, y esa diferencia se suma a la
base, atenuada por el tamaño de muestra. BDB no tiene carreras: la carrera no se ajusta.
"""
from __future__ import annotations

from typing import Callable

import pandas as pd

from backend.data_loader import DataStore
from backend.engines.common import MIN_N, confianza, describir_situacion, empate_tecnico, ventana_progresiva
from backend.schemas import Option, RecommendRequest, RecommendResponse

K_ATENUACION = 40          # a mayor K, más pesa la muestra grande para confiar en el ajuste
MIN_N_BASE = 100           # muestra deseada en la base nflverse
MIN_N_PROFUNDO = 60        # los pases largos son menos frecuentes
MIN_AJUSTE = 5             # mínimo de jugadas BDB para considerar un ajuste
FACTOR_AMPLIO = 3

Mascara = Callable[[pd.DataFrame], pd.Series]


def _media(s: pd.Series) -> float:
    return float(s.mean()) if len(s) else 0.0


def _criterios_bdb(req: RecommendRequest) -> list[tuple[str, Mascara]]:
    crit: list[tuple[str, Mascara]] = []
    if req.rival_coverage:
        crit.append((f"cobertura {req.rival_coverage}", lambda b, v=req.rival_coverage: b["pff_passCoverage"] == v))
    if req.formation:
        crit.append((f"formación {req.formation}", lambda b, v=req.formation: b["offenseFormation"] == v))
    if req.personnel:
        crit.append((f"personal {req.personnel}", lambda b, v=req.personnel: b["personnelO"] == v))
    if req.defenders_in_box is not None:
        crit.append((f"{req.defenders_in_box} defensores en la caja",
                     lambda b, v=req.defenders_in_box: b["defendersInBox"] == v))
    return crit


def _ajuste_profundidad(bdb_tipo: pd.DataFrame, crit: list[tuple[str, Mascara]]) -> tuple[float, int, list[str]]:
    """Suma de diferencias atenuadas entre el EPA con cada criterio y el EPA promedio de BDB."""
    total, n_min, avisos = 0.0, 10**9, []
    base = _media(bdb_tipo["epa"])
    for nombre, f in crit:
        sub = bdb_tipo[f(bdb_tipo)]
        n = len(sub)
        if n < MIN_AJUSTE:
            avisos.append(f"Casi no hay jugadas de BDB con {nombre} para este tipo de pase ({n}); no se ajustó.")
            n_min = min(n_min, n)
            continue
        total += (_media(sub["epa"]) - base) * n / (n + K_ATENUACION)
        n_min = min(n_min, n)
    return total, (0 if n_min == 10**9 else n_min), avisos


def _ajuste_play_action(bdb: pd.DataFrame, crit: list[tuple[str, Mascara]]) -> tuple[float, int, list[str]]:
    """Diferencia atenuada de EPA entre play action y pase normal, con los criterios dados (todos a la vez)."""
    sub = bdb
    for _, f in crit:
        sub = sub[f(sub)]
    pa = sub[sub["pff_playAction"] == 1]
    no = sub[sub["pff_playAction"] == 0]
    avisos: list[str] = []
    if len(pa) < 10 or len(no) < 10:
        if crit:
            avisos.append("Pocas jugadas de BDB con play action bajo esas condiciones: se usó el efecto general de BDB.")
        pa, no = bdb[bdb["pff_playAction"] == 1], bdb[bdb["pff_playAction"] == 0]
    n = min(len(pa), len(no))
    if n == 0:
        return 0.0, 0, avisos
    return (_media(pa["epa"]) - _media(no["epa"])) * n / (n + K_ATENUACION), n, avisos


def _opcion(key: str, label: str, epa: float, exito: float, n_base: int, ajuste: float,
            n_bdb: int | None, hay_criterios: bool, ajuste_equipo: float = 0.0) -> Option:
    n_conf = min(n_base, n_bdb) if hay_criterios and n_bdb is not None else n_base
    return Option(
        key=key, label=label, score=epa, score_metric="EPA", success_rate=exito,
        n_samples=n_base, confidence=confianza(n_conf),
        detail={
            "ajuste_bdb": ajuste, "muestra_bdb": float(n_bdb) if n_bdb is not None else None,
            "ajuste_equipo": ajuste_equipo,
        },
    )


def _ajuste_mezcla(bdb: pd.DataFrame, crit: list[tuple[str, Mascara]], mezcla: dict[str, float]) -> tuple[float, float, float]:
    """Ajuste esperado contra un rival que usa varias coberturas: promedio ponderado por su frecuencia de uso."""
    total = sum(mezcla.values())
    cortos, largos = bdb[bdb["pass_length"] == "short"], bdb[bdb["pass_length"] == "deep"]
    a_cor = a_lar = a_pa = 0.0
    for cob, share in mezcla.items():
        c = crit + [(f"cobertura {cob}", lambda b, v=cob: b["pff_passCoverage"] == v)]
        w = share / total
        a_cor += w * _ajuste_profundidad(cortos, c)[0]
        a_lar += w * _ajuste_profundidad(largos, c)[0]
        a_pa += w * _ajuste_play_action(bdb, c)[0]
    return a_cor, a_lar, a_pa


def recommend_offense(req: RecommendRequest, store: DataStore, score_diff: int | None = None) -> RecommendResponse:
    sd = req.score_diff if score_diff is None else score_diff
    pbp = store.pbp
    sit = pbp[pbp["down"] == req.down]

    d, y, t = req.yards_to_go, req.yardline_100, req.game_seconds_remaining
    crit_base = {
        "ydstogo": (d, max(1.0, 0.25 * d)),
        "yardline_100": (y, 10),
        "score_differential": (sd, 4),
        "game_seconds_remaining": (t, 300),
    }

    pases = sit[(sit["play_type"] == "pass")]
    corridas = sit[(sit["play_type"] == "run") & (sit["qb_scramble"] != 1)]
    cortos = pases[(pases["pass_length"] == "short") & (pases["sack"] != 1)]
    largos = pases[(pases["pass_length"] == "deep") & (pases["sack"] != 1)]

    win_run, f_run = ventana_progresiva(corridas, crit_base, MIN_N_BASE)
    win_cor, f_cor = ventana_progresiva(cortos, crit_base, MIN_N_BASE)
    win_lar, f_lar = ventana_progresiva(largos, crit_base, MIN_N_PROFUNDO)
    win_pas, f_pas = ventana_progresiva(pases, crit_base, MIN_N_BASE)

    if min(len(win_run), len(win_cor), len(win_lar)) < MIN_AJUSTE or len(win_pas) < MIN_AJUSTE:
        raise ValueError("No hay jugadas similares suficientes para esta situación.")

    # Capturas: se reparten entre las opciones de pase
    s = float((win_pas["sack"] == 1).mean())
    caps = win_pas[win_pas["sack"] == 1]
    epa_cap = _media(caps["epa"]) if len(caps) >= MIN_AJUSTE else _media(pbp[(pbp["sack"] == 1) & (pbp["down"] == req.down)]["epa"])
    exito_cap = _media(caps["success"]) if len(caps) >= MIN_AJUSTE else 0.0

    # Ajuste con datos de BDB
    bdb = store.bdb
    bdb = bdb[bdb["matched"] & (bdb["sack"] != 1)]
    crit = _criterios_bdb(req)
    avisos: list[str] = []
    hay = bool(crit)
    aj_cor = aj_lar = aj_pa = 0.0
    n_cor = n_lar = n_pa = None
    ts = store.teams
    # Si hay rival y no se indicó su cobertura, se usa su mezcla habitual de coberturas
    mezcla = {}
    if req.opponent and not req.rival_coverage:
        mezcla = {c: s for c, s in ts.cov_mix.get(req.opponent, {}).items() if s >= 0.03}
    if mezcla:
        aj_cor, aj_lar, aj_pa = _ajuste_mezcla(bdb, crit, mezcla)
    else:
        if hay:
            aj_cor, n_cor, a1 = _ajuste_profundidad(bdb[bdb["pass_length"] == "short"], crit)
            aj_lar, n_lar, a2 = _ajuste_profundidad(bdb[bdb["pass_length"] == "deep"], crit)
            avisos += a1 + a2
        aj_pa, n_pa, a3 = _ajuste_play_action(bdb, crit)
        avisos += a3

    # Ajuste por equipo: tu ofensiva y la defensa rival frente al promedio de la liga
    eq = {tipo: 0.0 for tipo in ("run", "pass_short", "pass_deep")}
    for tipo in eq:
        if req.team:
            eq[tipo] += ts.off_delta[req.team][tipo]
        if req.opponent:
            eq[tipo] += ts.def_delta[req.opponent][tipo]
    eq_pa = 0.7 * eq["pass_short"] + 0.3 * eq["pass_deep"]

    def con_capturas(epa_sin: float, exito_sin: float) -> tuple[float, float]:
        return (1 - s) * epa_sin + s * epa_cap, (1 - s) * exito_sin + s * exito_cap

    epa_cor, ex_cor = con_capturas(_media(win_cor["epa"]) + aj_cor + eq["pass_short"], _media(win_cor["success"]))
    epa_lar, ex_lar = con_capturas(_media(win_lar["epa"]) + aj_lar + eq["pass_deep"], _media(win_lar["success"]))
    epa_pas_base, ex_pas = con_capturas(_media(win_pas[win_pas["sack"] != 1]["epa"]), _media(win_pas[win_pas["sack"] != 1]["success"]))
    epa_pa = epa_pas_base + aj_pa + eq_pa

    opciones = [
        _opcion("run", "Carrera", _media(win_run["epa"]) + eq["run"], _media(win_run["success"]), len(win_run),
                0.0, None, False, eq["run"]),
        _opcion("pass_short", "Pase corto", epa_cor, ex_cor, len(win_cor), aj_cor, n_cor, hay, eq["pass_short"]),
        _opcion("pass_deep", "Pase largo", epa_lar, ex_lar, len(win_lar), aj_lar, n_lar, hay, eq["pass_deep"]),
        _opcion("pass_pa", "Pase con play action", epa_pa, ex_pas, len(win_pas), aj_pa, n_pa, True, eq_pa),
    ]
    opciones.sort(key=lambda o: o.score, reverse=True)

    factores = {"run": f_run, "pass_short": f_cor, "pass_deep": f_lar, "pass_pa": f_pas}
    advertencias = list(dict.fromkeys(avisos))
    for o in opciones:
        if factores[o.key] >= FACTOR_AMPLIO:
            advertencias.append(f"Pocas jugadas muy similares para «{o.label}»: se amplió bastante el rango de búsqueda.")
        if o.n_samples < MIN_N:
            advertencias.append(f"Muestra pequeña para «{o.label}» ({o.n_samples} jugadas): tómalo con cautela.")

    notas = [
        "EPA por jugada en situaciones similares de nflverse (2018 a 2023). Las capturas del QB cuentan dentro de los pases.",
        "Play action: se estima con Big Data Bowl (2021, semanas 1 a 8) sobre la base de todos los pases.",
    ]
    if crit:
        notas.append(
            "No hay carreras en Big Data Bowl: los datos de la defensa rival ajustan solo las opciones de pase. "
            "El ajuste no incluye capturas, que suben contra blitz (por ejemplo Cover-0)."
        )
    if req.down == 4:
        notas.append("Para decidir entre despejar, gol de campo o ir por el primero usa el modo «4º down».")
    if req.team or req.opponent:
        quien = " y ".join(x for x in (f"la ofensiva de {req.team}" if req.team else "", f"la defensa de {req.opponent}" if req.opponent else "") if x)
        notas.append(
            f"Ajuste por equipo ({quien}) frente al promedio de la liga en 2021-2023: carrera {eq['run']:+.3f}, "
            f"pase corto {eq['pass_short']:+.3f}, pase largo {eq['pass_deep']:+.3f} EPA."
        )
    if mezcla:
        notas.append(
            f"Sin cobertura indicada: se usó la mezcla habitual de coberturas de {req.opponent} en Big Data Bowl "
            f"({', '.join(f'{c} {s:.0%}' for c, s in sorted(mezcla.items(), key=lambda kv: -kv[1])[:4])})."
        )

    return RecommendResponse(
        mode="offense",
        best=opciones[0].key,
        options=opciones,
        notes=notas,
        warnings=empate_tecnico(opciones) + advertencias,
        context={
            "situacion": describir_situacion(sd, t, req.quarter, req.clock_seconds),
            "game_seconds_remaining": t,
            "score_diff": sd,
            "ajustes_bdb": len(crit),
        },
    )
