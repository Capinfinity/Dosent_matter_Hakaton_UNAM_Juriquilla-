"""Catálogo de los 32 equipos de la NFL.

Las abreviaturas son las que usan Big Data Bowl y nflverse en estos datos (por ejemplo LA para
los Rams y LV para los Raiders). Los colores son aproximados y solo se usan para la interfaz.
"""
from __future__ import annotations

from backend.schemas import TeamInfo

# abreviatura: (nombre, conferencia, división, color principal, color secundario)
_EQUIPOS: dict[str, tuple[str, str, str, str, str]] = {
    # AFC Este
    "BUF": ("Buffalo Bills", "AFC", "Este", "#00338D", "#C60C30"),
    "MIA": ("Miami Dolphins", "AFC", "Este", "#008E97", "#FC4C02"),
    "NE": ("New England Patriots", "AFC", "Este", "#002244", "#C60C30"),
    "NYJ": ("New York Jets", "AFC", "Este", "#125740", "#FFFFFF"),
    # AFC Norte
    "BAL": ("Baltimore Ravens", "AFC", "Norte", "#241773", "#9E7C0C"),
    "CIN": ("Cincinnati Bengals", "AFC", "Norte", "#FB4F14", "#000000"),
    "CLE": ("Cleveland Browns", "AFC", "Norte", "#311D00", "#FF3C00"),
    "PIT": ("Pittsburgh Steelers", "AFC", "Norte", "#FFB612", "#101820"),
    # AFC Sur
    "HOU": ("Houston Texans", "AFC", "Sur", "#03202F", "#A71930"),
    "IND": ("Indianapolis Colts", "AFC", "Sur", "#002C5F", "#A2AAAD"),
    "JAX": ("Jacksonville Jaguars", "AFC", "Sur", "#006778", "#D7A22A"),
    "TEN": ("Tennessee Titans", "AFC", "Sur", "#0C2340", "#4B92DB"),
    # AFC Oeste
    "DEN": ("Denver Broncos", "AFC", "Oeste", "#FB4F14", "#002244"),
    "KC": ("Kansas City Chiefs", "AFC", "Oeste", "#E31837", "#FFB81C"),
    "LV": ("Las Vegas Raiders", "AFC", "Oeste", "#000000", "#A5ACAF"),
    "LAC": ("Los Angeles Chargers", "AFC", "Oeste", "#0080C6", "#FFC20E"),
    # NFC Este
    "DAL": ("Dallas Cowboys", "NFC", "Este", "#003594", "#869397"),
    "NYG": ("New York Giants", "NFC", "Este", "#0B2265", "#A71930"),
    "PHI": ("Philadelphia Eagles", "NFC", "Este", "#004C54", "#A5ACAF"),
    "WAS": ("Washington Commanders", "NFC", "Este", "#5A1414", "#FFB612"),
    # NFC Norte
    "CHI": ("Chicago Bears", "NFC", "Norte", "#0B162A", "#C83803"),
    "DET": ("Detroit Lions", "NFC", "Norte", "#0076B6", "#B0B7BC"),
    "GB": ("Green Bay Packers", "NFC", "Norte", "#203731", "#FFB612"),
    "MIN": ("Minnesota Vikings", "NFC", "Norte", "#4F2683", "#FFC62F"),
    # NFC Sur
    "ATL": ("Atlanta Falcons", "NFC", "Sur", "#A71930", "#000000"),
    "CAR": ("Carolina Panthers", "NFC", "Sur", "#0085CA", "#101820"),
    "NO": ("New Orleans Saints", "NFC", "Sur", "#D3BC8D", "#101820"),
    "TB": ("Tampa Bay Buccaneers", "NFC", "Sur", "#D50A0A", "#34302B"),
    # NFC Oeste
    "ARI": ("Arizona Cardinals", "NFC", "Oeste", "#97233F", "#000000"),
    "LA": ("Los Angeles Rams", "NFC", "Oeste", "#003594", "#FFA300"),
    "SF": ("San Francisco 49ers", "NFC", "Oeste", "#AA0000", "#B3995D"),
    "SEA": ("Seattle Seahawks", "NFC", "Oeste", "#002244", "#69BE28"),
}

TEAMS: dict[str, TeamInfo] = {
    abbr: TeamInfo(abbr=abbr, name=n, conference=c, division=d, color=c1, color2=c2)
    for abbr, (n, c, d, c1, c2) in _EQUIPOS.items()
}

TEAM_CODES: list[str] = sorted(TEAMS)
