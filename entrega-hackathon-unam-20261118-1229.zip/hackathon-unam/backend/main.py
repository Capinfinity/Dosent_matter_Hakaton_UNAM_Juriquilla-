"""API del Asistente de jugadas NFL. Ejecuta: .venv/bin/uvicorn backend.main:app --reload"""
from contextlib import asynccontextmanager
from pathlib import Path

from fastapi import FastAPI, HTTPException
from fastapi.staticfiles import StaticFiles

from backend.data_loader import DataStore, get_store
from backend.engines import recommend
from backend.schemas import Meta, RecommendRequest, RecommendResponse, TeamProfile, TeamSummary


@asynccontextmanager
async def lifespan(_: FastAPI):
    get_store()  # carga los datos al arrancar
    yield


app = FastAPI(title="Hackathon NFL UNAM", lifespan=lifespan)


@app.get("/health")
def health() -> dict:
    return {"status": "ok"}


def _frecuentes(serie, top: int | None = None) -> list[str]:
    vc = serie.dropna().astype(str).value_counts()
    return list(vc.index[:top]) if top else list(vc.index)


def _meta(store: DataStore) -> Meta:
    b = store.bdb
    cajas = sorted(int(x) for x in b["defendersInBox"].dropna().unique())
    return Meta(
        coverages=_frecuentes(b["pff_passCoverage"]),
        coverage_types=_frecuentes(b["pff_passCoverageType"]),
        formations=_frecuentes(b["offenseFormation"]),
        personnel=_frecuentes(b["personnelO"], top=15),
        defenders_in_box=cajas,
        modes=["offense", "defense", "fourth_down"],
        data={"nflverse_plays": int(len(store.pbp)), "bdb_plays": int(len(b))},
    )


@app.get("/api/meta", response_model=Meta)
def meta() -> Meta:
    return _meta(get_store())


@app.get("/api/teams", response_model=list[TeamSummary])
def teams() -> list[TeamSummary]:
    """Los 32 equipos con su jugada preferida y más efectiva (ofensiva y defensiva)."""
    return get_store().teams.summaries()


@app.get("/api/teams/{abbr}", response_model=TeamProfile)
def team_profile(abbr: str) -> TeamProfile:
    perfil = get_store().teams.profiles.get(abbr.upper())
    if perfil is None:
        raise HTTPException(status_code=404, detail=f"Equipo desconocido: {abbr}")
    return perfil


@app.post("/api/recommend", response_model=RecommendResponse)
def api_recommend(req: RecommendRequest) -> RecommendResponse:
    try:
        return recommend(req, get_store())
    except ValueError as e:
        raise HTTPException(status_code=422, detail=str(e)) from e


# El build del dashboard (vite build) se sirve en la misma URL y puerto que la API.
# Va al final para que /health, /api/... y /docs tengan prioridad.
_DIST = Path(__file__).resolve().parent.parent / "dashboard" / "dist"
if _DIST.is_dir():
    app.mount("/", StaticFiles(directory=_DIST, html=True), name="dashboard")
