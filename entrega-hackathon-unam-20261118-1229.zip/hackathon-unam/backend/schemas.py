"""Contrato de la API: esquemas de petición y respuesta."""
from __future__ import annotations

from typing import Literal, Optional

from pydantic import BaseModel, Field, model_validator

Mode = Literal["offense", "defense", "fourth_down"]
Confidence = Literal["alta", "media", "baja"]


class RecommendRequest(BaseModel):
    mode: Mode = Field(description="offense: tu ofensiva; defense: tu defensa; fourth_down: decisión de 4º down")
    down: int = Field(ge=1, le=4)
    yards_to_go: int = Field(ge=1, le=99, description="Yardas para el primero")
    yardline_100: int = Field(ge=1, le=99, description="Yardas que faltan para la zona de anotación rival")
    score_diff: int = Field(ge=-60, le=60, description="Tu marcador menos el del rival")
    quarter: int = Field(ge=1, le=5, description="1 a 4; 5 = tiempo extra")
    clock_seconds: int = Field(ge=0, le=900, description="Segundos que faltan en el cuarto")

    # Opcionales ("Más datos")
    rival_coverage: Optional[str] = Field(default=None, description="Cobertura PFF del rival, p. ej. Cover-3")
    formation: Optional[str] = Field(default=None, description="Formación ofensiva, p. ej. SHOTGUN")
    personnel: Optional[str] = Field(default=None, description="Personal ofensivo, p. ej. '1 RB, 1 TE, 3 WR'")
    defenders_in_box: Optional[int] = Field(default=None, ge=3, le=11)
    timeouts: Optional[int] = Field(default=None, ge=0, le=3, description="Tus tiempos fuera restantes")

    # Equipos (opcionales): abreviaturas como KC, BUF, LA
    team: Optional[str] = Field(default=None, description="Tu equipo (abreviatura)")
    opponent: Optional[str] = Field(default=None, description="Equipo rival (abreviatura)")

    @model_validator(mode="after")
    def _validar_equipos(self) -> "RecommendRequest":
        from backend.teams import TEAMS  # import tardío: teams.py importa schemas

        for nombre, valor in (("team", self.team), ("opponent", self.opponent)):
            if valor is not None and valor not in TEAMS:
                raise ValueError(f"{nombre}: equipo desconocido «{valor}»")
        if self.team and self.team == self.opponent:
            raise ValueError("team y opponent deben ser equipos distintos")
        return self

    @model_validator(mode="after")
    def _validar(self) -> "RecommendRequest":
        if self.yards_to_go > self.yardline_100:
            raise ValueError("yards_to_go no puede ser mayor que yardline_100")
        limite = 600 if self.quarter == 5 else 900
        if self.clock_seconds > limite:
            raise ValueError(f"clock_seconds no puede pasar de {limite} en este cuarto")
        return self

    @property
    def game_seconds_remaining(self) -> int:
        """Segundos que faltan en el juego (el tiempo extra se trata como 0 de juego regular)."""
        if self.quarter == 5:
            return self.clock_seconds
        return (4 - self.quarter) * 900 + self.clock_seconds

    @property
    def half_seconds_remaining(self) -> int:
        if self.quarter in (1, 3):
            return 900 + self.clock_seconds
        return self.clock_seconds


class Option(BaseModel):
    key: str
    label: str
    score: float = Field(description="Valor esperado de la opción (mayor es mejor)")
    score_metric: str = Field(description="Qué mide score: 'WPA' o 'EPA'")
    success_rate: Optional[float] = Field(default=None, ge=0, le=1)
    n_samples: int = Field(ge=0)
    confidence: Confidence
    detail: dict[str, Optional[float]] = Field(default_factory=dict)


class RecommendResponse(BaseModel):
    mode: Mode
    best: str = Field(description="key de la mejor opción")
    options: list[Option]
    notes: list[str] = Field(default_factory=list)
    warnings: list[str] = Field(default_factory=list)
    context: dict[str, str | int | float] = Field(default_factory=dict)


class TeamInfo(BaseModel):
    abbr: str
    name: str
    conference: str
    division: str
    color: str
    color2: str


class PlayStat(BaseModel):
    """Una jugada (tipo de jugada o cobertura) de un equipo."""
    id: str
    label: str
    n: int
    share: float = Field(description="Proporción de uso entre las jugadas comparables del equipo")
    epa: float = Field(description="EPA promedio observado")
    epa_adj: float = Field(description="EPA suavizado hacia el promedio de la liga según la muestra")
    success_rate: float
    lift: float = Field(default=0.0, description="Uso del equipo menos uso de la liga (proporción)")
    edge: float = Field(default=0.0, description="EPA suavizado del equipo menos EPA de la liga")


class OffenseProfile(BaseModel):
    plays: int
    pass_rate: float
    categories: list[PlayStat]
    preferred: Optional[PlayStat] = Field(default=None, description="La más usada")
    most_effective: Optional[PlayStat] = Field(default=None, description="Mayor EPA suavizado")
    signature: Optional[PlayStat] = Field(default=None, description="La que usa más que la liga")
    strength: Optional[PlayStat] = Field(default=None, description="Donde rinde más que la liga")
    formations: list[PlayStat]
    passing: dict[str, Optional[float]]


class DefenseProfile(BaseModel):
    plays: int
    epa_allowed_run: float
    epa_allowed_pass: float
    coverages: list[PlayStat]
    preferred_coverage: Optional[PlayStat] = Field(default=None, description="La más usada")
    most_effective_coverage: Optional[PlayStat] = Field(default=None, description="Menor EPA permitido suavizado")
    signature_coverage: Optional[PlayStat] = Field(default=None, description="La que usa más que la liga")
    vulnerability: Optional[PlayStat] = Field(default=None, description="Tipo de jugada donde más EPA permite")
    man_rate: Optional[float] = None
    blitz_rate: Optional[float] = None
    pressure_rate: Optional[float] = None
    passing_allowed: dict[str, Optional[float]]


class TeamProfile(BaseModel):
    info: TeamInfo
    seasons: list[int]
    offense: OffenseProfile
    defense: DefenseProfile


class TeamSummary(BaseModel):
    info: TeamInfo
    preferred_offense: Optional[str] = None
    most_effective_offense: Optional[str] = None
    preferred_defense: Optional[str] = None
    most_effective_defense: Optional[str] = None


class Meta(BaseModel):
    coverages: list[str]
    coverage_types: list[str]
    formations: list[str]
    personnel: list[str]
    defenders_in_box: list[int]
    modes: list[str]
    data: dict[str, int]
