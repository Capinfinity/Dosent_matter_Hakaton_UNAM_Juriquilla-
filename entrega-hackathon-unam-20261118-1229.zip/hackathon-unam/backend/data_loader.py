"""Carga de datos en memoria. Solo lectura: no se escribe nada en disco."""
from __future__ import annotations

from dataclasses import dataclass
from functools import lru_cache
from pathlib import Path

import pandas as pd

from backend.team_stats import TeamStats, build_team_stats

DATA_DIR = Path(__file__).resolve().parent.parent / "data"

# Columnas de nflverse que se unen a las jugadas de Big Data Bowl.
_COLS_UNION = [
    "old_game_id", "play_id", "epa", "wpa", "success", "pass_length", "pass_location",
    "yardline_100", "game_seconds_remaining", "score_differential", "qb_scramble", "sack",
    "interception", "touchdown", "yards_gained",
]


@dataclass(frozen=True)
class DataStore:
    pbp: pd.DataFrame   # nflverse 2018-2023 filtrado (carreras, pases, despejes, goles de campo)
    bdb: pd.DataFrame   # jugadas de pase de BDB 2021 sem. 1-8 unidas con nflverse (EPA, WPA...) y presión PFF
    teams: TeamStats    # clasificación por equipo (perfiles y ajustes)


def _presion(data_dir: Path) -> pd.DataFrame:
    """Rushers y presión por jugada, a partir de pffScoutingData (rol 'Pass Rush')."""
    pff = pd.read_csv(
        data_dir / "pffScoutingData.csv",
        usecols=["gameId", "playId", "pff_role", "pff_hit", "pff_hurry", "pff_sack"],
    )
    pff["rusher"] = (pff["pff_role"] == "Pass Rush").astype(int)
    pff["presiona"] = (pff[["pff_hit", "pff_hurry", "pff_sack"]].fillna(0).sum(axis=1) > 0).astype(int)
    g = pff.groupby(["gameId", "playId"]).agg(n_rushers=("rusher", "sum"), pressure=("presiona", "max"))
    return g.reset_index()


def _cargar(data_dir: Path) -> DataStore:
    pbp = pd.read_csv(data_dir / "nflverse_pbp_filtered.csv", low_memory=False)

    plays = pd.read_csv(data_dir / "plays.csv", low_memory=False)
    nfl21 = (
        pbp.loc[pbp["season"] == 2021, _COLS_UNION]
        .rename(columns={"old_game_id": "gameId", "play_id": "playId"})
        .drop_duplicates(["gameId", "playId"])
    )
    bdb = plays.merge(nfl21, on=["gameId", "playId"], how="left")
    bdb["matched"] = bdb["epa"].notna()
    bdb = bdb.merge(_presion(data_dir), on=["gameId", "playId"], how="left")
    return DataStore(pbp=pbp, bdb=bdb, teams=build_team_stats(pbp, bdb))


@lru_cache(maxsize=1)
def get_store() -> DataStore:
    """Carga los datos una sola vez por proceso."""
    return _cargar(DATA_DIR)
