"""Pruebas de /api/explain con Bedrock simulado: no usan red ni llaves."""
import pytest
from fastapi.testclient import TestClient

from backend import explain as mod
from backend.main import app

BASE = {
    "mode": "fourth_down", "down": 4, "yards_to_go": 2, "yardline_100": 40,
    "score_diff": -3, "quarter": 4, "clock_seconds": 300,
}


class FakeBedrock:
    def __init__(self, texto="Ir por el primero rinde más que patear en esta situación."):
        self.texto = texto
        self.llamadas = []

    def converse(self, **kw):
        self.llamadas.append(kw)
        return {"output": {"message": {"content": [{"text": self.texto}]}}}


class BedrockCaido:
    def converse(self, **kw):
        raise RuntimeError("ExpiredTokenException")


@pytest.fixture()
def client():
    with TestClient(app) as c:
        yield c


def test_explain_devuelve_texto_de_nova(client, monkeypatch):
    falso = FakeBedrock()
    monkeypatch.setattr(mod, "_cliente", falso)
    r = client.post("/api/explain", json=BASE)
    assert r.status_code == 200
    d = r.json()
    assert d["explanation"] == falso.texto
    kw = falso.llamadas[0]
    assert kw["modelId"] == "us.amazon.nova-pro-v1:0"
    # El prompt lleva la situación y la mejor opción calculada por el motor
    assert '"mejor_opcion"' in kw["messages"][0]["content"][0]["text"]


def test_explain_usa_bedrock_model_id(client, monkeypatch):
    falso = FakeBedrock()
    monkeypatch.setattr(mod, "_cliente", falso)
    monkeypatch.setenv("BEDROCK_MODEL_ID", "otro-modelo")
    client.post("/api/explain", json=BASE)
    assert falso.llamadas[0]["modelId"] == "otro-modelo"


def test_explain_degrada_si_nova_falla(client, monkeypatch):
    monkeypatch.setattr(mod, "_cliente", BedrockCaido())
    r = client.post("/api/explain", json=BASE)
    assert r.status_code == 200
    assert r.json()["explanation"] is None


def test_explain_valida_la_peticion(client, monkeypatch):
    monkeypatch.setattr(mod, "_cliente", FakeBedrock())
    r = client.post("/api/explain", json={**BASE, "yards_to_go": 50})
    assert r.status_code == 422
