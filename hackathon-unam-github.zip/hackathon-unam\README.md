# Asistente de jugadas NFL

Aplicación web que recomienda la mejor jugada según la situación (down, distancia, posición en el campo, marcador y reloj) y, de forma opcional, la defensa u ofensiva rival.

Tiene tres modos:

| Modo | Qué recomienda | Datos |
|---|---|---|
| **4º down** | Ir por el primero, gol de campo o despejar | nflverse 2018-2023 |
| **Ofensiva** | Carrera, pase corto, pase largo o pase con play action | nflverse, más Big Data Bowl para ajustar por cobertura, formación, personal y defensores en la caja |
| **Defensiva** | Cobertura (Man o Zone), caja recomendada y tendencia Man contra Zone | Big Data Bowl (2021, semanas 1 a 8) |

Cada recomendación muestra una tabla comparativa con la mejor opción resaltada, una gráfica, el tamaño de muestra y un nivel de confianza (alta, media o baja). Avisa cuando la muestra es pequeña o cuando las dos mejores opciones están en empate técnico.

## Equipos

Al abrir la app se elige **tu equipo** y **el rival** entre los 32 de la NFL. Los datos se clasifican por equipo (nflverse 2021-2023 y Big Data Bowl 2021) y de cada uno se calcula:

- **Ofensiva:** jugada más usada, más efectiva (mayor EPA suavizado), sello (la que usa más que la liga) y fortaleza (donde rinde más que la liga), entre 9 tipos de jugada (carrera y pase corto o largo, a la izquierda, al centro o a la derecha). También sus formaciones y estadísticas de pase.
- **Defensa:** cobertura preferida, más efectiva y sello, tipo de jugada donde es más vulnerable, y tasas de hombre, blitz y presión.

Las recomendaciones usan a ambos equipos: el rendimiento de tu ofensiva y de la defensa rival frente a la liga ajusta el EPA de carrera y pase, la probabilidad de conversión en 4º down y el valor de cada cobertura. Si no indicas la cobertura o la formación del rival, se usa la mezcla que ese equipo emplea. Los ajustes están acotados y atenuados por la muestra, y cada respuesta explica cuánto se ajustó.

## Campo en vista aérea

Debajo de la recomendación hay una simulación animada del campo con las medidas reglamentarias (120 × 53.33 yardas, hash marks a 70 pies 9 pulgadas de cada banda, postes de 6.17 yardas). Muestra las posiciones de los 22 jugadores, las rutas, las zonas de cobertura, la marca hombre a hombre, la línea de golpeo y la de primer down. Se puede elegir cualquier jugada (10 ofensivas, 7 coberturas, gol de campo y despeje), cambiar la defensa o formación rival, la velocidad, y ver el campo completo o con zoom. La jugada recomendada se selecciona sola, con la dirección (izquierda, centro, derecha) donde tu equipo rinde mejor.

Las jugadas del campo son un libro de jugadas estándar dibujado a mano (no vienen de los datos de tracking): ilustran el concepto, no la alineación exacta de un equipo.

## Cómo funciona (resumen)

- **4º down:** para ir por el primero y para el gol de campo, valor = p(éxito) · WPA(éxito) + (1 − p) · WPA(fracaso). La probabilidad p depende de la distancia. El WPA de cada resultado depende de la yarda, el marcador y el reloj. Despejar es el WPA promedio de despejes similares. WPA es el cambio en la probabilidad de victoria.
- **Ofensiva:** EPA por jugada en situaciones similares (down, distancia, yarda, marcador, reloj). Las capturas se reparten entre los pases. Si se indica la defensa rival, se suma un ajuste de Big Data Bowl, atenuado por la muestra. Big Data Bowl no tiene carreras, así que la carrera no se ajusta.
- **Defensiva:** EPA permitido por cobertura en jugadas similares, mezclado con el promedio general de esa cobertura según la muestra. Se excluyen llamadas especiales (Prevent, Red Zone, Goal Line, Bracket).
- Las situaciones similares se buscan ensanchando poco a poco la ventana hasta tener muestra suficiente.

## Ejecutar

Requisitos: haber corrido `sh .hackathon/setup.sh` (crea `.venv` y las dependencias).

```sh
# 1. Datos (ya incluidos en data/; solo si quieres regenerarlos)
.venv/bin/python scripts/prepare_data.py --force

# 2. Frontend: genera dashboard/dist
cd dashboard && ../.hackathon/.tools/node/bin/npm run build && cd ..

# 3. Servidor (API y página en el mismo puerto)
.venv/bin/uvicorn backend.main:app --port 8000
```

Abre http://localhost:8000. La documentación de la API está en `/docs`.

### Probarla desde otra computadora (misma red)

Levanta el servidor escuchando en toda la red, con `--host 0.0.0.0`:

```sh
.venv/bin/uvicorn backend.main:app --host 0.0.0.0 --port 8000
```

Averigua tu IP (`ipconfig getifaddr en0` en macOS) y la otra computadora abre `http://TU_IP:8000`. Deben estar en la misma red, sin aislamiento de clientes, y el firewall debe permitir conexiones entrantes a Python. El servidor debe seguir encendido. Para un enlace público en internet hace falta el hosting del evento o un túnel.

### Clonar desde GitHub

Requisitos: [uv](https://docs.astral.sh/uv/) (instala Python 3.12 por ti) y [Node.js 22](https://nodejs.org/).

Windows (PowerShell):

```powershell
git clone <URL-del-repositorio>
cd <carpeta>
uv venv .venv --python 3.12
uv pip install --python .venv\Scripts\python.exe -r requirements.txt
cd dashboard; npm.cmd install; npm.cmd run build; cd ..
.venv\Scripts\python.exe -m uvicorn backend.main:app --port 8000
```

macOS / Linux:

```sh
git clone <URL-del-repositorio>
cd <carpeta>
uv venv .venv --python 3.12
uv pip install --python .venv/bin/python -r requirements.txt
cd dashboard && npm install && npm run build && cd ..
.venv/bin/uvicorn backend.main:app --port 8000
```

Abre http://localhost:8000. Si uv falla con `invalid peer certificate`, tu red inspecciona HTTPS: antes de los comandos de uv define `UV_SYSTEM_CERTS=1` (en PowerShell: `$env:UV_SYSTEM_CERTS="1"`).

### Explicación con Amazon Nova (opcional)

Debajo de cada recomendación aparece un cuadro "Por qué (Amazon Nova)" que justifica la jugada elegida en 2 o 3 frases. Nova solo explica la decisión del motor estadístico, no la cambia. Usa Amazon Bedrock con el modelo de `BEDROCK_MODEL_ID` (por defecto `us.amazon.nova-pro-v1:0`) en la región de `AWS_REGION` (por defecto `us-east-1`).

Para activarla, copia `.env.example` como `.env` y pon tus propias credenciales de AWS con acceso a Bedrock. **No subas `.env` a GitHub** (ya está en `.gitignore`). Sin credenciales, o si Bedrock falla, la app funciona igual y solo oculta el cuadro.

`dashboard/dist` no se versiona, por eso hay que compilar el frontend después de clonar. Los CSV que usa la app ya vienen en `data/` (47 MB en total). No se versiona `Datos/` (material de consulta de 826 MB) ni `.env` (llaves de AWS).

Desarrollo con recarga en vivo: en una terminal `.venv/bin/uvicorn backend.main:app --reload` y en otra `cd dashboard && npm run dev` (Vite reenvía `/api` al puerto 8000).

## API

- `GET /health`
- `GET /api/meta`: valores válidos (coberturas, formaciones, personal, caja).
- `GET /api/teams`: los 32 equipos con su jugada preferida y más efectiva.
- `GET /api/teams/{abbr}`: perfil completo (por ejemplo `KC`, `LA`, `LV`).
- `POST /api/recommend`: `mode` (`fourth_down`, `offense`, `defense`), `down`, `yards_to_go`, `yardline_100` (yardas a la zona de anotación rival), `score_diff` (tu marcador menos el del rival), `quarter` (1 a 5), `clock_seconds` (segundos que faltan en el cuarto). Opcionales: `team`, `opponent`, `rival_coverage`, `formation`, `personnel`, `defenders_in_box`, `timeouts`.
- `POST /api/explain`: mismo cuerpo que `/api/recommend`. Devuelve `{explanation, model}` con la justificación de Amazon Nova; `explanation` es `null` si Nova no está disponible.

## Pruebas

```sh
.venv/bin/pytest -q
```

## Estructura

```
backend/      FastAPI: main.py, schemas.py, data_loader.py, teams.py, team_stats.py, engines/ (fourth_down, offense, defense, common)
dashboard/    React + Vite + Tailwind + Recharts (components/, playbook/ con el libro de jugadas y el campo)
data/         CSV de Big Data Bowl y nflverse filtrado (ver data/README.md)
Datos/        Material de consulta (tracking completo y base de conocimiento). La app NO lo usa en ejecución
scripts/      prepare_data.py, check_data_quality.py
tests/        pytest
```

`Datos/` pesa unos 825 MB, casi todo de `tracking`. El comando `setup.sh --entregar` empaqueta todo salvo `.venv`, `node_modules` y similares, así que **mueve `Datos/` fuera del proyecto antes de generar el zip de entrega** (la app no la necesita). Para GitHub no hace falta moverla: `.gitignore` ya la excluye.

## Fuentes de datos

- [Big Data Bowl (repositorio del equipo)](https://github.com/ThompsonJamesBliss/nfl-big-data-bowl-regional-event-data/tree/main/data): `games`, `plays` y `pffScoutingData`. Cobertura PFF, formación, personal y defensores en la caja, solo pases de 2021 semanas 1 a 8.
- [nflverse-data](https://github.com/nflverse/nflverse-data/releases/tag/pbp): play-by-play 2018 a 2023, filtrado.

## Limitaciones

- La muestra de Big Data Bowl es pequeña (8 semanas, solo pases). Las recomendaciones que dependen de cobertura, formación o caja pueden tener confianza baja. La app lo indica.
- Los datos son observacionales. Ir por el primero tiene sesgo de selección: los equipos lo intentan cuando la situación les favorece.
- El 4º down no modela tiempos fuera, el viento ni la calidad del pateador o del equipo.
- Es una herramienta de apoyo a la decisión, no un oráculo.

## Fuera de alcance por ahora

Datos de `tracking`.
