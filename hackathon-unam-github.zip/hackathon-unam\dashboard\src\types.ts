export type Mode = 'offense' | 'defense' | 'fourth_down'
export type Confidence = 'alta' | 'media' | 'baja'

export interface RecommendRequest {
  mode: Mode
  down: number
  yards_to_go: number
  yardline_100: number
  score_diff: number
  quarter: number
  clock_seconds: number
  rival_coverage?: string
  formation?: string
  personnel?: string
  defenders_in_box?: number
  timeouts?: number
  team?: string
  opponent?: string
}

export interface Option {
  key: string
  label: string
  score: number
  score_metric: string
  success_rate: number | null
  n_samples: number
  confidence: Confidence
  detail: Record<string, number | null>
}

export interface ExplainResponse {
  explanation: string | null
  model: string | null
}

export interface RecommendResponse {
  mode: Mode
  best: string
  options: Option[]
  notes: string[]
  warnings: string[]
  context: Record<string, string | number>
}

export interface Meta {
  coverages: string[]
  coverage_types: string[]
  formations: string[]
  personnel: string[]
  defenders_in_box: number[]
  modes: Mode[]
  data: Record<string, number>
}

export interface TeamInfo {
  abbr: string
  name: string
  conference: string
  division: string
  color: string
  color2: string
}

export interface PlayStat {
  id: string
  label: string
  n: number
  share: number
  epa: number
  epa_adj: number
  success_rate: number
  lift: number
  edge: number
}

export interface OffenseProfile {
  plays: number
  pass_rate: number
  categories: PlayStat[]
  preferred: PlayStat | null
  most_effective: PlayStat | null
  signature: PlayStat | null
  strength: PlayStat | null
  formations: PlayStat[]
  passing: Record<string, number | null>
}

export interface DefenseProfile {
  plays: number
  epa_allowed_run: number
  epa_allowed_pass: number
  coverages: PlayStat[]
  preferred_coverage: PlayStat | null
  most_effective_coverage: PlayStat | null
  signature_coverage: PlayStat | null
  vulnerability: PlayStat | null
  man_rate: number | null
  blitz_rate: number | null
  pressure_rate: number | null
  passing_allowed: Record<string, number | null>
}

export interface TeamProfile {
  info: TeamInfo
  seasons: number[]
  offense: OffenseProfile
  defense: DefenseProfile
}

export interface TeamSummary {
  info: TeamInfo
  preferred_offense: string | null
  most_effective_offense: string | null
  preferred_defense: string | null
  most_effective_defense: string | null
}
